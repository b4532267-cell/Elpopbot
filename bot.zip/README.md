#### kemo-md ####
𝑶𝑾𝑵𝑬𝑹:
#               ```+201015115056```

𝑵𝑨𝑴𝑬 
#                  𝐄𝐋 𝐏𝐎𝐏 🩸


𝟏: `https://whatsapp.com/channel/0029Vb83VLS9mrGeH1iPbH30`


𝟐: `https://whatsapp.com/channel/0029Vb83VLS9mrGeH1iPbH30`

 #name bot
`𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻`