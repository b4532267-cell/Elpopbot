// --- ملف إدارة العمليات الرئيسي لمشروع SATO BOT ---
// المطور: كيمو البودرجي (KEMO EL BODRAGE)
// ✅ تم التوافق مع: plugins/jadibot-serbot.js + telegram_bot.js

import { join, dirname } from 'path';
import { createRequire } from 'module';
import { fileURLToPath } from 'url';
import { setupMaster, fork } from 'cluster';
import { watchFile, unwatchFile } from 'fs';
import { spawn } from 'child_process';       // ← مطلوب لتشغيل telegram_bot بشكل صحيح
import cfonts from 'cfonts';

// ──────────────────────────────────────────────
//  إعداد المسارات الأساسية
// ──────────────────────────────────────────────
const __dirname = dirname(fileURLToPath(import.meta.url));
const require   = createRequire(__dirname);

// ──────────────────────────────────────────────
//  شعار البوت
// ──────────────────────────────────────────────
cfonts.say('𝐄𝐋 𝐏𝐎𝐏-DE\nSYSTEM', {
  font: 'block',
  align: 'center',
  gradient: ['cyan', 'white']
});

cfonts.say('Bot Manager By KEMO', {
  font: 'simple',
  align: 'center',
  gradient: ['red', 'white']
});

// ──────────────────────────────────────────────
//  تحميل config.js لتهيئة global.conns / global.jadi
//  / global.db / global.ch وغيرها قبل أي شيء
//  (مطلوب بشكل صريح من jadibot-serbot.js)
// ──────────────────────────────────────────────
await import('./config.js');

// ──────────────────────────────────────────────
//  تشغيل main.js (واتساب) عبر cluster — نفس الطريقة الأصلية
// ──────────────────────────────────────────────
let isWorking = false;

async function launchWhatsApp() {
  if (isWorking) return;
  isWorking = true;

  const script = 'main.js';
  const args   = [join(__dirname, script), ...process.argv.slice(2)];

  setupMaster({ exec: args[0], args: args.slice(1) });

  let child = fork();

  child.on('exit', (code) => {
    isWorking = false;
    console.log(`⚠️  [main.js] توقف بكود: ${code}. إعادة تشغيل الواتساب...`);

    // إعادة تشغيل فورية دائماً لضمان الاستمرارية
    launchWhatsApp();

    // مراقبة الملف فقط عند الخروج غير الطبيعي (code !== 0)
    if (code === 0) return;
    watchFile(args[0], () => {
      unwatchFile(args[0]);
      launchWhatsApp();
    });
  });
}

// ──────────────────────────────────────────────
//  تشغيل telegram_bot.js عبر spawn (مستقل تماماً)
//  ← cluster.fork() لا يعمل صح مع telegram_bot لأنه
//    يحتاج Telegraf polling + clearPolling قبل البدء
//    وهو ما يعمله start.js — لذا نحاكي نفس المنطق هنا
// ──────────────────────────────────────────────
const TG_TOKEN = (() => {
  try {
    // نحاول نقرأ التوكن من config بدون هارد-كود
    return global.TelegramToken || global.telegramToken || null;
  } catch { return null; }
})();

const TG_API = TG_TOKEN ? `https://api.telegram.org/bot${TG_TOKEN}` : null;

async function clearTelegramPolling() {
  if (!TG_API) return; // إذا مفيش توكن نتجاوز
  try {
    const fetch = (await import('node-fetch')).default;
    await fetch(`${TG_API}/deleteWebhook?drop_pending_updates=true`);
    await fetch(`${TG_API}/getUpdates?timeout=0&offset=-1`);
    console.log('[INDEX] ✅ تم مسح جلسات Telegram القديمة');
  } catch (e) {
    console.log('[INDEX] ⚠️  لم يتمكن من مسح جلسات Telegram:', e.message);
  }
}

async function launchTelegram(attempt = 1) {
  console.log(`[INDEX] 🚀 تشغيل telegram_bot.js (محاولة #${attempt})...`);

  await clearTelegramPolling();
  // انتظر ثانيتين بعد المسح (نفس منطق start.js)
  await new Promise(r => setTimeout(r, 2000));

  const child = spawn('node', ['--experimental-vm-modules', 'telegram_bot.js'], {
    stdio: 'inherit',
    cwd:   __dirname,
  });

  child.on('exit', async (code, signal) => {
    console.log(`[INDEX] ⚠️  telegram_bot.js خرج — كود: ${code}, إشارة: ${signal}`);

    // إعادة المحاولة عند الخروج بخطأ أو بـ null (crash)
    if (code === 1 || code === null) {
      const wait = Math.min(5000 * attempt, 30000);
      console.log(`[INDEX] 🔄 إعادة تشغيل Telegram بعد ${wait / 1000}s...`);
      await new Promise(r => setTimeout(r, wait));
      launchTelegram(attempt + 1);
    } else if (code === 0) {
      // خروج طبيعي → أعد التشغيل مرة واحدة فقط
      launchTelegram(1);
    } else {
      console.log(`[INDEX] ❌ telegram_bot.js توقف نهائياً بكود: ${code}`);
    }
  });
}

// ──────────────────────────────────────────────
//  نقطة الانطلاق: شغّل الواتساب والتلجرام معاً
// ──────────────────────────────────────────────
launchWhatsApp();
launchTelegram();

console.log('✅ نظام الإدارة يعمل الآن: [WhatsApp ✔ | Telegram ✔]');
