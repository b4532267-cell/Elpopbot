// يجب عليك عدم تعديل اي شئ من بدايه السطر ال13 لعدم تخريب اللبوت #
// 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓
import { watchFile, unwatchFile } from 'fs' 
import chalk from 'chalk'
import { fileURLToPath, pathToFileURL } from 'url'
import path from 'path'
import { createRequire } from 'module'
import { platform } from 'process'

// ⚠️ globals مطلوبة عند تشغيل telegram_bot.js بدون main.js
if (!global.opts) global.opts = { legacy: false };
if (!global.conns) global.conns = [];
if (!global.APIs) global.APIs = {};
if (!global.APIKeys) global.APIKeys = {};

if (!global.__filename) {
  global.__filename = function filename(pathURL = import.meta.url, rmPrefix = platform !== 'win32') {
    return rmPrefix ? /file:\/\/\//.test(pathURL) ? fileURLToPath(pathURL) : pathURL : pathToFileURL(pathURL).toString();
  };
}
if (!global.__dirname) {
  global.__dirname = function dirname(pathURL) {
    return path.dirname(global.__filename(pathURL, true));
  };
}
if (!global.__require) {
  global.__require = function require(dir = import.meta.url) {
    return createRequire(dir);
  };
}
if (!global.API) {
  global.API = (name, p = '/', query = {}, apikeyqueryname) =>
    (name in global.APIs ? global.APIs[name] : name) + p +
    (query || apikeyqueryname ? '?' + new URLSearchParams(Object.entries({
      ...query,
      ...(apikeyqueryname ? { [apikeyqueryname]: global.APIKeys[name in global.APIs ? global.APIs[name] : name] } : {}),
    })) : '');
}

// conn — متغير حر في handler.js يجب أن يشير دائماً للاتصال النشط
// set يسمح لـ main.js بتعيين global.conn = makeWASocket(...) مباشرة
Object.defineProperty(global, 'conn', {
  get: () => global.conns?.find(c => c?.user) || global.conns?.[0] || null,
  set: (v) => {
    if (v !== null && v !== undefined) {
      if (!global.conns) global.conns = [];
      global.conns[0] = v;
    }
  },
  configurable: true,
  enumerable: true,
});

// متغيرات أخرى مطلوبة في handler.js
if (!global.rcanal)    global.rcanal    = null;
if (!global.timestamp) global.timestamp = { start: new Date() };
if (!global.pairing)   global.pairing   = 'number';

// 💡 تم تأمين الأرقام بجميع الصيغ المقروءة للـ Handler عشان يتعرف عليك فوراً كمطور
global.owner = [
  ['201015115056', '𝐄𝐋 𝐏𝐎𝐏-𝑴𝑫', true],
  ['1015115056', '𝐄𝐋 𝐏𝐎𝐏-𝑴𝑫', true],
  ['966567158348', 'دحوم | 𝑩𝑶𝑻', true],
  ['966567158348', 'دحوم | 𝑩𝑶𝑻', true]
]

global.mods = ['201015115056', '966567158348']
global.prems = ['201015115056', '966567158348']

global.libreria = 'Baileys'
global.baileys = 'V 6.7.16' 
global.vs = '2.2.0'
global.nameqr = '𝑸𝑹'
global.namebot = '𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻'
global.sessions = 'songsessions'
global.jadi = 'JadiBots' 
global.yukiJadibts = true

global.packname = '𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻$'
global.namebot = '𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻!! '
global.author = '𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻♡'
global.moneda = 'Dolar'
global.canalreg = '120363407666513777@newsletter'

global.namecanal = '⚝  𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓  ⚝'
global.canal = 'https://whatsapp.com/channel/0029Vb83VLS9mrGeH1iPbH30'
global.idcanal = '120363407666513777@newsletter'

global.ch = {
ch1: '120363407666513777@newsletter',
}

global.multiplier = 69 
global.maxwarn = '2'

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})