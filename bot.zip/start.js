/**
 * Wrapper لتشغيل telegram_bot.js بشكل آمن
 * يُنهي أي جلسة polling قديمة قبل البدء لتجنب خطأ 409
 */
import { spawn } from 'child_process';
import { createRequire } from 'module';

const _require = createRequire(import.meta.url);
const fetch = (await import('node-fetch')).default;

const BOT_TOKEN = '8843524822:AAGl0hirtuXRQlXEG21ZVgzq7PATOZhWyqs';
const TG_API    = `https://api.telegram.org/bot${BOT_TOKEN}`;

async function clearPolling() {
  try {
    // حذف أي webhook قائم
    await fetch(`${TG_API}/deleteWebhook?drop_pending_updates=true`);
    // استدعاء getUpdates بـ timeout=0 لإنهاء أي long-poll نشط
    await fetch(`${TG_API}/getUpdates?timeout=0&offset=-1`);
    console.log('[STARTER] ✅ Cleared previous polling sessions');
  } catch (e) {
    console.log('[STARTER] ⚠️  Could not clear sessions:', e.message);
  }
}

async function startBot(attempt = 1) {
  console.log(`[STARTER] 🚀 Starting telegram_bot.js (attempt #${attempt})...`);

  await clearPolling();
  // انتظر ثانيتين بعد المسح
  await new Promise(r => setTimeout(r, 2000));

  const child = spawn('node', ['telegram_bot.js'], {
    stdio: 'inherit',
    cwd: process.cwd(),
  });

  child.on('exit', async (code, signal) => {
    console.log(`[STARTER] ⚠️  Bot exited — code: ${code}, signal: ${signal}`);

    if (code === 1 || code === null) {
      // انتظر 5 ثواني قبل إعادة المحاولة لإفساح الوقت لإنهاء الـ poll القديمة
      const wait = Math.min(5000 * attempt, 30000);
      console.log(`[STARTER] 🔄 Retrying in ${wait / 1000}s...`);
      await new Promise(r => setTimeout(r, wait));
      startBot(attempt + 1);
    } else {
      process.exit(code || 0);
    }
  });
}

startBot();
