// core/theme.js
// 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓 - النسخة المؤمنة بالكامل ضد الإيرورز 🌙

export const theme = {
  // الرموز الأساسية والاحترافية
  skull: '⎔',
  blood: '✥',
  virus: '⬪',
  eye: '❖',
  sword: '⥍',
  target: '⥌',
  darkStar: '⸂🌙⸃',
  lightStar: '⸂✨⸃',
  
  // فواصل Unicode Fancy الاحترافية
  divider: '◑ • ─ ⌯┅┉⌯ •﹝🍫﹞• ⌯┅┉⌯ ─ • ◐',
  smallDivider: '⎔⋅• ─┈╌⬪─═✥═─⬪╌┈─ •⋅⎔',
  endDivider: '◑ • ─ ⌯┅┉⌯ •﹝🍫﹞• ⌯┅┉⌯ ─ • ◐',
  
  // تنسيق النص بالاستايل الفخم
  title: (text) => `> ˹ *${text || ''}* ˼`,
  subtitle: (text) => `> ⸂ *${text || ''}* ⸃`,
  info: (text) => `> ❖ *${text || ''}*`,
  warning: (text) => `> ⎔ *${text || ''}* ⎔`,
  success: (text) => `> ✥ *${text || ''}*`,
  error: (text) => `> ⬪ *${text || ''}*`,
  
  // بناء الرسالة بأمان تام
  build: function(sections) {
    // حماية لو الـ sections مبعوتة غلط أو مش مصفوفة (Array)
    if (!sections || !Array.isArray(sections)) return `> ${this.divider}\n>\n> ❌ خطأ في تحميل البيانات\n>\n> ${this.endDivider}`;

    let msg = `> ${this.divider}\n>\n`
    for (const section of sections) {
      if (!section) continue; // لو السيكشن مبعوت فاضي يتخطاه وميعملش كراش

      if (section.type === 'title') {
        msg += `> ˹ *${section.text || ''}* ˼\n`
      } else if (section.type === 'subtitle') {
        msg += `> ⸂ *${section.text || ''}* ⸃\n`
      } else if (section.type === 'info') {
        // تأمين الـ label والـ value عشان ما يطبعش undefined
        msg += `> ❖ ${section.label || ''}: ${section.value || ''}\n`
      } else if (section.type === 'line') {
        msg += `> ${section.text || ''}\n`
      } else if (section.type === 'divider') {
        msg += `> ${this.smallDivider}\n`
      } else if (section.type === 'spacer') {
        msg += `> \n`
      }
    }
    msg += `>\n> ${this.endDivider}`
    return msg
  }
}

export const formatWithTheme = (data) => {
  return theme.build(data)
}