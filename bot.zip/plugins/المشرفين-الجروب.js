const handler = async (m, { conn, participants, groupMetadata }) => {
  try {
    // ✅ التحقق من وجود قاعدة البيانات
    let chat = {};
    if (global.db?.data?.chats?.[m.chat]) {
      chat = global.db.data.chats[m.chat];
    }

    // ✅ جلب صورة الجروب مع صورة احتياطية
    let pp;
    try {
      pp = await conn.profilePictureUrl(m.chat, 'image');
    } catch {
      pp = 'https://i.imgur.com/6U6Z6jQ.jpg';
    }

    // ✅ استخراج الإعدادات مع قيم افتراضية آمنة
    const { 
      antiLink = false, 
      detect = false, 
      welcome = false, 
      modoadmin = false, 
      autoRechazar = false, 
      nsfw = false, 
      autoAceptar = false, 
      reaction = false, 
      isBanned = false, 
      antifake = false 
    } = chat;

    // ✅ تصحيح فلترة المدراء
    const groupAdmins = participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin');
    
    // ✅ تحسين عرض قائمة المدراء
    let listAdmin = 'لا يوجد مدراء';
    if (groupAdmins.length > 0) {
      listAdmin = groupAdmins.map((v, i) => `🤖 ${i + 1}. @${v.id.split('@')[0]}`).join('\n');
    }

    // ✅ تصحيح تحديد منشئ الجروب
    let owner = groupAdmins.find(p => p.admin === 'superadmin')?.id;
    if (!owner) {
      owner = groupAdmins[0]?.id || m.chat.split('-')[0] + '@s.whatsapp.net';
    }

    // ✅ جمع الأسماء المطلوب منشنها
    const mentions = [...groupAdmins.map(v => v.id)];
    if (owner && !mentions.includes(owner)) {
      mentions.push(owner);
    }

    // ✅ معالجة وصف الجروب بشكل آمن
    let groupDesc = 'لا يوجد وصف';
    if (groupMetadata.desc) {
      groupDesc = typeof groupMetadata.desc === 'string' 
        ? groupMetadata.desc 
        : groupMetadata.desc.toString?.() || 'لا يوجد وصف';
    }

    // ✅ تحسين النص
    const text = `*✧･ﾟ🤖 معلومات الجروب 🤖ﾟ･✧*

🤖 *معرف الجروب:* ${groupMetadata.id}
🤖 *اسم الجروب:* ${groupMetadata.subject}
🤖 *عدد الأعضاء:* ${participants.length}
🤖 *المنشئ:* @${owner.split('@')[0]}

🤖 *المدراء:*
${listAdmin}

*✦─━─━─━──━─━─━─✦*
🤖 *الإعدادات:*

◈ البوت: ${isBanned ? '❌ معطل' : '✅ مفعل'}
◈ الترحيب: ${welcome ? '✅' : '❌'}
◈ اكتشاف التغييرات: ${detect ? '✅' : '❌'}
◈ مضاد الروابط: ${antiLink ? '✅' : '❌'}
◈ قبول تلقائي: ${autoAceptar ? '✅' : '❌'}
◈ رفض تلقائي: ${autoRechazar ? '✅' : '❌'}
◈ محتوى +18: ${nsfw ? '✅' : '❌'}
◈ وضع المدراء: ${modoadmin ? '✅' : '❌'}
◈ الردود التفاعلية: ${reaction ? '✅' : '❌'}
◈ مضاد الأرقام الوهمية: ${antifake ? '✅' : '❌'}

*✦─━─━─━──━─━─━─✦*
🤖 *وصف الجروب:*
${groupDesc}

━━━━━━━━━━━━━━━
*𝐁𝐄𝐋𝐀𝐋 🩸*`;

    // ✅ استخدام sendMessage بدلاً من sendFile للتوافق
    await conn.sendMessage(m.chat, {
      image: { url: pp },
      caption: text,
      mentions: mentions
    }, { quoted: m });

  } catch (e) {
    console.error('❌ خطأ في أمر معلومات الجروب:', e);
    m.reply('❌ حصل خطأ أثناء جلب معلومات الجروب: ' + (e.message || 'خطأ غير معروف'));
  }
};

handler.help = ['infogrupo', 'الجروب'];
handler.tags = ['group'];
handler.command = ['infogrupo', 'الجروب', 'معلومات الجروب', 'groupinfo'];
handler.group = true;

export default handler;