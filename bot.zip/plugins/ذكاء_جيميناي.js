/**
 * 🤖 أمر Gemini AI المطور
 * 🛠️ المطور: KEMO EL BODRAGE
 * 🔗 API: Aqronix (Powered By Alakreb)
 */

import fetch from 'node-fetch';

let handler = async (m, { conn, text, usedPrefix, command }) => {
    // لو مفيش نص، يطلب من المستخدم يكتب سؤال
    if (!text) throw `*⚠️ يـا حـب اکـتـب سـؤالـك بـعـد الأمـر.. مـثـلاً:*\n\n*${usedPrefix + command} كـيـف حـالـك يـا جـيـمـنـي؟*`;

    try {
        // إظهار حالة "جاري الكتابة"
        await conn.sendPresenceUpdate('composing', m.chat);

        // طلب الـ API
        const response = await fetch('https://api.aqronix-host.site/api/v1/ai/chat/gemini', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: text,
                user_id: m.sender // عشان الـ AI يفتكر المحادثة لكل شخص
            })
        });

        const data = await response.json();

        if (!data.status) throw 'لأسف الـ API فيه مشكلة حالياً، جرب تاني كمان شوية.';

        // الرد المزخرف بالعريض
        let replyMsg = `
┏━━━━━━━❪ 🤖 ❫━━━━━━━┓
┃   ✨ 𝐆𝐄𝐌𝐈𝐍𝐈 | 𝐀𝐈 𝐀𝐒𝐒𝐈𝐒𝐓𝐀𝐍𝐓 ✨
┣━━━━━━━━━━━━━━━━┛
┃ 💡 الإجـابـة:
┃ 
┃ ${data.result}
┃ 
┣━━━━━━━━━━━━━━━━┓
┃ 🛠️ بـواسطـة: 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓
┗━━━━━━━❪ ⚡ ❫━━━━━━━┛`.trim();

        await conn.reply(m.chat, replyMsg, m);

    } catch (e) {
        console.error(e);
        await m.reply('❌ حـصـل خـطـأ فـي الاتـصـال بـالـذكـاء الاصـطـنـاعـي.');
    }
};

handler.help = ['gemini', 'ذكاء'];
handler.tags = ['ai'];
handler.command = /^(جيميني|gemini|ذكاء|ai)$/i; // يشتغل بكل الأوامر دي

export default handler;