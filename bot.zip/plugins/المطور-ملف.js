import fs from 'fs'
import path from 'path'

const getMimeType = (ext) => {
  switch (ext) {
    case '.js': return 'application/javascript'
    case '.json': return 'application/json'
    case '.txt': return 'text/plain'
    case '.env': return 'text/plain'
    default: return 'text/plain'
  }
}

const handler = async (m, { conn, args }) => {
  const filePath = args[0]
  if (!filePath) return m.reply('❌ اكتب مسار الملف مثل: .ملف plugins/example.js')

  const fullPath = path.join('./', filePath)
  if (!fs.existsSync(fullPath)) return m.reply('❌ الملف غير موجود')

  try {
    const content = fs.readFileSync(fullPath, 'utf8')
    const fileExt = path.extname(fullPath)
    const mime = getMimeType(fileExt)

    if (content.length <= 4000) {
      await conn.sendMessage(m.chat, {
        text: `📄 *محتوى ${filePath}:*\n\n${content}`,
      }, { quoted: m })
    } else {
      await conn.sendMessage(m.chat, {
        text: `⚠️ الملف طويل جدًا (${content.length} حرف)، تم إرساله كمستند.`,
      }, { quoted: m })
    }

    await conn.sendMessage(m.chat, {
      document: fs.readFileSync(fullPath),
      mimetype: mime,
      fileName: path.basename(filePath)
    }, { quoted: m })

  } catch (err) {
    m.reply(`❌ حدث خطأ أثناء قراءة الملف:\n\n${err}`)
  }
}

handler.help = ['ملف [المسار]']
handler.tags = ['tools']
handler.command = ['ملف']
handler.rowner = true

export default handler