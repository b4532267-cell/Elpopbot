import axios from "axios"

// --- إعدادات وثوابت البث والقناة (Newsletter) للوهم البرمجي ---
const newsletterJid  = '120363407666513777@newsletter';
const newsletterName = '.𓏲⋆˙𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓🎀';

// 🔒 حماية من التكرار
const _processed = new Set();

class SaveTube {
  constructor() {
    this.ky = 'C5D58EF67A7584E4A29F6C35BBC4EB12'
    this.m = /^((?:https?:)?\/\/)?((?:www|m|music)\.)?(?:youtube\.com|youtu\.be)\/(?:watch\?v=)?(?:embed\/)?(?:v\/)?(?:shorts\/)?([a-zA-Z0-9_-]{11})/
    this.is = axios.create({
      headers: {
        'content-type': 'application/json',
        'origin': 'https://yt.savetube.me',
        'user-agent': 'Mozilla/5.0 (Android 15; Mobile)'
      }
    })
  }

  async decrypt(enc) {
    const buf = Buffer.from(enc, 'base64')
    const keyBytes = Buffer.from(this.ky, 'hex')
    const iv = buf.slice(0, 16)
    const data = buf.slice(16)

    const cryptoKey = await globalThis.crypto.subtle.importKey(
      'raw',
      keyBytes,
      { name: 'AES-CBC' },
      false,
      ['decrypt']
    )

    const decrypted = await globalThis.crypto.subtle.decrypt(
      { name: 'AES-CBC', iv },
      cryptoKey,
      data
    )

    return JSON.parse(Buffer.from(decrypted).toString())
  }

  async getCdn() {
    const res = await this.is.get("https://media.savetube.vip/api/random-cdn")
    return { status: true, data: res.data.cdn }
  }

  async download(url) {
    const id = url.match(this.m)?.[3]
    if (!id) throw "رابط يوتيوب غير صالح"

    const cdn = await this.getCdn()
    const info = await this.is.post(`https://${cdn.data}/v2/info`, {
      url: `https://www.youtube.com/watch?v=${id}`
    })

    const dec = await this.decrypt(info.data.data)

    const dl = await this.is.post(`https://${cdn.data}/download`, {
      id,
      downloadType: 'audio',
      quality: '128',
      key: dec.key
    })

    return {
      title: dec.title,
      duration: dec.duration,
      thumb: dec.thumbnail,
      download: dl.data.data.downloadUrl
    }
  }
}

/* ================= المعالج ================= */

let handler = async (m, { conn, args, usedPrefix, command }) => {
  // 🔒 منع التكرار
  if (_processed.has(m.id)) return;
  _processed.add(m.id);
  setTimeout(() => _processed.delete(m.id), 60_000);

  if (!args[0]) {
    return m.reply(
      `❌ الاستخدام:\n${usedPrefix + command} <رابط_يوتيوب>\n\nمثال:\n${usedPrefix + command} https://youtu.be/U2vyax9Uufc`
    )
  }

  const url = args[0]
  const st = new SaveTube()

  const infoContextInfo = {
    mentionedJid: [m.sender],
    isForwarded: true,
    forwardingScore: 999,
    forwardedNewsletterMessageInfo: {
      newsletterJid: newsletterJid,
      newsletterName: newsletterName,
      serverMessageId: -1
    },
    externalAdReply: {
      title: '.𓏲⋆˙𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓🎀',
      body: 'تحميل صوت يوتيوب بأعلى جودة 🎧',
      thumbnail: global.icons || '', 
      sourceUrl: 'https://whatsapp.com/channel/0029VbCS3Q34SpkER26xwJ3u',
      mediaType: 1,
      renderLargerThumbnail: false
    }
  };

  const audioContextInfo = {
    mentionedJid: [m.sender],
    isForwarded: true,
    forwardingScore: 999,
    forwardedNewsletterMessageInfo: {
      newsletterJid: newsletterJid,
      newsletterName: newsletterName,
      serverMessageId: -1
    }
  };

  try {
    await conn.reply(
      m.chat,
      `*⏳ جَــأࢪي م࣬ـــ؏ٚـأݪـجَۿ أݪــࢪأبٚطَ وتنزيل ملف الصوت بـأعلى جودة...*`,
      m,
      { contextInfo: infoContextInfo, quoted: m }
    )

    const res = await st.download(url)

    const audioResponse = await axios.get(res.download, { responseType: 'arraybuffer' })
    const audioBuffer = Buffer.from(audioResponse.data, 'binary')

    let audioCaption = `🎵 *العنوان:* ${res.title}\n⏱ *المدة:* ${res.duration}`;

    await conn.sendMessage(
      m.chat,
      {
        audio: audioBuffer,
        mimetype: 'audio/mpeg', 
        fileName: `${res.title}.mp3`,
        caption: audioCaption, 
        ptt: false, 
        contextInfo: audioContextInfo
      },
      { quoted: m }
    )

    let successText = `✔ *تـم الـتـحـمـيـل بـنـجـاح مـيـة بـالـمـيـة!* \n\n` +
                      `📌 *العنوان:* ${res.title}\n` +
                      `⏱ *المدة:* ${res.duration}\n` +
                      `🎀 *بواسطة:* ${newsletterName}`;

    await conn.reply(m.chat, successText, m, { contextInfo: infoContextInfo, quoted: m });

  } catch (e) {
    console.error(e)
    await conn.reply(
      m.chat,
      `❌ *حدث خطأ أثناء معالجة أو إرسال الصوت:*\n${e.message || e}`,
      m,
      { contextInfo: infoContextInfo, quoted: m }
    )
  }
}

handler.help = ['صوت']
handler.command = ['صوت', 'ytmp3', 'mp3']
handler.tags = ['download']

export default handler