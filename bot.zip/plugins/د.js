let handler = async (m, { conn }) => {
  if (!m.isGroup) {
    return m.reply('⌯ هذا الأمر يعمل فقط داخل الجروبات 🧾');
  }

  let groupId = m.chat;
  m.reply(`🆔 معرف الجروب:\n\`${groupId}\``);
};

handler.command = /^د$/i; // الأمر هو .د
handler.group = true; // يشتغل بس داخل الجروبات

export default handler;