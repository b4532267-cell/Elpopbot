let handler = async (m, { conn }) => {

  // --- ✍️ اكتب النص الذي تريده هنا (سيراه الجميع) ---
  let teks = `> *★عـــلـــشـــان بـــحـــبـــك يـــعـــنـــي 🐣💕★* `; 
  // -------------------------------------------------------

  // إرسال الرد لأي مستخدم مع ميزة التوجيه من قناتك
  await conn.sendMessage(m.chat, {
    text: teks,
    mentions: [m.sender], // عمل منشن للشخص الذي نادى البوت
    contextInfo: {
      forwardingScore: 999, 
      isForwarded: true,    
      forwardedNewsletterMessageInfo: {
        newsletterJid: '120363407666513777@newsletter', 
        serverMessageId: 143,
        newsletterName: '𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻' 
      }
    }
  }, { quoted: m });

};

// 🎯 الكلمات التي يستجيب لها البوت (أي شخص يكتب ساتو أو كيمو)
handler.customPrefix = /البوب|بوب/i; 
handler.command = new RegExp;

export default handler;