import pkg from '@whiskeysockets/baileys'
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg

const handler = async (m, { conn }) => {
  try {
    let name = conn.getName(m.sender) || 'مستخدم'

    await conn.sendMessage(m.chat, { react: { text: '🎭', key: m.key } })

    // 🖼️ الصورة المثبتة الرسمية لبوتك
    const imageUrl = "https://files.catbox.moe/5o36un.jpg"
    const media = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer })

    // 📋 تنسيق الأوامر والاسم الجديد بالإيموجي 🍫 تحت بعض بالملي وبدون أعلام
    const caption = `
╭━━〔🎭 ﻗـسـم الـتـسـلـيـة 🎭〕━━⬣
┃ ➟ *مرحباً بك يا* 『${name}』
┃ ➟ *داخل بوت* 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 🍫
╰━━━━━━━━━━━━⬣

╭━━〔🍬 أوامـر الـتـسـلـيـة 🍬〕━━⬣
┃ ➟ 💥 *.صفع*
┃ ➟ ❓ *.هل*
┃ ➟ 👤 *.زنجي*
┃ ➟ ✨ *.جميل*
┃ ➟ 💬 *.كومنت*
┃ ➟ 🐦 *.تويته*
┃ ➟ 🎭 *.شخصيه*
┃ ➟ 🔮 *.حقيقة*
┃ ➟ 🙋‍♂️ *.انا*
┃ ➟ 📜 *.حكمه*
┃ ➟ 📝 *.بوست*
┃ ➟ 😂 *.ميمز*
┃ ➟ 💞 *.غزل*
┃ ➟ 💬 *.صراحه*
┃ ➟ 🔗 *.رابطي*
╰━━━━━━━━━━━━⬣
`.trim()

    let msg = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: caption },
            footer: { text: '⦓ 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ⦔' },
            header: { hasMediaAttachment: true, ...media },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "⬅️ العودة للقائمة الرئيسية",
                    id: ".menu"
                  })
                }
              ]
            }
          }
        }
      }
    }

    // تأكيد تنظيف الفوتر تماماً من أي علم في الرسالة التفاعلية
    msg.viewOnceMessage.message.interactiveMessage.footer.text = '⦓ 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓 ⦔'

    await conn.relayMessage(m.chat, msg, {})

  } catch (err) {
    console.error(err)
    await conn.sendMessage(m.chat, { text: '❌ حدث خطأ أثناء تنفيذ الأمر.' }, { quoted: m })
  }
}

handler.command = /^(ق9)$/i
handler.tags = ["fun"]
handler.help = ["ق9"]

export default handler