import fetch from 'node-fetch';
import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';
import { fileTypeFromBuffer } from 'file-type';

let handler = async (m, { conn, command, text, args, usedPrefix }) => {
  if (command === 'apk') {
    if (!text) {
      return await conn.sendMessage(m.chat, {
        text: `❗ *يرجى كتابة اسم التطبيق الذي تريد البحث عنه.*\n\n📦 مثال:\n${usedPrefix + command} facebook`
      }, { quoted: m });
    }

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
      const results = await searchApk(text);

      const uniqueApps = [];
      const seenNames = new Set();

      for (const app of results) {
        if (!seenNames.has(app.name)) {
          seenNames.add(app.name);
          uniqueApps.push(app);
        }
      }

      if (!uniqueApps.length) return m.reply("❌ لم يتم العثور على تطبيقات.");

      const apps = uniqueApps.slice(0, 5);
      const thumbnail = await prepareWAMessageMedia({ image: { url: apps[0].icon } }, { upload: conn.waUploadToServer });

      let msgText = `🔍 *نتائج البحث عن:* 『 ${text} 』\n\n`;
      msgText += apps.map((app, i) => `${i + 1}. ${app.name}`).join("\n");

      const buttons = apps.map((app, i) => ({
        name: 'quick_reply',
        buttonParamsJson: JSON.stringify({
          display_text: `${i + 1}. ${app.name}`,
          id: `.تنزيل-تطبيق ${app.package}`
        })
      }));

      const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              body: { text: msgText },
              footer: { text: "اختر التطبيق الذي تريده من الأزرار أدناه" },
              header: {
                hasMediaAttachment: true,
                imageMessage: thumbnail.imageMessage,
              },
              nativeFlowMessage: {
                buttons,
                messageParamsJson: "",
              }
            }
          }
        }
      }, { userJid: conn.user.jid, quoted: m });

      await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (e) {
      await conn.sendMessage(m.chat, { text: `❌ حدث خطأ أثناء البحث.` }, { quoted: m });
      console.error(e);
    }

  } else if (command === 'تنزيل-تطبيق') {
    if (!args[0]) {
      throw '🐦‍🔥*مثال:* \n ' + usedPrefix + command + ' com.facebook.lite\n\n🐦‍🔥*طريقة الاستخدام:* استخدم معرف التطبيق من الزر الذي يظهر عند البحث.';
    }

    conn.sendMessage(m.chat, { react: { text: "🕒", key: m.key } });

    try {
      let info = await apkinfo(args[0]);
      let res = await apk(args[0]);

      let { buffer, size, mimetype } = await downloadApkBuffer(res.download);

      if (size > 990 * 1024 * 1024) {
        throw '🐦‍🔥*ملف APK كبير جدًا. الحد الأقصى لحجم التنزيل هو 990 ميجابايت.*';
      }

      // إرسال معلومات التطبيق
      await conn.sendMessage(m.chat, {
        image: { url: info.icon },
        caption: `🐦‍🔥*↲⚡↱ الــتـطـبـيـق :* ${info.name}\n🐦‍🔥*↲⚡↱ المعرف (ID) :* ${info.packageN}\n🐦‍🔥*↲⚡↱ حجم الملف :* ${(size / 1024 / 1024).toFixed(2)} MB\n🐦‍🔥*↲⚡↱ سيتم إرسال التطبيق الآن...`,
        footer: '🐦‍🔥𝐄𝐋 𝐏𝐎𝐏 𝐁Ⓧ𝐓',
      });

      // إرسال التطبيق كـ buffer
      await conn.sendMessage(
        m.chat,
        {
          document: buffer,
          fileName: `${info.packageN}.apk`,
          mimetype
        },
        { quoted: m }
      );

    } catch (e) {
      console.error(e);
      m.reply('❌ حدث خطأ أثناء تنزيل التطبيق.');
    }
  }
};

handler.command = /^(apk|تنزيل-تطبيق)$/i;
handler.help = ['apk', 'تنزيل-تطبيق'];
handler.tags = ['downloader'];
export default handler;

// === FUNCTIONS ===

async function searchApk(query) {
  const res = await fetch(`https://ws75.aptoide.com/api/7/apps/search?query=${encodeURIComponent(query)}&limit=10`);
  const json = await res.json();
  return json.datalist.list.map(app => ({
    name: app.name,
    package: app.package,
    size: app.size,
    icon: app.icon,
    downloadLink: app.file.path
  }));
}

async function apkinfo(packageName) {
  const res = await fetch(`https://ws75.aptoide.com/api/7/apps/search?query=${packageName}&limit=1`);
  const json = await res.json();
  const app = json.datalist.list[0];
  if (!app) throw '❌ لم يتم العثور على التطبيق.';

  return {
    name: app.name,
    icon: app.icon,
    packageN: app.package,
    download: app.file.path
  };
}

async function apk(packageName) {
  const res = await fetch(`https://ws75.aptoide.com/api/7/apps/search?query=${packageName}&limit=1`);
  const json = await res.json();
  const app = json.datalist.list[0];
  if (!app || !app.file.path) throw '❌ تعذر الحصول على رابط التنزيل.';

  return {
    fileName: app.package + '.apk',
    download: app.file.path
  };
}

async function downloadApkBuffer(url) {
  const res = await fetch(url);
  if (!res.ok) throw '❌ فشل تحميل الملف من السيرفر';

  const buffer = await res.buffer();
  const fileType = await fileTypeFromBuffer(buffer);
  const mimetype = fileType?.mime || 'application/vnd.android.package-archive';

  return { buffer, size: buffer.length, mimetype };
}