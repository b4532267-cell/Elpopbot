const handler = async (m, { conn }) => {
    // نص الإعلان "الفخم"
    const advertisement = `
*╭━━━〔 ⟦‌🚸‌꯭‌⟧҉‌  𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻  ⟦‌🚸‌꯭‌⟧҉‌ 〕━━━╮*

*❮ هـل تـبـحـث عـن الـقـوة والـسـيـطـرة؟ ❯*
*إلـيـك بـوت سـاتـو - الأقـوى فـي الـواتـسـاب! 🩸*

*⟦‌🚸‌꯭‌⟧҉‌ مـمـيـزات لـن تـجـدهـا إلا مـعـنـا:*

*👑 الـمـطـور الـرسـمـي ⇜ 𝐁𝐄𝐋𝐀𝐋​​​​​​​​​​​​𓍼⸰🍸⸰*

*❮ لـشـراء الـنـسـخـة الـخـاصـة بـك أو لـلاسـتـفـسـار ❯*
*تـواصـل مـع الـمـطـور مـبـاشـرة مـن هـنـا:*
wa.me/201015115056

*✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦*
*𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻*
*✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦*`

    // إرسال الإعلان مع منشن للمطور
    await conn.sendMessage(m.chat, { 
        text: advertisement,
        contextInfo: {
            externalAdReply: {
                title: '𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻 𝑺𝒀𝑺𝑻𝑬𝑴',
                body: 'احصل على بوتك الخاص الآن!',
                thumbnailUrl: 'https://files.catbox.moe/mfi39c.jpg', // صورتك اللي استعملناها
                sourceUrl: 'https://whatsapp.com/channel/0029VbCS3Q34SpkER26xwJ3u',
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m })
}

handler.help = ['شراء']
handler.tags = ['main']
handler.command = ['شراء', 'شراء البوت', 'سعر البوت'] 

export default handler