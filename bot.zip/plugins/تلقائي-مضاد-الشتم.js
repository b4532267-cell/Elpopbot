import * as fs from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
const __dirname = dirname(fileURLToPath(import.meta.url));

const toxicRegex = /(^|\s)(g0re|g0r3|g.o.r.e|sap0|sap4|malparido|malparida|malparidos|malparidas|m4lp4rid0|m4lp4rido|m4lparido|malp4rido|m4lparid0|malp4rid0|chocha|chupalo|chupal0|chupon|chupameesta|sabandija|kbron|kbrona|putita|putito|putit0|pr0stitut4s|pr0stitutas|prostitut45|fanax|drogas|droga|dr0g4|nepe|p3ne|pen3|p.e.n.e|pvt0|pvto|put0|coño|c0ño|afeminado|marihuana|chocho|cagon|pedorro|agrandado|pinga|joto|mamar|chupa|caca|bobo|loco|chupapolla|estupido|estupida|polla|pollas|idiota|maricon|chucha|verga|vrga|naco|zorra|zorro|pito|huevon|huevona|mrd|ctm|csm|ptm|baboso|babosa|feo|fea|mamawebos|chupame|bolas|imbecil|cabron|carajo|gore|gordo|gorda|mierda|cerdo|cerda|puerco|puerca|perra|perro|dumb|fuck|shit|bullshit|cunt|semen|bitch|motherfucker|foker|fucking|كسمك|كسم|كـس|قحبة|قحب|قحاب|زبي|زبيك|زبك|زبيها|زبها|زبه|زبو|منيوك|خرا|عاهرة|متناك|متناكة|ناكك|انيك|ينيك|تنيك|نيج|ينج|وسخ|حيوان|خنزير|كلب|حقير|طرطور|عبيط|عرص|عرصة|شرموطة|شراميط|كس|كسك|كسها|كسو كسمك|كس اختك|بوت خربان|بوت فاشل|انيك عارضك|xnx|sexs|sex|سكس|بوت معطوب|زاني|قواد|ديوث|منيوكة|قحبه|كس اختك|كس امك|يلعن|يلعن امك|يلعن ابوك|ابن المتناكه|ابن القحبة|شراميط|fuckyou|dickhead|asshole|retard|suckmydick|suckit|motherfuck|yourmom|urmom|tetas|culo|chingadamadre|vergalon|estupidos|cabrona|gilipollas|pendejo|mierdaseca|imbécil|tont0|tonta|cojones|putamadre|idiotas|maldita|maldito|puta|putos|putas|pvtas|pvtos|ctmre|imbessil|حرامي|لقيط|ابن الزنا|منيوكين|قرفان|ناشف|زبالة|دبان|خبث|منيوك|مقزز|مقززة|خرابيط|دوخة|شاذ|شذوذ|خربان|خربانة|عتوه|بهدلة|رديء|مريض|غبي|غباء|خرفان|مخبوط|ناقص كرامه|بغل|بلطجي|مخرب|جبان|نذل|وقح|لئيم|فاشل|أهبل|دماغه فاضي|مسخوط|مقلوع|مخرّب|عتالة|فقران|مجنون|مجنونة|تخين|سمين|داعر|زق|زفت|زعران|فاسد|سفاح|شقيق|منحل|خاين|يردد|يتنمر|يتغشش|يتفل|يتفل عليك|تفل|يا واد يا كلب|يا عقيم|يا معفن|يا حقير|يا وحش|يا غبي|يا بليد|يا غشيم|يا كلب|يا داعر|يا خسيس|يا متسخ|يا وسخ|يا نذل|يا رديء|يا فاشل|يا حمار|يا وقح|يا ضايع|يا طماع|يا متعفن|يا منيوك|يا ابن الكلب|يا ولد القحبة|يا ولد الحرامي|يا ولد الزنا|يا ولد اللقيط|يا ولد الشرموطة|يا ولد العاهرة|يا ولد الفاسق|يا ولد المتناك|يا ولد الغبي|يا ولد السافل|يا ولد الداعر|يا ولد الحقير|يا ولد الندل|يا ولد الشرير|يا ولد الكذاب|يا ولد الخبيث|يا ولد اللئيم|يا ولد الوغد|يا ولد الجبان|يا ولد الطماع|يا ولد الحثالة|يا ولد القذر|يا ولد العاهر|يا ولد الخسيس|fuckbot|يا بوت كلب|يا روبوت كلب|يا بوت غبي|يا بوت معفن|botfuck)(\s|$)/i;

// مسار ملف قاعدة البيانات
const DB_PATH = join(__dirname, '../antispam-db.json');

// تهيئة قاعدة البيانات
let database = {};
try {
    database = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
} catch (e) {
    database = { users: {} };
    fs.writeFileSync(DB_PATH, JSON.stringify(database, null, 2));
}

export async function before(m, { conn, isAdmin, isBotAdmin, isOwner }) {
    if (m.isBaileys && m.fromMe) return true;
    if (!m.isGroup) return false;

    const delet = m.key.participant;
    const bang = m.key.id;
    const fakemek = {
        key: { participant: '0@s.whatsapp.net', remoteJid: '0@s.whatsapp.net' },
        message: {
            groupInviteMessage: {
                groupJid: '51995386439-1616969743@g.us',
                inviteCode: 'm',
                groupName: 'P',
                caption: '🚫 تم اكتشاف رسالة مزعجة',
                jpegThumbnail: null
            }
        }
    };

    if (!m.text) return true;

    const isToxic = toxicRegex.exec(m.text.toLowerCase());

    if (isToxic && !isOwner && !isAdmin) {
        if (!isBotAdmin) {
            await conn.sendMessage(m.chat, {
                text: `⚠️ تم اكتشاف كلمة ممنوعة (${isToxic[0]}) لكنني لست مشرفًا لذا لا أستطيع حذف الرسالة.`,
                mentions: [m.sender]
            }, { quoted: fakemek });
            return false;
        }

        try {
            await conn.sendMessage(m.chat, {
                delete: {
                    remoteJid: m.chat,
                    fromMe: false,
                    id: bang,
                    participant: delet
                }
            });
        } catch (e) {
            console.log('خطأ حذف رسالة:', e);
        }

        // تحديث قاعدة البيانات المحلية
        const user = database.users[m.sender] || {};
        user.warn = (user.warn || 0) + 1;
        database.users[m.sender] = user;
        fs.writeFileSync(DB_PATH, JSON.stringify(database, null, 2));

        if (user.warn < 4) {
            await conn.sendMessage(m.chat, {
                text: `*@${m.sender.split('@')[0]}*، لقد استخدمت كلمة ممنوعة (${isToxic[0]}). لديك الآن *${user.warn}/4* من التحذيرات قبل الحظر.`,
                mentions: [m.sender]
            }, { quoted: fakemek });
        } else {
            user.warn = 0;
            user.banned = true;
            fs.writeFileSync(DB_PATH, JSON.stringify(database, null, 2));

            await conn.sendMessage(m.chat, {
                text: `تم حظرك من المجموعة بسبب تكرار استخدام الكلمات الممنوعة\n*@${m.sender.split('@')[0]}*`,
                mentions: [m.sender]
            }, { quoted: fakemek });

            try {
                await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove');
            } catch (e) {
                console.log('خطأ طرد المستخدم:', e);
            }
        }

        return false;
    }

    return true;
}