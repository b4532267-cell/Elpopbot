import axios from "axios";

const client_id = "acc6302297e040aeb6e4ac1fbdfd62c3";
const client_secret = "0e8439a1280a43aba9a5bc0a16f3f009";
const basic = Buffer.from(`${client_id}:${client_secret}`).toString("base64");
const TOKEN_ENDPOINT = "https://accounts.spotify.com/api/token";

const getToken = async () => {
  const res = await axios.post(
    TOKEN_ENDPOINT,
    "grant_type=client_credentials",
    {
      headers: {
        Authorization: "Basic " + basic,
        "Content-Type": "application/x-www-form-urlencoded",
      },
    }
  );
  return res.data.access_token;
};

const searchTrack = async (query, token) => {
  const res = await axios.get(
    `https://api.spotify.com/v1/search?q=${encodeURIComponent(query)}&type=track&limit=1`,
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    }
  );
  if (res.data.tracks.items.length === 0) throw new Error("🐦‍🔥 لم يتم العثور على الأغنية.");
  return res.data.tracks.items[0];
};

const getDownloadLink = async (trackUrl) => {
  const res = await axios.post(
    "https://spotydown.media/api/download-track",
    { url: trackUrl },
    { headers: { "Content-Type": "application/json" } }
  );
  if (!res.data.file_url) throw new Error("🐦‍🔥 فشل في الحصول على رابط التحميل.");
  return res.data.file_url;
};

const handler = async (m, { conn, text, command }) => {
  if (!text) {
    let usage = `🐦‍🔥 *طريقة استخدام الأمر (${command}):*\n\n`;
    if (/^spotify$/i.test(command)) {
      usage += `أرسل الأمر مع اسم الأغنية.\nمثال: *spotify calm down*`;
    } else if (/^سبوتيفاي$/i.test(command)) {
      usage += `أرسل الأمر مع اسم الأغنية بالعربية أو الإنجليزية.\nمثال: *سبوتيفاي أحبك*`;
    }
    usage += `\n\n𝐄𝐋 𝐏𝐎𝐏 𝑩𝑶𝑻 𝚅¹🐦‍🔥`;
    return m.reply(usage);
  }

  await conn.sendMessage(m.chat, { react: { text: "🐦‍🔥", key: m.key } });

  try {
    const token = await getToken();
    const track = await searchTrack(text, token);
    const downloadUrl = await getDownloadLink(track.external_urls.spotify);

    await conn.sendMessage(m.chat, {
      audio: { url: downloadUrl },
      mimetype: "audio/mpeg",
      ptt: false,
      contextInfo: {
        externalAdReply: {
          title: track.name,
          body: `🐦‍🔥 الفنان: ${track.artists.map((a) => a.name).join(", ")}`,
          thumbnailUrl: track.album.images[0]?.url,
          mediaType: 1,
          mediaUrl: track.external_urls.spotify,
          sourceUrl: track.external_urls.spotify,
        },
      },
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: "🐦‍🔥", key: m.key } });

  } catch (err) {
    console.error(err);
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } });
    m.reply("🐦‍🔥 فشل في جلب الأغنية. حاول لاحقًا.\n\n𝐄𝐋 𝐏𝐎𝐏 𝑩𝑶𝑻 𝚅¹🐦‍🔥");
  }
};

handler.help = ["spotify", "سبوتيفاي"];
handler.tags = ["downloader"];
handler.command = /^spotify|سبوتيفاي$/i;
handler.register = true;
handler.group = true;
handler.limit = 3;

export default handler;