// plugins/owner.js
// 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓

let handler = async (m, { conn }) => {
  try {
    await conn.sendMessage(
      m.chat,
      {
        audio: { url: 'https://example.com/audio.opus' },
        mimetype: 'audio/mp4',
        ptt: true
      },
      { quoted: m }
    );
    await new Promise(resolve => setTimeout(resolve, 1000));
  } catch (e) {}

  let vcard = `BEGIN:VCARD
VERSION:3.0
FN:𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓
ORG:𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓
TITLE:Bot Developer
TEL;type=CELL;waid=201015115056:+201015115056
X-WA-BIZ-NAME:𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓
X-WA-BIZ-DESCRIPTION:𝐁𝐄𝐋𝐀𝐋 𝐄𝐋 𝐁𝐎𝐃𝐑𝐀𝐆𝐄
X-WA-BIZ-HOURS:Mo-Su 00:00-23:59
END:VCARD`

  let qkontak = {
    key: {
      fromMe: false,
      participant: "0@s.whatsapp.net",
      remoteJid: "status@broadcast"
    },
    message: {
      contactMessage: {
        displayName: "𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓",
        vcard
      }
    }
  }

  await conn.sendMessage(
    m.chat,
    {
      contacts: {
        displayName: '𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓',
        contacts: [{ vcard }]
      }
    },
    { quoted: qkontak }
  )
}

handler.help = ['owner', 'creator']
handler.tags = ['main']
handler.command = /^(owner|creator|المطورين|المطور|مطور|مطورك|مطوري|creador)$/i

export default handler