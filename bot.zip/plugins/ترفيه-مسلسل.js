let handler = async(m, {
        conn,
        text,
        command
}) => {
        let yh = global.loli
        let url = yh[Math.floor(Math.random() * yh.length)]
        conn.sendMessage(m.chat, {
                image: {
                        url: url
                },
                caption: `اتفضل يحب شوف دا`
        }, {
                quoted: m
        });
}
handler.command = /^(مسلسل)$/i
handler.tags = ['𝑮 𝑶 𝑲 𝑼']
handler.help = ['صور مسلسلات عشوائيه']
export default handler

global.loli = [
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://i.postimg.cc/sxhYRCTR/Screenshot-20220804-031853.png",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://i.postimg.cc/fT5LTg14/Screenshot-20220804-122545.png",
"https://i.postimg.cc/kXLxXzW1/Screenshot-20220804-122550.png",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
   ];
