/*
wa.me/6282285357346
github: https://github.com/sadxzyq
Instagram: https://instagram.com/tulisan.ku.id
ini wm gw cok jan di hapus
*/

import fetch from "node-fetch";
import axios from 'axios';
import cheerio from 'cheerio';

let lastNews = []; // لتخزين الأخبار المُرسلة
let currentIndex = -1; // مؤشر آخر خبر تم إرساله

let handler = async (m, { conn, text, usedPrefix, command }) => {
  // تحقق إذا كان الأمر يحتوي على نص (بحث) أم لا
  let isSearch = text.length > 0;
  let articles = isSearch ? await searchKaoriNews(text) : await fetchKaoriNews();

  if (!articles.length) return conn.sendMessage(m.chat, { text: "🐦‍🔥 فشل في جلب الأخبار من Kaori Nusantara، حاول مرة أخرى لاحقًا." }, { quoted: m });

  if (currentIndex === -1) {
    // إذا كانت هذه المرة الأولى التي يتم فيها إرسال الأخبار
    currentIndex = 0;
  } else {
    // إذا تم إرسال أخبار سابقة، نقوم بتغيير المؤشر
    currentIndex++;
  }

  // جلب الخبر المطلوب بناءً على المؤشر
  let article = articles[currentIndex];

  let timestamp = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
  let caption = `🐦‍🔥 *أحدث أخبار الأنمي و الثقافة الشعبية*\n\n📅 *تاريخ التحديث:* ${timestamp}\n\n`;

  // ترجمة كل جزء من الخبر
  let translatedTitle = await translate(article.title, 'ar'); // ترجمة العنوان
  let translatedAltTitle = article.altTitle ? await translate(article.altTitle, 'ar') : ''; // ترجمة العنوان البديل
  let translatedExcerpt = await translate(article.excerpt, 'ar'); // ترجمة الوصف
  let translatedCategory = article.category ? await translate(article.category, 'ar') : ''; // ترجمة الفئة
  let translatedAuthor = article.author ? await translate(article.author, 'ar') : ''; // ترجمة الكاتب

  // دمج الترجمة في العنوان
  caption += `🎯 *العنوان:* ${translatedTitle[0]} \n📝 *الترجمة:* ${translatedTitle[0]}\n`; // إضافة الترجمة بعد العنوان
  if (translatedAltTitle) caption += `🔖 *العنوان البديل:* ${translatedAltTitle[0]}\n`;
  caption += `📆 *التاريخ:* ${article.date || "غير متوفر"}\n`;
  caption += `✍️ *الكاتب:* ${translatedAuthor || "غير معروف"}\n`;
  caption += `📂 *الفئة:* ${translatedCategory || "غير متوفرة"}\n\n`;
  caption += `📝 *الوصف:* ${translatedExcerpt}\n\n`;
  caption += `📖 *اقرأ المقال:* \n${article.url}\n\n`;

  // إرسال الخبر المترجم للمستخدم
  try {
    await conn.sendMessage(m.chat, {
      image: { url: article.image },
      caption: caption
    }, { quoted: m });
  } catch (err) {
    console.error(err);
    m.reply("حدث خطأ أثناء إرسال الخبر.");
  }
};

// إضافة الأوامر باللغة العربية بجانب الإنجليزية
handler.command = /^(kaorinews|أخبار-انمي|اخبار-انمي)$/i;
handler.tags = ["news"];
handler.help = ["kaorinews", "أخبار-انمي", "اخبار-انمي"];

export default handler;

// دالة لتحميل الأخبار
async function fetchKaoriNews() {
  try {
    const { data: html } = await axios.get("https://www.kaorinusantara.or.id/newsline");
    const $ = cheerio.load(html);
    const articles = [];

    $(".td_module_10").each((_, el) => {
      const title = $(el).find(".entry-title a").text().trim();
      const url = $(el).find(".entry-title a").attr("href");
      const excerpt = $(el).find(".td-excerpt").text().trim();
      const date = $(el).find(".td-post-date time").text().trim();
      const author = $(el).find(".td-post-author-name a").text().trim();
      const category = $(el).find(".td-post-category").text().trim();
      const image = $(el).find(".td-module-thumb img").attr("data-src") || $(el).find(".td-module-thumb img").attr("src");

      articles.push({ title, url, date, author, category, excerpt, image });
    });

    return await scrapeArticleDetails(articles);
  } catch (error) {
    return [];
  }
}

// دالة للبحث في الأخبار
async function searchKaoriNews(query) {
  try {
    const { data: html } = await axios.get(`https://www.kaorinusantara.or.id/?s=${query}`);
    const $ = cheerio.load(html);
    const results = [];

    $(".td_module_10").each((_, el) => {
      const title = $(el).find(".entry-title a").text().trim();
      const url = $(el).find(".entry-title a").attr("href");
      const excerpt = $(el).find(".td-excerpt").text().trim();
      const date = $(el).find(".td-post-date time").text().trim();
      const author = $(el).find(".td-post-author-name a").text().trim();
      const category = $(el).find(".td-post-category").text().trim();
      const image = $(el).find(".td-module-thumb img").attr("data-src") || $(el).find(".td-module-thumb img").attr("src");

      results.push({ title, url, date, author, category, excerpt, image });
    });

    return await scrapeArticleDetails(results);
  } catch (error) {
    return [];
  }
}

// دالة لقراءة تفاصيل المقالات
async function scrapeArticleDetails(articles) {
  return await Promise.all(
    articles.map(async (article) => {
      try {
        const { data: html } = await axios.get(article.url);
        const $ = cheerio.load(html);

        const altTitle = $('meta[property="og:title"]').attr("content") || "";
        const content = $(".td-post-content").find("p").text().trim() || "غير متوفر";

        return { ...article, altTitle, content };
      } catch (error) {
        return article;
      }
    })
  );
}

// دالة لترجمة النصوص
async function translate(query = "", lang) {
  if (!query.trim()) return "";
  const url = new URL("https://translate.googleapis.com/translate_a/single");
  url.searchParams.append("client", "gtx");
  url.searchParams.append("sl", "auto");
  url.searchParams.append("dt", "t");
  url.searchParams.append("tl", lang);
  url.searchParams.append("q", query);

  try {
    const response = await fetch(url.href);
    const data = await response.json();
    if (data) {
      return [data[0].map((item) => item[0].trim()).join("\n"), data[2]];
    } else {
      return "";
    }
  } catch (err) {
    throw err;
  }
}