import { canLevelUp, xpRange } from '../lib/levelling.js';
import PhoneNumber from 'awesome-phonenumber';
import axios from 'axios';

// دالة فحص البريميوم (بسيطة ومباشرة)
function isPremium(userId) {
  const id = userId.split('@')[0];
  return global.prems && global.prems.includes(id);
}

let handler = async (m, { conn, usedPrefix }) => {
  try {
    // تحديد الشخص (منشن، ريبلاي، أو صاحب الرسالة)
    let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : m.sender;
    
    // جلب البيانات من الداتا (ولو مش موجود بنعمل بيانات وهمية عشان الكود ميفصلش)
    let user = global.db.data.users[who] || {
      name: conn.getName(who),
      level: 0,
      exp: 0,
      role: 'عابر سبيل 🚶',
      registered: false,
      age: '--'
    };

    // جلب الصورة والحالة من واتساب مباشرة (مش من الداتا)
    let pp = await conn.profilePictureUrl(who, 'image').catch(_ => 'https://files.catbox.moe/12zkn0.jpg');
    let bio = (await conn.fetchStatus(who).catch(_ => ({}))).status || 'لا توجد حالة';
    
    let prem = isPremium(who);

    // ✅ جلب الجنسية (لأي رقم في العالم)
    let userNationality = 'غير معروف 🌍';
    try {
      let numOnly = who.split('@')[0];
      let api = await axios.get(`https://delirius-apiofc.vercel.app/tools/country?text=${numOnly}`).timeout(2500);
      if (api.data && api.data.result) {
        userNationality = `${api.data.result.name} ${api.data.result.emoji}`;
      }
    } catch {
      userNationality = 'غير معروف 🌍';
    }

    // ✅ حساب الـ XP (لو مش مسجل هيظهر 0)
    let { min, xp } = xpRange(user.level, global.multiplier || 1);
    let currentXp = user.exp - min;
    let requiredXp = xp - min;
    let progress = requiredXp > 0 ? Math.min(Math.max((currentXp / requiredXp) * 10, 0), 10) : 0;
    let progressBar = '▰'.repeat(Math.floor(progress)) + '▱'.repeat(10 - Math.floor(progress));

    // ✅ التوقيت
    let d = new Date(new Date() + 3600000 * 3);
    let time = d.toLocaleTimeString('ar', { hour: 'numeric', minute: 'numeric' });

    // ✅ تنسيق الرسالة
    let txt = `*╭───〔 👤 بـروفـايـل الـمـسـتـخـدم 〕───⊷*\n`;
    txt += `*│* 👤 *الاسـم* : ${user.name || 'مجهول'}\n`;
    txt += `*│* 🎂 *العمر* : ${user.registered ? `${user.age} سنة` : 'غير مسجل'}\n`;
    txt += `*│* 🌍 *الجنسية* : ${userNationality}\n`;
    txt += `*│* 📊 *المستوى* : ${user.level} [ ${user.role} ]\n`;
    txt += `*│* 🚀 *الخبرة* : ${progressBar}\n`;
    txt += `*│* 🎖️ *الرتبة* : ${prem ? 'VIP 👑' : 'عضو عادي'}\n`;
    txt += `*│* 📝 *الحالة* : ${bio}\n`;
    txt += `*╰──────────────────────────⊷*`;

    await conn.sendMessage(m.chat, {
      image: { url: pp },
      caption: txt,
      mentions: [who],
      contextInfo: {
        forwardingScore: 999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: '120363407666513777@newsletter',
          serverMessageId: 143,
          newsletterName: '𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻 🦅'
        }
      }
    }, { quoted: m });

  } catch (e) {
    console.error(e);
    conn.reply(m.chat, '❌ فشل جلب البروفايل.', m);
  }
};

handler.help = ['بروفيل'];
handler.tags = ['main'];
handler.command = /^(بروفيل|بروفيلي|profile)$/i;

// 🛑 أهم تعديل: خلّينا دي false عشان أي حد يستخدمه
handler.register = false; 

export default handler;