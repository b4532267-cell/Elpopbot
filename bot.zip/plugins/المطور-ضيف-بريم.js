let handler = async (m, { conn, text, usedPrefix, command, isOwner }) => {
  
  // ✅ التحقق من أن المستخدم مطور
  if (!isOwner) return m.reply('❌ هذا الأمر للمطور فقط!');
  
  // ✅ تعريف fkontak (يمكن استخدامه في الردود)
  let fkontak = {
    "key": {
      "participants": "0@s.whatsapp.net",
      "remoteJid": "status@broadcast",
      "fromMe": false,
      "id": "Halo"
    },
    "message": {
      "contactMessage": {
        "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
      }
    },
    "participant": "0@s.whatsapp.net"
  }

  // ✅ تحديد المستخدم
  let who = m.isGroup ? (m.mentionedJid[0] ? m.mentionedJid[0] : (m.quoted ? m.quoted.sender : false)) : m.chat
  if (!who) throw `🐦‍🔥 *يجب تحديد أو الرد على المستخدم الذي تريد منحه البريميوم.*\n\n*مثال:* ${usedPrefix + command} @${m.sender.split`@`[0]} 1`

  // ✅ استخراج المدة
  let txt = text.replace('@' + who.split`@`[0], '').trim()
  if (!txt) throw `🐦‍🔥 *يرجى تحديد مدة البريميوم بالأرقام فقط.*\n\n*مثال:* ${usedPrefix + command} @${m.sender.split`@`[0]} 1`

  if (isNaN(txt)) return m.reply(`🐦‍🔥 *المدة يجب أن تكون رقمًا.*\n\n*مثال:* ${usedPrefix + command} @${m.sender.split`@`[0]} 1`)

  let name = '@' + who.split`@`[0]
  
  // ✅ التحقق من وجود المستخدم في قاعدة البيانات
  if (!global.db?.data?.users) {
    global.db.data.users = {};
  }
  if (!global.db.data.users[who]) {
    global.db.data.users[who] = {
      premium: false,
      premiumTime: 0,
      name: name
    };
  }
  
  let user = global.db.data.users[who]
  let now = Date.now()  // ✅ تصحيح: new Date() * 1 -> Date.now()
  let hora = 3600000 * txt
  let dia = 86400000 * txt
  let semana = 604800000 * txt
  let mes = 2629800000 * txt

  let timeValue
  let tiempoTexto

  // ✅ تحسين switch
  switch (command) {
    case 'addprem':
    case 'userpremium':
    case 'بريمو':
      timeValue = hora
      tiempoTexto = msToTime(hora)
      break
    case 'addprem2':
    case 'userpremium2':
    case 'بريم':
      timeValue = dia
      tiempoTexto = msToTime(dia)
      break
    case 'addprem3':
    case 'userpremium3':
      timeValue = semana
      tiempoTexto = msToTime(semana)
      break
    case 'addprem4':
    case 'userpremium4':
    case 'ضيف-بريم':
      timeValue = mes
      tiempoTexto = msToTime(mes)
      break
    default:
      throw `🐦‍🔥 *أمر غير معروف.*`
  }

  // ✅ إضافة البريميوم مع حساب الوقت المتبقي
  if (now < user.premiumTime) {
    // إذا كان المستخدم بريميوم بالفعل، نضيف المدة للمدة المتبقية
    let remaining = user.premiumTime - now;
    user.premiumTime = now + remaining + timeValue;
  } else {
    user.premiumTime = now + timeValue;
  }
  user.premium = true;

  // ✅ حساب الوقت المتبقي بشكل صحيح
  let remainingTime = user.premiumTime - now;
  let remainingText = msToTime(remainingTime);

  // ✅ إرسال الرد مع منشن صحيح
  let replyText = `🐦‍🔥 *تم ترقية المستخدم إلى بريميوم!*

✨ *الاسم:* ${name}
⏳ *المدة المضافة:* ${tiempoTexto}
⌛ *ينتهي بعد:* ${remainingText}

𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻🐦‍🔥`;

  await conn.reply(m.chat, replyText, m, {
    mentions: [who]  // ✅ تصحيح: استخدام who بدلاً من conn.parseMention
  });
  
  // ✅ حفظ التغييرات في قاعدة البيانات
  if (global.db.save) {
    global.db.save();
  }
}

handler.help = [
  'addprem [@user] <ساعات>',
  'addprem2 [@user] <أيام>', 
  'addprem3 [@user] <أسابيع>',
  'addprem4 [@user] <أشهر>',
  'بريمو', 'بريم', 'ضيف-بريم'
];
handler.tags = ['owner'];
handler.command = [
  'addprem', 'userpremium', 
  'addprem2', 'userpremium2', 
  'addprem3', 'userpremium3', 
  'addprem4', 'userpremium4', 
  'بريمو', 'بريم', 'ضيف-بريم'
];
handler.group = true;
handler.owner = true;

export default handler;

// ✅ دالة تحويل الوقت (محسنة)
function msToTime(duration) {
  if (duration < 0) return 'انتهت الصلاحية';
  
  let days = Math.floor(duration / (1000 * 60 * 60 * 24));
  let hours = Math.floor((duration % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  let minutes = Math.floor((duration % (1000 * 60 * 60)) / (1000 * 60));
  let seconds = Math.floor((duration % (1000 * 60)) / 1000);
  
  let parts = [];
  if (days > 0) parts.push(`${days} يوم`);
  if (hours > 0) parts.push(`${hours} ساعة`);
  if (minutes > 0) parts.push(`${minutes} دقيقة`);
  if (seconds > 0 || parts.length === 0) parts.push(`${seconds} ثانية`);
  
  return parts.join(' ');
}