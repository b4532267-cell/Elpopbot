let handler = async (m, { conn }) => {
  try {
    let groupMetadata = await conn.groupMetadata(m.chat)
    const welcomeMessage = `
┏━── ⭑ 💫 𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻  ⭑ ──━┓
| مرحباً بك أيها العضو الجديد! 
|  الاسم: @user
| المجموعة: ${groupMetadata.subject}
| تم انضمامك إلى عالم المتعة والحماس
| نتمنى لك وقتًا مليئًا بالحماس والجنون!💫
┗━── ⭑ 💫 𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻  ⭑ ──━┛
`.trim()
    global.db.data.chats[m.chat].welcome = true
    global.db.data.chats[m.chat].sWelcome = welcomeMessage
    conn.reply(m.chat, `✅ تم تغيير الترحيب إلى:\n\n${welcomeMessage.replace('@user', `@${m.sender.split('@')[0]}`)}`, m)
  } catch (error) {
    console.error(error)
    m.reply(`❌ حدث خطأ: ${error.message}`)
  }
}

handler.command = /^تغييرالترحيب$/i
handler.admin = true
handler.group = true
export default handler

let welcomeHandler = async (m, { conn }) => {
  try {
    if (m.action === 'add' && m.participants.length > 0 && global.db.data.chats[m.chat].welcome) {
      let groupMetadata = await conn.groupMetadata(m.chat)
      let welcomeMessage = global.db.data.chats[m.chat].sWelcome
      welcomeMessage = welcomeMessage.replace('@user', `@${m.participants[0].split('@')[0]}`)
      conn.sendMessage(m.chat, { text: welcomeMessage }, { mentions: [m.participants[0]] })
    }
  } catch (error) {
    console.error(error)
  }
}

welcomeHandler.all = true
welcomeHandler.group = true
export { welcomeHandler }