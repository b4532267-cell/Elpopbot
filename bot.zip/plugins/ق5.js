import pkg from '@whiskeysockets/baileys'
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg

const handler = async (m, { conn }) => {
  try {
    let name = conn.getName(m.sender) || 'مستخدم'

    await conn.sendMessage(m.chat, { react: { text: '📥', key: m.key } })

    // 🖼️ الصورة المثبتة الرسمية لبوتك
    const imageUrl = "https://files.catbox.moe/5o36un.jpg"
    const media = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer })

    // 📋 تنسيق الأوامر والاسم الجديد بالإيموجي 🍫 تحت بعض بالملي وبدون أعلام
    const caption = `
╭━━〔📥 ﻗـسـم الـتـحـمـيـل 📥〕━━⬣
┃ ➟ *مرحباً بك يا* 『${name}』
┃ ➟ *داخل بوت* 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 🍫
╰━━━━━━━━━━━━⬣

╭━━〔🍬 أوامـر الـتـحـمـيـل 🍬〕━━⬣
┃ ➟ 🗃️ *.جيتهاب*
┃ ➟ 🗂️ *.ميديا_فاير*
┃ ➟ 🎵 *.شغل*
┃ ➟ 📤 *.ميجا*
┃ ➟ 📍 *.تويتر*
┃ ➟ 💎 *.تيك*
┃ ➟ 🎥 *.رابط+ytmp4*
┃ ➟ 📥 *.رابط+ytmp3*
┃ ➟ 📺 *.يوتيوب*
┃ ➟ 📯 *.انستا*
╰━━━━━━━━━━━━⬣
`.trim()

    let msg = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: caption },
            footer: { text: '⦓ 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ⦔' }, // هنا الفوتر العادي للرسالة التفاعلية بدون تأثير على التكست الأساسي
            header: { hasMediaAttachment: true, ...media },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "⬅️ العودة للقائمة الرئيسية",
                    id: ".menu"
                  })
                }
              ]
            }
          }
        }
      }
    }

    // هنا عشان تطلع الـ 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 في الفوتر صافية من غير علم بوليفيا في الزرار التفاعلي نفسه
    msg.viewOnceMessage.message.interactiveMessage.footer.text = '⦓ 𝐄𝐋 𝐏𝐎𝐏 𝑩𝑶𝑻 ⦔'

    await conn.relayMessage(m.chat, msg, {})

  } catch (err) {
    console.error(err)
    await conn.sendMessage(m.chat, { text: '❌ حدث خطأ أثناء تنفيذ الأمر.' }, { quoted: m })
  }
}

handler.command = /^(ق5)$/i
handler.tags = ["download"]
handler.help = ["ق5"]

export default handler