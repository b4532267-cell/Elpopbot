// ╔══════════════════════════════════════════════╗
// ║        🛡️ مضاد البوتات — SATO BOT           ║
// ║    متوافق مع handler.js و lib/simple.js      ║
// ╚══════════════════════════════════════════════╝

// ─── تتبع البوتات المكتشفة في الذاكرة (مؤقت) ───
const detectedBots = {};

// ─── روابط الميديا ───
const MEDIA_URLS = {
    video: 'https://file.garden/aauvg01sjleV_ic1/VID-20260511-WA0128.mp4',
    audio: 'https://file.garden/aauvg01sjleV_ic1/VID-20260511-WA0128.mp3'
};

// ══════════════════════════════════════════════════
//   أمر التحكم: تفعيل / تعطيل / عرض الحالة
// ══════════════════════════════════════════════════
let handler = async (m, { conn, args, usedPrefix, command, isOwner, isAdmin }) => {
    let chatId = m.chat;

    // ─── قراءة إعدادات الجروب من قاعدة البيانات ───
    // نستخدم global.db.data.chats بدل ملف JSON خارجي
    // لأن هذا هو النظام المعتمد في SATO BOT
    if (!global.db.data.chats[chatId]) global.db.data.chats[chatId] = {};
    let chat = global.db.data.chats[chatId];
    let antibot = chat.antiBot === true;

    if (args[0] === "اون" || args[0] === "on" || args[0] === "تشغيل") {
        if (antibot) return m.reply("🛡️ مضاد البوتات مفعل بالفعل!");
        chat.antiBot = true;
        return m.reply("✅ تم تفعيل مضاد البوتات بنجاح!");

    } else if (args[0] === "اوف" || args[0] === "off" || args[0] === "ايقاف") {
        if (!antibot) return m.reply("❌ مضاد البوتات معطل بالفعل!");
        chat.antiBot = false;
        return m.reply("❌ تم تعطيل مضاد البوتات!");

    } else {
        let status = antibot ? '🟢 مفعل' : '🔴 معطل';
        return m.reply(
            `🛡️ *مضاد البوتات*\n` +
            `الحالة: ${status}\n\n` +
            `لاستخدامه:\n` +
            `${usedPrefix + command} اون\n` +
            `${usedPrefix + command} اوف`
        );
    }
};

// ══════════════════════════════════════════════════
//   handler.before — يشتغل على كل رسالة تيجي
//   handler.js بيناديه قبل معالجة الأوامر
// ══════════════════════════════════════════════════
handler.before = async function (m, { conn, isBotAdmin, isAdmin, isOwner, isROwner }) {
    try {
        // 1. جروبات فقط
        if (!m.isGroup) return false;

        // 2. تجاهل رسائل البوت نفسه
        // م.isBaileys معرَّف في lib/simple.js ويكشف رسائل البوت الأساسي
        if (m.isBaileys) return false;
        if (m.key.fromMe) return false;

        // 3. هل مضاد البوتات مفعّل في هذا الجروب؟
        let chat = global.db.data?.chats?.[m.chat];
        if (!chat?.antiBot) return false;

        // 4. تجاهل الأدمن والأوناز — لا نطردهم حتى لو رسالتهم شبهت بوت
        if (isAdmin || isOwner || isROwner) return false;

        // 5. ─── كشف بصمة الرسالة ───
        // handler.js يضع m.isBaileys = true لرسائل البوت الأساسي (3EB0 + fromMe)
        // هنا نكشف البوتات الخارجية بناءً على msgId فقط بدون fromMe
        let msgId = m.key?.id || '';
        let isBot = false;
        let botType = '';

        if (msgId) {
            // Baileys standard (أطوال مختلفة حسب الإصدار)
            if (msgId.startsWith('3EB0') && msgId.length < 25)
                { isBot = true; botType = 'Baileys'; }
            else if (msgId.startsWith('BAE5') && msgId.length === 16)
                { isBot = true; botType = 'Baileys v2'; }
            else if (msgId.startsWith('B24E') && msgId.length === 20)
                { isBot = true; botType = 'Baileys v3'; }
            else if (msgId.startsWith('8SCO') && msgId.length === 20)
                { isBot = true; botType = 'Baileys v4'; }
            else if (msgId.startsWith('NJX-'))
                { isBot = true; botType = 'NJX Bot'; }
        }

        if (!isBot) return false;

        // 6. فك تشفير الـ JID بالطريقة الصحيحة (conn.decodeJid موجودة في lib/simple.js)
        let senderId = conn.decodeJid(m.sender);
        let chatId   = conn.decodeJid(m.chat);
        let senderNum = senderId.split('@')[0];

        // 7. منع إرسال نفس التحذير مرتين للبوت الواحد
        if (!detectedBots[chatId]) detectedBots[chatId] = [];
        if (detectedBots[chatId].includes(senderId)) return false;
        detectedBots[chatId].push(senderId);

        // 8. ─── إرسال تحذير الميديا ───
        try {
            // فيديو كـ GIF مع الكابشن
            await conn.sendMessage(chatId, {
                video:       { url: MEDIA_URLS.video },
                gifPlayback: true,
                caption:
                    `🚨 *تم اكتشاف بوت!*\n` +
                    `👤 *الرقم:* ${senderNum}\n` +
                    `🔍 *النوع:* ${botType}`,
                mentions: [senderId]
            });

            // صوت تنبيه
            await conn.sendMessage(chatId, {
                audio:    { url: MEDIA_URLS.audio },
                mimetype: 'audio/mpeg',
                ptt:      false
            });

        } catch (mediaErr) {
            // fallback: رسالة نصية لو فشل الميديا
            console.error('[antibot] خطأ في إرسال الميديا:', mediaErr?.message);
            await conn.sendMessage(chatId, {
                text:     `🚨 *تم اكتشاف بوت!*\n📞 الرقم: ${senderNum}\n🏷️ النوع: ${botType}`,
                mentions: [senderId]
            });
        }

        // 9. ─── طرد البوت ───
        // isBotAdmin يجي من handler.js مباشرة — لا نحتاج نجيبه بنفسنا
        if (isBotAdmin) {
            try {
                await conn.groupParticipantsUpdate(chatId, [senderId], 'remove');
                await conn.sendMessage(chatId, {
                    text:     `✅ *تم طرد البوت بنجاح!*\n📞 الرقم: ${senderNum}`,
                    mentions: [senderId]
                });
            } catch (kickErr) {
                console.error('[antibot] فشل الطرد:', kickErr?.message);
                await conn.sendMessage(chatId, {
                    text:
                        `⚠️ *فشل الطرد!*\n` +
                        `📞 الرقم: ${senderNum}\n` +
                        `🔧 يرجى التأكد من صلاحيات البوت`,
                    mentions: [senderId]
                });
            }
        } else {
            await conn.sendMessage(chatId, {
                text:
                    `⚠️ *البوت مش أدمن!*\n` +
                    `📞 الرقم: ${senderNum}\n` +
                    `🔧 ارفعوا البوت أدمن عشان يطرد البوتات`,
                mentions: [senderId]
            });
        }

        // 10. مسح من قائمة التتبع بعد 15 ثانية (عشان لو رجع نكشفه تاني)
        setTimeout(() => {
            if (detectedBots[chatId]) {
                const idx = detectedBots[chatId].indexOf(senderId);
                if (idx > -1) detectedBots[chatId].splice(idx, 1);
            }
        }, 15000);

        return false; // لا نوقف معالجة الرسائل التانية

    } catch (e) {
        console.error('[antibot] خطأ عام:', e?.message);
        return false;
    }
};

// ══════════════════════════════════════════════════
//   إعدادات الـ Plugin
// ══════════════════════════════════════════════════
handler.command  = /^(مضاد_البوتات|antibot|نوبوت|مضاد)$/i;
handler.tags     = ['group'];
handler.group    = true;  // يشتغل في الجروبات فقط
handler.admin    = true;  // الأدمن فقط يقدر يشغّله
handler.botAdmin = true;  // البوت لازم يكون أدمن للطرد

export default handler;