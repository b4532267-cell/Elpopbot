import fetch from 'node-fetch'

let handler = async (m, { conn, args, command }) => {
  if (args.length < 2) {
    let usage = ''
    if (/^balogo$/i.test(command)) {
      usage = `🐦‍🔥 طريقة الاستخدام لأمر *balogo*:\nاكتب الأمر ثم الاسم الأول والثاني ليتم توليد الشعار بأسلوب Blue Archive.\n🐦‍🔥 مثال:\n.balogo Bella Taka\n𝐄𝐋 𝐏𝐎𝐏 𝑩𝑶𝑻 𝚅¹🐦‍🔥`
    } else if (/^لوج$/i.test(command)) {
      usage = `🐦‍🔥 طريقة الاستخدام لأمر *لوج*:\nاكتب "لوج" ثم اسمين (مثلاً اسمك واسم فريقك)، ليتم توليد شعار Blue Archive.\n🐦‍🔥 مثال:\nلوج سارة نينجا\n𝐄𝐋 𝐏𝐎𝐏 𝑩𝑶𝑻 𝚅¹🐦‍🔥`
    }
    return m.reply(usage)
  }

  const textL = encodeURIComponent(args[0])
  const textR = encodeURIComponent(args.slice(1).join(' '))
  const imageUrl = `https://api.nekorinn.my.id/maker/ba-logo?textL=${textL}&textR=${textR}`

  await conn.sendMessage(m.chat, {
    image: { url: imageUrl },
    caption: `🐦‍🔥 تم إنشاء شعارك بنجاح! 🐦‍🔥\n🐦‍🔥 باستخدام: ${args[0]} ${args.slice(1).join(' ')}\n𝐄𝐋 𝐏𝐎𝐏 𝑩𝑶𝑻 𝚅¹🐦‍🔥`
  }, { quoted: m });
};

handler.help = ['balogo <الاسم1> <الاسم2>', 'لوج <الاسم1> <الاسم2>']
handler.command = /^(balogo|لوج|لوجو)$/i
handler.tags = ['tools']

export default handler