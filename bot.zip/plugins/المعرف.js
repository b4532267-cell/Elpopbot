let handler = async (m, { conn }) => {
  if (!m.chat.endsWith('@newsletter')) return m.reply('❗ دي مش رسالة من قناة واتساب يا حب');

  let channelID = m.chat;
  m.reply(`✅ معرف القناة هو:\n\`\`\`${channelID}\`\`\``);
};

handler.command = ['المعرف'];
handler.help = ['المعرف'];
handler.tags = ['tools'];

export default handler;