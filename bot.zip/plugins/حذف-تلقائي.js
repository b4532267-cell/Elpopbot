// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  𝑺𝑨𝑻𝑶 | 𝑩𝑶𝑻  ⟡  حذف-تلقائي.js
//  إصلاح: ENOENT TaibSessions — guard على existsSync
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

import { readdir, unlink, mkdir } from 'fs/promises'
import { existsSync }             from 'fs'
import path                       from 'path'

const handler = (m) => m

handler.all = async function (m) {
  // ✅ FIX — المسار الصح هو songsessions وليس TaibSessions
  // واستخدم global.sessions لو معرّف، وإلا ارجع للمسار الافتراضي
  const sessionPath = `./${global.sessions || 'songsessions'}/`

  // ✅ FIX ENOENT — تحقق من وجود المجلد أولاً قبل readdir
  if (!existsSync(sessionPath)) return true

  // فقط البوت الأساسي يشغّل هذه العملية
  try {
    if (global.conn?.user?.jid && this?.user?.jid) {
      if (global.conn.user.jid !== this.user.jid) return true
    }
  } catch { return true }

  try {
    const files = await readdir(sessionPath)

    if (files.length >= 900) {
      const groupChat = '120363420377967468@g.us'

      await this.sendMessage(groupChat, {
        text: `🐦‍🔥 عدد الملفات وصل ${files.length}، جاري التنظيف... 🐦‍🔥`
      }).catch(() => {})

      const filesToDelete = files.filter(f => f !== 'creds.json')
      await Promise.all(
        filesToDelete.map(f => unlink(path.join(sessionPath, f)).catch(() => {}))
      )

      await this.sendMessage(groupChat, {
        text: `🐦‍🔥 تم حذف ${filesToDelete.length} ملف بنجاح 🐦‍🔥`
      }).catch(() => {})
    }
  } catch (err) {
    // ✅ FIX — لا نطبع ENOENT في الكونسول بعد الآن
    if (err.code !== 'ENOENT') {
      console.error('[SATO] Error while cleaning session files:', err.message)
    }
  }

  return true
}

export default handler
