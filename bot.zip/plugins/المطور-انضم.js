let handler = async (m, { conn, text, usedPrefix, command, args, isOwner }) => {

   if (!isOwner) return conn.reply(m.chat, `*دعوة البوت إلى مجموعة*\n\nيا @${m.sender.split('@')[0]}\nلو عاوز تضيف البوت لمجموعة، كلم الأونر عشان يظبطلك الموضوع`.trim(), m, { mentions: [m.sender] })

  let linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i
  let delay = time => new Promise(res => setTimeout(res, time))

  let [_, code] = text.match(linkRegex) || []
  if (!args[0]) throw `✠ ابعت رابط الجروب يا زعيم\n\n 📌 مثال:\n *${usedPrefix + command}* <الرابط>`
  if (!code) throw `✠ الرابط ده مش مظبوط يا فندم!`
  
  m.reply(`استنى عليا ثواني، جاري محاولة الانضمام...`)
  await delay(2000)

  try {
    // محاولة الانضمام المباشر
    let res = await conn.groupAcceptInvite(code)
    
    if (res) {
        await m.reply(`✅ البوت دخل الجروب بنجاح!`)
    }

  } catch (e) {
      // إذا فشل الانضمام المباشر، نحاول إرسال طلب انضمام (بسبب موافقة المشرف)
      try {
          let inviteRequest = await conn.groupRequestInvite(code)
          if (inviteRequest) {
              await m.reply(`⚠️ الجروب يتطلب موافقة المشرف.\n✅ تم إرسال طلب الانضمام بنجاح، انتظر قبول المشرفين.`)
          }
      } catch (err) {
          console.error(err)
          throw `❌ فشل الانضمام: الرابط قد يكون تالفاً أو تم طرد البوت مسبقاً من هذا الجروب.`
      }
  }
}

handler.help = ['join <chat.whatsapp.com>']
handler.tags = ['owner']
handler.command = ['join', 'انضم'] 

export default handler