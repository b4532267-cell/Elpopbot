import fg from 'api-dylux';
import fetch from 'node-fetch';
import axios from 'axios';

// حزم غير متوفرة — نستبدلها بـ null والكود يستخدم try-catch
const facebook = null;
const fbDownloader = null;
const facebookdl = null;
const facebookdlv2 = null;
const savefrom = null;

const handler = async (m, {conn, args, command, usedPrefix}) => {
  if (!args[0]) throw `*[❗معلومه❗] حط رابط الفيديو مثال: ${usedPrefix + command}* https://fb.watch/fOTpgn6UFQ/`;
  if (!args[0].match(/www.facebook.com|fb.watch/g)) throw `*[❗𝐈𝐍𝐅𝐎❗] حط رابط الفيديو مثال: ${usedPrefix + command}* https://fb.watch/fOTpgn6UFQ/`;
  try {
    await m.reply(`*انتظر جاري التحميل...*`);
    // محاولة 1: api-dylux
    const ress = await fg.fbdl(args[0]);
    const urll = ress.data[0].url;
    await conn.sendFile(m.chat, urll, 'facebook.mp4', '*✅ تم التحميل*', m);
  } catch (err1) {
    try {
      // محاولة 2: API عامة
      const res3 = await fetch(`https://latam-api.vercel.app/api/facebookdl?apikey=nekosmic&q=${args[0]}`);
      const json = await res3.json();
      const url3 = json.video;
      await conn.sendFile(m.chat, url3, 'facebook.mp4', '*✅ تم التحميل*', m);
    } catch (err2) {
      try {
        // محاولة 3: lolhuman API
        const Rres = await fetch(`https://api.lolhuman.xyz/api/facebook?apikey=nekosmic&url=${args[0]}`);
        const Jjson = await Rres.json();
        let VIDEO = Jjson.result?.[0] || Jjson.result?.[1];
        if (!VIDEO) throw new Error('no video');
        conn.sendFile(m.chat, VIDEO, 'facebook.mp4', '*✅ تم التحميل*', m);
      } catch (err3) {
        try {
          // محاولة 4: igeh
          const req = await igeh(args[0]);
          conn.sendMessage(m.chat, {video: {url: req.url_list[0]}}, {quoted: m});
        } catch (err4) {
          throw `*[❗] فشل تحميل الفيديو، تأكد من صحة الرابط.*`;
        }
      }
    }
  }
};

handler.command = /^(facebook|fb|فيس|fbdl|فيسبوك)$/i;
export default handler;

async function igeh(url_media) {
  return new Promise(async (resolve, reject) => {
    const BASE_URL = 'https://instasupersave.com/';
    try {
      const resp = await axios(BASE_URL);
      const cookie = resp.headers['set-cookie'];
      const session = cookie[0].split(';')[0].replace('XSRF-TOKEN=', '').replace('%3D', '');
      const config = {
        method: 'post', url: `${BASE_URL}api/convert`,
        headers: {
          'origin': 'https://instasupersave.com',
          'x-xsrf-token': session,
          'Content-Type': 'application/json',
          'Cookie': `XSRF-TOKEN=${session}; instasupersave_session=${session}`
        },
        data: {url: url_media}
      };
      axios(config).then(response => {
        const ig = [];
        if (Array.isArray(response.data)) {
          response.data.forEach(post => ig.push(post.sd === undefined ? post.thumb : post.sd.url));
        } else {
          ig.push(response.data.url[0].url);
        }
        resolve({url_list: ig});
      }).catch(e => reject(e.message));
    } catch (e) {
      reject(e.message);
    }
  });
}
