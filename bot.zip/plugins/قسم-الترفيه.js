import pkg from '@whiskeysockets/baileys'
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg

const handler = async (m, { conn }) => {
  try {
    // 🖼️ الصورة المثبتة الرسمية لبوتك
    const imageUrl = "https://files.catbox.moe/5o36un.jpg"
    const media = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer })

    await conn.sendMessage(m.chat, { react: { text: '🎭', key: m.key } })

    // 📋 تنسيق الأوامر تحت بعض بالملي وبإسم البوت الرسمي
    const caption = `
╭━━〔🎭 ﻗـسـم الـتـرفـيـه 🎭〕━━⬣
┃ ➟ *مرحباً بك يا* 『${m.pushName}』
┃ ➟ *داخل بوت* 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 🃏
╰━━━━━━━━━━━━⬣

╭━━〔🎉 أوامـر الـتـرفـيـه 🎉〕━━⬣
┃ ➟ 👥 *.أصحاب*
┃ ➟ ⚔️ *.إعدام*
┃ ➟ 🏆 *.توب*
┃ ➟ 🎭 *.الشخصية*
┃ ➟ 🗣️ *.الصراحة*
┃ ➟ ⚽ *.الكورة*
┃ ➟ 😈 *.انحرافي*
┃ ➟ 🎸 *.إيمو*
┃ ➟ 🐾 *.بوستات*
┃ ➟ 📝 *.بوست*
┃ ➟ 🚔 *.بوليس*
┃ ➟ 💎 *.بيبضني*
┃ ➟ ❤️ *.بيحبني*
┃ ➟ 💔 *.يكرهني*
┃ ➟ 👑 *.تاج*
┃ ➟ 💣 *.تفجير*
┃ ➟ 🔠 *.حروف*
┃ ➟ 🍀 *.حظي*
┃ ➟ 🐏 *.خروف*
┃ ➟ 💍 *.خطوبة*
┃ ➟ 🧠 *.ذكاء*
┃ ➟ 🦾 *.رجولتي*
┃ ➟ 🧑‍🤝‍🧑 *.رفيق*
┃ ➟ 🎭 *.شخصية*
┃ ➟ 🤝 *.صديق*
┃ ➟ 🎤 *.صراحتي*
┃ ➟ 💔 *.طلاق*
┃ ➟ 💞 *.علاقة*
┃ ➟ ❓ *.فزورة*
┃ ➟ 🎥 *.فيلم*
┃ ➟ 🔪 *.قتل*
┃ ➟ 🐱 *.قطة*
┃ ➟ 📖 *.مقولات*
┃ ➟ 🎲 *.نرد*
┃ ➟ 📊 *.نوعية*
┃ ➟ 🔍 *.هذا*
┃ ➟ ❔ *.هل*
┃ ➟ ⚰️ *.وفاتي*
╰━━━━━━━━━━━━⬣
`.trim()

    const msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            header: proto.Message.InteractiveMessage.Header.create({ title: '', hasMediaAttachment: true, ...media }),
            body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
            footer: proto.Message.InteractiveMessage.Footer.create({ text: '⦓ 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ⦔' }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "⬅️ العودة للقائمة الرئيسية",
                    id: ".menu"
                  })
                }
              ]
            })
          })
        }
      }
    }, { userJid: m.sender })

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

  } catch (err) {
    console.error(err)
    await conn.sendMessage(m.chat, { text: '❌ حدث خطأ أثناء تنفيذ الأمر.' }, { quoted: m })
  }
}

handler.command = /^قسم-الترفيه$/i
handler.tags = ["fun"]
handler.help = ["قسم-الترفيه"]

export default handler