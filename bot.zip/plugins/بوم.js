import fs from 'fs'
import { join } from 'path'

const handler = async (m, { conn, participants }) => {
  if (!m.isGroup) return

  const botId = conn.user.id.split(':')[0] + '@s.whatsapp.net'
  const ownerId = m.sender 

  const kickList = participants
    .filter(p => p.id !== botId && p.id !== ownerId) 
    .map(p => p.id)

  if (!kickList.length) return m.reply('⚠️ لا يوجد أعضاء لطردهم!')

  const newName = "مــزࢪوف 🩸 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓"
  const newDesc = `*عـــايـــز تـــعـــࢪف ڪـــيـــف اتـــزࢪفـــت 🩸*

*╭━━━〔 ⟦‌🚸‌꯭‌⟧҉‌  𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻  ⟦‌🚸‌꯭‌⟧҉‌ 〕━━━╮*

*❮ مرحباً بك في بوت 𝐄𝐋 𝐏𝐎𝐏 ❯*

*👑 المطور ⇜  𝐁𝐄𝐋𝐀𝐋​​​​​​​​​​​​𓍼⸰🍸⸰*

*⟦‌🚸‌꯭‌⟧҉‌ 『 بلاغ عن مشكلة 』*
*إذا واجهت أي خطأ أو عطل فني*
*استخدم الأمر:*
*❮.ابلاغ + وصف المشكلة❯*

┃ *⟦‌🚸‌꯭‌⟧҉‌ 『 قناެهُ البوت الرسمية 』*
┃ *.• بــنــزل ارقــام فــيــڪ و مــلــفــات بــوتــات هــنــاڪ.•*

*❮⟦‌🚸‌꯭‌⟧҉‌ 𝗖𝗛𝗔𝗡𝗡𝗘𝗟 𝐄𝐋 𝐏𝐎𝐏 𝗕𝗢𝗧❯*

*https://whatsapp.com/channel/0029Vb83VLS9mrGeH1iPbH30*

⟦‌🚸‌꯭‌⟧҉‌ *『 جــࢪوٰبٚ اެݪٺنٰــصَــي٘ــبٚ』*

*https://chat.whatsapp.com/KEIdC5qaCXRJGOmXiRoNEF?s=cl&p=a&mlu=4&amv=1*

*⟦‌🚸‌꯭‌⟧҉‌  اެؤاެم࣬ࢪ متكاملهُ • سرعة • حماية*
 ⟦‌🚸‌꯭‌⟧҉‌ *أقوى بوت واتساب حُتِيٰ اެݪاެنِ*

*✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦*
*⟦‌🚸‌꯭‌⟧҉‌  𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻 - 𝑺𝒀𝑺𝑻𝑬𝑴*
*​✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦ــﹻٰۨ۬ۛﹷ✦*`

  try {
    // 1. تغيير الوصف والاسم (أسرع شيء)
    await conn.groupUpdateDescription(m.chat, newDesc)
    await conn.groupUpdateSubject(m.chat, newName)

    // 2. تغيير الصورة من ملف داخلي (سرعة فائقة)
    const imagePath = join(process.cwd(), 'sato.jpg') // تأكد أن الصورة بهذا الاسم في فولدر البوت
    if (fs.existsSync(imagePath)) {
        const buffer = fs.readFileSync(imagePath)
        await conn.updateProfilePicture(m.chat, buffer)
    }

    // 3. طرد الجميع
    await conn.groupParticipantsUpdate(m.chat, kickList, 'remove')

    await m.reply(`*تـــم الـــزرف بـــنـــجـــاح 🩸*\n👥 المطرودين: ${kickList.length}`)

  } catch (err) {
    console.error(err)
    m.reply("❌ حدث خطأ!.")
  }
}

handler.help = ['فجر']
handler.tags = ['group']
handler.command = /^(فجرر|فجر|kickall)$/i

handler.group = true
handler.admin = true
handler.botAdmin = true

export default handler