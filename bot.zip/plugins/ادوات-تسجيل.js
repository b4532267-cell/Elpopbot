import db from '../lib/database.js';
import { createHash } from 'crypto';
import fetch from 'node-fetch';

let Reg = /\|?(.*)([.|] *?)([0-9]*)$/i;
let handler = async function (m, { conn, text, usedPrefix, command }) {
  let user = global.db.data.users[m.sender];
  let name2 = conn.getName(m.sender);

  if (user.registered === true) {
    return m.reply(`*⚡ يا ${name2}, أنت مسجل بالفعل بصفتك أحد ألعصابة!*`);
  }

  if (!Reg.test(text)) {
    return m.reply(
      `*⚡ أدخل اسمك وعمرك بأسلوب 𝐁𝐄𝐋𝐀𝐋!*\n\n*مثال:* .تسجيل 𝐁𝐄𝐋𝐀𝐋. 20`
    );
  }

  let [_, name, splitter, age] = text.match(Reg);
  if (!name) return conn.reply(m.chat, '*⚡ الاسم لا يمكن أن يكون فارغًا مثل شاكرا مكسورة!*', m);
  if (!age) return conn.reply(m.chat, '*⚡ العمر مطلوب يا شينوبي!*', m);

  age = parseInt(age);

  if (age < 15) return m.reply('*⚡ صغير جدًا على مهام ألعصابة. ارجع تدرب شوي!*');
  if (age >= 51 && age <= 85) return m.reply('*⚡ لا نأخذ شينوبي متقاعدين! خذ سيفك وارجع تقاعدك!*');
  if (age >= 86 && age <= 100) return m.reply('*⚡ هذا البوت للنينجا، مش لحفلات الشاي يا حج.*');
  if (age > 100) return m.reply('*⚡ لا يمكن تسجيل شينوبي من عصر الريكودو!*');

  user.name = name.trim();
  user.age = age;
  user.regTime = +new Date();
  user.registered = true;

  let sn = createHash('md5').update(m.sender).digest('hex').slice(0, 6);

  let imgUrl = [
    'https://files.catbox.moe/wfs4py.jpeg',
    'https://files.catbox.moe/wfs4py.jpeg',
    'https://files.catbox.moe/wfs4py.jpeg'
  ].getRandom();

  let imgBuffer;
  try {
    imgBuffer = await (await fetch(imgUrl)).buffer();
  } catch (error) {
    console.error('[ERROR] لم يتمكن من تحميل الصورة:', error);
    return m.reply('[⚡] لم يتم تحميل صورة الهوكاجي. حاول لاحقًا.');
  }

  let now = new Date();
  let date = now.toLocaleDateString('ar-AR', { year: 'numeric', month: 'long', day: 'numeric' });

  let txt = `╭══•ೋ✧⚡✧ೋ•══╮
*『 تـسـجـيـل الـنـيـنـجـا 』*
╰══•ೋ✧⚡✧ೋ•══╯
*☯️ الاسم:* 『 ${name} 』
*⛩️ العمر:* 『 ${age} سنة 』
*⚡ تاريخ التسجيل:* ${date}
*🌀 الرقم التسلسلي:* #${sn}
*━━━━━━━━━━━━━*
*مرحبًا بك بين صفوف ألعصابة، أيها الوميض القادم!*`;

  let dev = '『 ⚡ 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ⚡ 』';

  await conn.sendMessage(m.chat, {
    image: imgBuffer,
    caption: txt,
    footer: dev,
    buttons: [
      {
        buttonId: `.بروفيلي`,
        buttonText: { displayText: '⚔️ الملف الشخصي' },
      },
      {
        buttonId: `.اوامر`,
        buttonText: { displayText: '☁️ القائمة الرئيسية' },
      },
    ],
    viewOnce: true,
    headerType: 4,
  }, { quoted: m });

  await m.react('⚡');
};

handler.help = ['تسجيل'].map(v => v + ' *<الاسم.العمر>*');
handler.tags = ['start'];
handler.command = ['verify', 'reg', 'register', 'تسجيل'];

export default handler;