let handler = async (m, { conn, isOwner, command }) => {
  if (!isOwner) return m.reply('🚫 هذا الأمر مخصص للمطور فقط.');

  let groups = Object.entries(conn.chats).filter(([jid, chat]) => jid.endsWith('@g.us'));
  
  if (groups.length === 0) return m.reply('❌ البوت غير موجود في أي مجموعة.');

  let txt = `📦 *قائمة المجموعات التي يشترك فيها البوت:*\n\n`;
  
  for (let [jid, chat] of groups) {
    let metadata = await conn.groupMetadata(jid).catch(_ => null);
    if (!metadata) continue;

    let name = metadata.subject;
    let size = metadata.participants.length;
    let invite = 'غير متاح';

    try {
      invite = 'https://chat.whatsapp.com/' + await conn.groupInviteCode(jid);
    } catch (e) {}

    txt += `╭─────◇\n`;
    txt += `│ 📛 *الاسم:* ${name}\n`;
    txt += `│ 👥 *عدد الأعضاء:* ${size}\n`;
    txt += `│ 🔗 *الرابط:* ${invite}\n`;
    txt += `╰─────◆\n\n`;
  }

  await m.reply(txt);
};

handler.command = ['المجموعات'];
handler.owner = true;

export default handler;