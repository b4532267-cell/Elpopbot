let handler = m => m;

handler.all = async function (m) {
    if (m.key.fromMe) return;

    let chat = global.db.data.chats[m.chat];
    let responses;

    if (/^بوت خول$/i.test(m.text)) {
        responses = ['*زبي في طيزك اتحول 🤤*'];



    } else if (/^بوت ابن متناكه$/i.test(m.text)) {
        responses = ['*مفيش متناكه من بعد امك متشتمش البوت يخول 🫵🏻*'];


    } else if (/^كسم استا|بكسم البوت|استا كسمك$/i.test(m.text)) {
        responses = ['*كسم امك يا عرص متشتمش البوت 🫵🏻*'];
        
        

    } else if (/^ميتين البوت$/i.test(m.text)) {
        responses = ['*علي ميتين امك يعرص متشتمش البوت 🫵🏻*'];
        
    } else if (/^بوت زاني$/i.test(m.text)) {
        responses = ['*امك اللي زانيه يا عرص متشتمش البوت 🫵🏻*'];


    } else if (/^بوت عرص$/i.test(m.text)) {
        responses = ['*مفيش عرص غيرك هنا يخول متشتمش البوت 🫵🏻*'];

} else if (/^بوت دمج|انت بوت دمج$/i.test(m.text)) {
        responses = ['*مفيش دمج هنا غيرك يا خول متشتمش البوت 🫵🏻*'];
        


    } else if (/^بوت متناك|بوت عايز يتناك|انت بوت متناك$/i.test(m.text)) {
        responses = ['*مفيش متناك من بعدك يعرص متشتمش البوت 🫵🏻*'];



    } else if (/^عامل اي يا بوت|بوت عامل اي$/i.test(m.text)) {
        responses = ['*بخير الحمد لله 💎🩵*'];

    
    } else if (/^بوت كس$/i.test(m.text)) {
        responses = ['*انا زب في كسمك متشتمش البوت 🫵🏻*'];
        
    

    } else if (/^بوت علق$/i.test(m.text)) {
        responses = ['*مفيش علق من بعد ابوك يخول متشتمش البوت 🫵🏻*'];

   

    } else if (/^بوت عاق$/i.test(m.text)) {
        responses = ['*كسمك اللي عاق متشتمش البوت يمعرص 🫵🏻*'];



    
    } else if (/^بوت خرا$/i.test(m.text)) {
        responses = ['*كله انت*', '*انت الي خرا*'];



    } else if (/^بوت اسكت$/i.test(m.text)) {
        responses = ['*انـت مـيـن عـشـان تـسـكـتـنـي😠*', '*مـش هـسـكـت😝*', '*اسـكـت انـت🙄*'];
    }

    if (responses) {
        let response = responses[Math.floor(Math.random() * responses.length)];

        await this.sendMessage(m.chat, {
            text: response,
            contextInfo: {
                isForwarded: true,
                forwardingScore: 999,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363407666513777@newsletter',
                    newsletterName: '𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻',
                    serverMessageId: 100
                }
            }
        }, { quoted: m });
    }

    return !0;
};

export default handler;