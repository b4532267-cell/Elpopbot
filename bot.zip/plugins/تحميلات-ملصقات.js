// ╔══════════════════════════════════════════════════════════════╗
// ║     ⧼ 𝑷𝑹𝑶𝑻𝑶𝑻𝒀𝑷𝑬 ⧽ v2 — ملصقات Pinterest                  ║
// ║     plugins/stickers.js                                      ║
// ╚══════════════════════════════════════════════════════════════╝

import fetch    from 'node-fetch'
import { writeFileSync, unlinkSync, readFileSync, existsSync } from 'fs'
import { execSync } from 'child_process'
import webp     from 'node-webpmux'
import crypto   from 'crypto'

// ─── إضافة EXIF (حقوق البوت) ─────────────────────────────────────────────────
async function addExif(webpSticker) {
    try {
        const img          = new webp.Image()
        const stickerPackId = crypto.randomBytes(32).toString('hex')
        const json         = {
            'sticker-pack-id':        stickerPackId,
            'sticker-pack-name':      '𝐒𝐀𝐓𝐎 𝐁𝐎𝐓',
            'sticker-pack-publisher': '༺ 𝑲𝑬𝑴𝑶  ༻',
            'emojis':                 ['⚔️', '🩸', '🜲'],
        }
        const exifAttr = Buffer.from([
            0x49,0x49,0x2A,0x00,0x08,0x00,0x00,0x00,
            0x01,0x00,0x41,0x57,0x07,0x00,0x00,0x00,
            0x00,0x00,0x16,0x00,0x00,0x00,
        ])
        const jsonBuffer = Buffer.from(JSON.stringify(json), 'utf8')
        const exif       = Buffer.concat([exifAttr, jsonBuffer])
        exif.writeUIntLE(jsonBuffer.length, 14, 4)
        await img.load(webpSticker)
        img.exif = exif
        return await img.save(null)
    } catch {
        return webpSticker
    }
}

// ─── صورة ثابتة → WEBP ستيكر ─────────────────────────────────────────────────
async function makeStaticSticker(buffer, index) {
    const inputPath  = `./tmp_stk_${Date.now()}_${index}.jpg`
    const outputPath = `./tmp_stk_${Date.now()}_${index}.webp`
    try {
        writeFileSync(inputPath, buffer)
        execSync(
            `ffmpeg -y -i "${inputPath}" -vf "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000" -q:v 80 "${outputPath}"`,
            { stdio: 'pipe' }
        )
        let result = readFileSync(outputPath)
        result = await addExif(result)
        return result
    } finally {
        try { if (existsSync(inputPath))  unlinkSync(inputPath)  } catch {}
        try { if (existsSync(outputPath)) unlinkSync(outputPath) } catch {}
    }
}

// ─── GIF/WEBP متحرك → WEBP ستيكر متحرك ──────────────────────────────────────
async function makeAnimatedSticker(buffer, index, ext = 'gif') {
    const inputPath  = `./tmp_stk_anim_${Date.now()}_${index}.${ext}`
    const outputPath = `./tmp_stk_anim_${Date.now()}_${index}.webp`
    try {
        writeFileSync(inputPath, buffer)
        execSync(
            `ffmpeg -y -i "${inputPath}" -vf "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000,fps=15" -loop 0 -q:v 80 -preset default -an "${outputPath}"`,
            { stdio: 'pipe' }
        )
        let result = readFileSync(outputPath)
        result = await addExif(result)
        return result
    } finally {
        try { if (existsSync(inputPath))  unlinkSync(inputPath)  } catch {}
        try { if (existsSync(outputPath)) unlinkSync(outputPath) } catch {}
    }
}

// ─── البحث في Pinterest ───────────────────────────────────────────────────────
async function searchPinterest(query, count = 30) {
    const results  = { static: [], animated: [] }
    const UA       = 'Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36'

    // ── محاولة 1: Pinterest HTML ──────────────────────────────────────────────
    try {
        const res = await fetch(
            `https://www.pinterest.com/search/pins/?q=${encodeURIComponent(query)}&rs=typed`,
            { headers: { 'User-Agent': UA, 'Accept': 'text/html', 'Accept-Language': 'ar,en;q=0.9' }, redirect: 'follow' }
        )
        if (res.ok) {
            const html = await res.text()

            // صور ثابتة
            const originals = html.match(/https:\/\/i\.pinimg\.com\/originals\/[^\s"'\\><]+\.(?:jpg|png|jpeg)/gi) || []
            const x736      = html.match(/https:\/\/i\.pinimg\.com\/736x\/[^\s"'\\><]+\.(?:jpg|png|jpeg)/gi)      || []
            const x564      = html.match(/https:\/\/i\.pinimg\.com\/564x\/[^\s"'\\><]+\.(?:jpg|png|jpeg)/gi)      || []

            // صور متحركة GIF
            const gifs      = html.match(/https:\/\/i\.pinimg\.com\/[^\s"'\\><]+\.gif/gi) || []
            const gifOrig   = html.match(/https:\/\/i\.pinimg\.com\/originals\/[^\s"'\\><]+\.gif/gi) || []

            results.static.push(
                ...[...new Set([...originals, ...x736, ...x564])]
            )
            results.animated.push(
                ...[...new Set([...gifOrig, ...gifs])]
            )
        }
    } catch {}

    // ── محاولة 2: Pinterest API ────────────────────────────────────────────────
    try {
        const res = await fetch(
            `https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=/search/pins/?q=${encodeURIComponent(query)}&data={"options":{"query":"${encodeURIComponent(query)}","scope":"pins","page_size":${count * 2}}}&_=1`,
            { headers: { 'User-Agent': UA, 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' } }
        )
        if (res.ok) {
            const json    = await res.json()
            const pins    = json?.resource_response?.data?.results || []
            for (const pin of pins) {
                const imgUrl = pin?.images?.orig?.url || pin?.images?.['736x']?.url
                if (imgUrl) {
                    if (imgUrl.endsWith('.gif')) results.animated.push(imgUrl)
                    else results.static.push(imgUrl)
                }
            }
        }
    } catch {}

    // ── محاولة 3: Tenor GIFs للمتحركة ────────────────────────────────────────
    try {
        const res = await fetch(
            `https://tenor.com/search/${encodeURIComponent(query)}-gifs`,
            { headers: { 'User-Agent': UA, 'Accept': 'text/html' } }
        )
        if (res.ok) {
            const html = await res.text()
            const gifs = html.match(/https:\/\/media\.tenor\.com\/[^\s"'\\><]+\.gif/gi) || []
            results.animated.push(...[...new Set(gifs)])
        }
    } catch {}

    // ── محاولة 4: Giphy للمتحركة ──────────────────────────────────────────────
    try {
        const res = await fetch(
            `https://giphy.com/search/${encodeURIComponent(query)}`,
            { headers: { 'User-Agent': UA, 'Accept': 'text/html' } }
        )
        if (res.ok) {
            const html = await res.text()
            const gifs = html.match(/https:\/\/media\d?\.giphy\.com\/media\/[^\s"'\\><]+\/giphy\.gif/gi) || []
            results.animated.push(...[...new Set(gifs)])
        }
    } catch {}

    // ── Unsplash للصور الثابتة كـ fallback ───────────────────────────────────
    if (results.static.length < 5) {
        try {
            const res = await fetch(
                `https://unsplash.com/napi/search/photos?query=${encodeURIComponent(query)}&per_page=30`,
                { headers: { 'User-Agent': UA, 'Accept': 'application/json' } }
            )
            if (res.ok) {
                const data = await res.json()
                const imgs = (data.results || []).map(p => p.urls?.regular).filter(Boolean)
                results.static.push(...imgs)
            }
        } catch {}
    }

    return {
        static:   [...new Set(results.static)].slice(0, count),
        animated: [...new Set(results.animated)].slice(0, count),
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
//                              Handler
// ═══════════════════════════════════════════════════════════════════════════════
let handler = async (m, { conn, text, args, usedPrefix, command }) => {

    const react = async (emoji) => {
        try { await conn.sendMessage(m.chat, { react: { text: emoji, key: m.key } }) } catch {}
    }

    if (!text) {
        react('❌')
        return m.reply(
`╭━❪ 𖤐 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓 𖤐 ❫━╮
│
│ 🜲⃝☠️ *بـحـث مـلـصـقـات*
│ 𖤐⃝🩸 *مـن Pinterest + Giphy*
│
│ 👁️⃝🩸 *الاستخدام:*
│ ${usedPrefix + command} ⧼البحث⧽ ⧼العدد⧽
│
│ 👁️⃝🩸 *أمثلة:*
│ ${usedPrefix + command} anime 10
│ ${usedPrefix + command} cat 20
│ ${usedPrefix + command} fire 30
│
│ 📌⃝🩸 *الحد الأقصى: 30 ملصق*
│ ✨⃝🩸 *يشمل ثابتة ومتحركة!*
│
╰━❪ 𖤐 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓 𖤐 ❫━╯`
        )
    }

    // ── تحليل الأمر ──────────────────────────────────────────────────────────
    let query = text
    let count = 10

    const parts    = text.split(' ')
    const lastPart = parts[parts.length - 1]
    if (!isNaN(lastPart) && parts.length > 1) {
        count = Math.min(30, Math.max(1, parseInt(lastPart)))
        query = parts.slice(0, -1).join(' ')
    }

    react('🔍')

    await conn.sendMessage(m.chat, {
        text:
`╭━❪ 𖤐 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓 𖤐 ❫━╮
│
│ 🔍⃝🩸 *جـاري الـبـحـث عـن:*
│ 🜲⃝☠️ *${query}*
│ 📊⃝🩸 *العـدد:* ${count} مـلـصـق
│ ✨⃝🩸 *ثابتة + متحركة*
│
╰━❪ 𖤐 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓 𖤐 ❫━╯`
    }, { quoted: m })

    try {
        const images = await searchPinterest(query, count)
        const allStatic   = images.static
        const allAnimated = images.animated

        if (allStatic.length === 0 && allAnimated.length === 0) {
            react('❌')
            return m.reply(`❌⃝🩸 *لا تـوجـد نـتـائـج لـ: ${query}*`)
        }

        react('⏳')

        let sentStatic   = 0
        let sentAnimated = 0
        let failCount    = 0

        const UA = 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36'

        // ── إرسال الصور الثابتة ───────────────────────────────────────────────
        for (let i = 0; i < allStatic.length && (sentStatic + sentAnimated) < count; i++) {
            try {
                const imgRes = await fetch(allStatic[i], {
                    headers: { 'User-Agent': UA },
                    timeout: 10000,
                })
                if (!imgRes.ok) { failCount++; continue }

                const buffer  = Buffer.from(await imgRes.arrayBuffer())
                const sticker = await makeStaticSticker(buffer, i)

                await conn.sendMessage(m.chat, { sticker }, { quoted: m })
                sentStatic++
                await new Promise(r => setTimeout(r, 400))
            } catch { failCount++ }
        }

        // ── إرسال الصور المتحركة ──────────────────────────────────────────────
        for (let i = 0; i < allAnimated.length && (sentStatic + sentAnimated) < count; i++) {
            try {
                const imgRes = await fetch(allAnimated[i], {
                    headers: { 'User-Agent': UA },
                    timeout: 15000,
                })
                if (!imgRes.ok) { failCount++; continue }

                const buffer  = Buffer.from(await imgRes.arrayBuffer())
                const url     = allAnimated[i]
                const ext     = url.endsWith('.webp') ? 'webp' : 'gif'
                const sticker = await makeAnimatedSticker(buffer, i, ext)

                await conn.sendMessage(m.chat, { sticker }, { quoted: m })
                sentAnimated++
                await new Promise(r => setTimeout(r, 600))
            } catch { failCount++ }
        }

        react('✅')

        await conn.sendMessage(m.chat, {
            text:
`╭━❪ 𖤐 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓 𖤐 ❫━╮
│
│ ✅⃝🩸 *تـم الإرسـال!*
│ 🖼️⃝🩸 *ثـابـتـة:* ${sentStatic}
│ ✨⃝🩸 *مـتـحـركـة:* ${sentAnimated}
│${failCount > 0 ? ` ❌⃝🩸 *فـشـل:* ${failCount}\n│` : ''}
│ 🔍⃝🩸 *الـبـحـث:* ${query}
│
╰━❪ 𖤐 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓 𖤐 ❫━╯`
        }, { quoted: m })

    } catch (e) {
        console.error('❌ خطأ ملصقات:', e)
        react('❌')
        m.reply(`❌⃝🩸 *حـدث خـطـأ:* ${e.message}`)
    }
}

handler.command = ['ملصقات', 'حزمة', 'ملصق', 'stickers', 'stikers', 'pack']
handler.help    = ['ملصقات [بحث] [عدد]']
handler.tags    = ['sticker']

export default handler