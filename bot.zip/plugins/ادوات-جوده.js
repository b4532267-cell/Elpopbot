import fetch from 'node-fetch';
import FormData from 'form-data';

const handler = async (m, { conn, args, usedPrefix, command }) => {
    // 🐦‍🔥 تحديد اسم الأمر المستخدم (عربي/إنجليزي)
    const commandName = command.toLowerCase();
    const isArabicCommand = commandName === 'جوده' || commandName === 'جودة';

    // 🐦‍🔥 رسالة المساعدة مع أمثلة
    const usageMessage = `
*🐦‍🔥 كيفية الاستخدام:*
▢ *${usedPrefix}${command}* (بالرد على صورة أو إرسال صورة)
▢ *مثال:* ${usedPrefix}${command} مع صورة مرفقة

*🐦‍🔥 الميزات:*
▢ يحسن جودة الصور باستخدام الذكاء الاصطناعي
▢ يدعم الصور من نوع JPG/PNG
`.trim();

    // 🐦‍🔥 تفاعل مع الرسالة (إيموجي انتظار)
    const react = async (emoji) => {
        try {
            await conn.sendMessage(m.chat, {
                react: {
                    text: emoji,
                    key: m.key
                }
            });
        } catch (e) {
            console.error(e);
        }
    };

    await react('⏳');

    try {
        let q = m.quoted || m;
        let mime = (q.msg || q).mimetype || q.mimetype || q.mediaType || '';
        
        // 🐦‍🔥 التحقق من وجود صورة
        if (!mime) {
            const errorMsg = isArabicCommand 
                ? '⚠️ *يجب عليك إرسال أو الرد على صورة أولاً!*\n\n' + usageMessage
                : '⚠️ *Please send or reply to an image first!*\n\n' + usageMessage;
            throw errorMsg;
        }
        
        // 🐦‍🔥 التحقق من نوع الصورة
        if (!/image\/(jpe?g|png)/.test(mime)) {
            const errorMsg = isArabicCommand
                ? `⚠️ *نوع الملف غير مدعوم!*\nيجب أن تكون الصورة بصيغة JPG/PNG.`
                : `⚠️ *Unsupported file type!*\nOnly JPG/PNG images are supported.`;
            throw errorMsg;
        }

        // 🐦‍🔥 تحميل الصورة
        let img = await q.download?.();
        if (!img) {
            const errorMsg = isArabicCommand
                ? '❌ *فشل تحميل الصورة!*'
                : '❌ *Failed to download image!*';
            throw errorMsg;
        }

        // 🐦‍🔥 رفع الصورة إلى Catbox
        const imageUrl = await uploadToCatbox(img);
        if (!imageUrl.startsWith('https://')) {
            const errorMsg = isArabicCommand
                ? '❌ *حدث خطأ أثناء رفع الصورة!*'
                : '❌ *Error uploading image!*';
            throw errorMsg;
        }

        // 🐦‍🔥 تحسين الجودة باستخدام API
        const apiUrl = `https://zenz.biz.id/tools/remini?url=${encodeURIComponent(imageUrl)}`;
        const res = await fetch(apiUrl);
        if (!res.ok) {
            const errorMsg = isArabicCommand
                ? '❌ *حدث خطأ في تحسين الجودة!*'
                : '❌ *Error enhancing image quality!*';
            throw errorMsg;
        }

        const json = await res.json();
        if (!json.status || !json.result?.result_url) {
            const errorMsg = isArabicCommand
                ? '❌ *لا يمكن معالجة الصورة!*'
                : '❌ *Failed to process image!*';
            throw errorMsg;
        }

        // 🐦‍🔥 جلب الصورة المحسنة
        const enhancedImage = await fetch(json.result.result_url).then(v => v.buffer());

        // 🐦‍🔥 إرسال الصورة المحسنة
        await conn.sendMessage(m.chat, {
            image: enhancedImage,
            caption: isArabicCommand 
                ? '*🐦‍🔥 تم تحسين جودة الصورة بنجاح!*' 
                : '*🐦‍🔥 Image quality enhanced successfully!*',
        }, { quoted: m });

        await react('✅');

    } catch (e) {
        await react('❌');
        m.reply(typeof e === 'string' ? e : isArabicCommand ? '❌ حدث خطأ!' : '❌ An error occurred!');
    }
};

// 🐦‍🔥 دالة لرفع الصور إلى Catbox
async function uploadToCatbox(buffer) {
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', buffer, 'image.jpg');

    const res = await fetch('https://catbox.moe/user/api.php', {
        method: 'POST',
        body: form
    });

    return await res.text();
}

// 🐦‍🔥 الأوامر المتاحة
handler.help = ['hd', 'remini', 'جوده', 'جودة'];
handler.tags = ['tools'];
handler.command = /^(hd|remini|جوده|جودة)$/i;

// 🐦‍🔥 توقيع البوت
handler.footer = '𝐄𝐋 𝐏𝐎𝐏 𝑩𝑶𝑻 𝚅¹ 🐦‍🔥';

export default handler;