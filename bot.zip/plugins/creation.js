// استيراد المكتبات (السيرفر سيتعرف عليها لأنها موجودة في ملفك)
import moment from 'moment-timezone';

let handler = async (m, { conn, usedPrefix, command }) => {
    // 1. التحقق من أن الأمر أُرسل في مجموعة
    if (!m.isGroup) return m.reply('⚠️ هذا الأمر مخصص للمجموعات فقط.');

    try {
        // 2. جلب بيانات المجموعة من السيرفر باستخدام مكتبة Baileys
        const groupMetadata = await conn.groupMetadata(m.chat);
        
        // 3. استخراج وتحويل تاريخ التأسيس
        // نستخدم 1000 لأن التاريخ يأتي بصيغة Unix Seconds والسيرفر يحتاجه بـ Milliseconds
        const creationTimestamp = groupMetadata.creation * 1000;
        
        // تنسيق التاريخ باللغة العربية (توقيت القاهرة)
        const dateCreated = moment(creationTimestamp).tz('Africa/Cairo').format('DD/MM/YYYY');
        const timeCreated = moment(creationTimestamp).tz('Africa/Cairo').format('hh:mm A');

        // 4. صياغة الرسالة النهائية بشكل منسق
        let info = `📊 *بيانات البار (المجموعة)*\n\n`;
        info += `📝 *الاسم:* ${groupMetadata.subject}\n`;
        info += `📅 *تاريخ التأسيس:* ${dateCreated}\n`;
        info += `⏰ *وقت التأسيس:* ${timeCreated}\n`;
        info += `👑 *المنشئ:* @${groupMetadata.owner ? groupMetadata.owner.split('@')[0] : 'غير معروف'}\n`;
        info += `👥 *عدد الأعضاء:* ${groupMetadata.participants.length}\n\n`;
        info += `🔗 *المعرف:* ${groupMetadata.id}`;

        // إرسال الرد مع تفعيل التاج (Mention) للمالك
        await conn.reply(m.chat, info, m, {
            mentions: groupMetadata.owner ? [groupMetadata.owner] : []
        });

    } catch (err) {
        // توثيق الخطأ في وحدة التحكم بالسيرفر (Console)
        console.error('Error fetching group metadata:', err);
        m.reply('❌ حدث خطأ برمجبي أثناء محاولة جلب البيانات.');
    }
};

// إعدادات تشغيل الأمر
handler.help = ['تاريخ_الإنشاء'];
handler.tags = ['group'];
handler.command = /^(تاريخ|انشاء|التأسيس)$/i; // الكلمات التي تشغل الأمر

export default handler;