import pkg from '@whiskeysockets/baileys'
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg

import { canLevelUp, xpRange } from '../lib/levelling.js'

function clockString(ms) {
  if (isNaN(ms)) return '00:00'
  let h = Math.floor(ms / 3600000)
  let m = Math.floor((ms % 3600000) / 60000)
  let s = Math.floor((ms % 60000) / 1000)
  return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':')
}

const handler = async (m, { conn }) => {
  try {
    await conn.sendMessage(m.chat, { react: { text: '🍫', key: m.key } })

    let uptime = clockString(process.uptime() * 1000)
    let user = global.db?.data?.users?.[m.sender] || { level: 0, exp: 0, limit: 10, premium: false, role: '𝐄𝐋 𝐏𝐎𝐏 𝙱𝙾𝚃' }

    let level = user.level || 0  
    let role = user.role || '𝐄𝐋 𝐏𝐎𝐏 𝙱𝙾𝚃' 
    let exp = user.exp || 0  
    let limit = user.limit || 0  
    let isPrems = user.premium || false  
    let rtotalreg = Object.keys(global.db?.data?.users || {}).length  

    let range = xpRange(level, global.multiplier)
    let xpLeft = range.max - exp
    if (xpLeft < 0) xpLeft = 0

    const daysArabic = { 'Sunday': 'الأحد', 'Monday': 'الإثنين', 'Tuesday': 'الثلاثاء', 'Wednesday': 'الأربعاء', 'Thursday': 'الخميس', 'Friday': 'الجمعة', 'Saturday': 'السبت' }
    let dayName = daysArabic[new Date().toLocaleDateString('en-US', { weekday: 'long' })] || 'غير معروف'

    const Elsony = 'https://files.catbox.moe/wfs4py.jpeg'  
    const media = await prepareWAMessageMedia({ image: { url: Elsony } }, { upload: conn.waUploadToServer })  

    const sections = [  
      { emoji: '🚀', title: 'قسم البحث والتنزيل', id: '.قسم-البحث' },
      { emoji: '🎮', title: 'قسم الألعاب والفعاليات', id: '.قسم-فعاليات' },
      { emoji: '🎭', title: 'قسم الترفيه والتسلية', id: '.قسم-الترفيه' },
      { emoji: '💻', title: 'قسم البرمجة والمطورين', id: '.قسم-برمجه' },
      { emoji: '⭐', title: 'قسم الدول والإطارات', id: '.قسم-دول' },
      { emoji: '💬', title: 'قسم المجموعات والجروب', id: '.قسم-جروب' },
      { emoji: '📲', title: 'قسم التحميلات المباشرة', id: '.قسم-التحميلات' },
      { emoji: '🔊', title: 'قسم الصوتيات والمقاطع', id: '.قسم-صوتيات' },
      { emoji: '🛠️', title: 'قسم الأدوات المساعدة', id: '.قسم-الادوات' },
      { emoji: '📿', title: 'قسم الدين الإسلامي', id: '.قسم-الدين' },
      { emoji: '📰', title: 'قسم الأخبار والتواصل', id: '.قسم-بحثث' },
      { emoji: '🤖', title: 'قسم الذكاء الاصطناعي', id: '.قسم-الذكاء' },
      { emoji: '👑', title: 'قسم ألعاب التسلية', id: '.ق1' },
      { emoji: '💀', title: 'قسم إدارة المشرفين', id: '.ق3' },
      { emoji: '🛠️', title: 'قسم الأدوات الإضافية', id: '.ق4' },
      { emoji: '🛡️', title: 'قسم التحميلات الفرعي', id: '.ق5' },
      { emoji: '🕹️', title: 'قسم البنك والمحفظة', id: '.ق6' },
      { emoji: '🌀', title: 'قسم الذكاء الاصطناعي AI', id: '.ق7' },
      { emoji: '🎭', title: 'قسم التسلية والمرح', id: '.ق9' },
      { emoji: '🕋', title: 'قسم الدين والقرآن', id: '.ق10' },
      { emoji: '🖌️', title: 'قسم الزخارف والنصوص', id: '.ق11' },
      { emoji: '⚔️', title: 'قسم النقابات والحروب', id: '.ق12' },
      { emoji: '🗾', title: 'قسم الصور والخلفيات', id: '.ق13' },
      { emoji: '📜', title: 'قسم القوانين الرسمية', id: '.القواعد' }
    ].map(s => ({  
      title: `⎔⋅• ──〔🍫 𝐄𝐋 𝐏𝐎𝐏 𝙱𝙾𝚃 🍫 〕── •⋅⎔\n⥍ ➟ ${s.emoji} ${s.title}\n⎔⋅• ──────────────── •⋅⎔`,  
      highlight_label: '🍫 𝐄𝐋 𝐏𝐎𝐏 𝙱𝙾𝚃 🍫',  
      rows: [{ header: s.emoji, title: `⸂ ⚕️ ${s.title} 🍫 ⸃`, id: s.id }]  
    }))  

    const extraSections = [
      { emoji: '🤖', title: 'بوت فرعي (تنصيب)', id: '.تنصيب' }, { emoji: '📶', title: 'بنج البوت (سرعة)', id: '.بنج' },
      { emoji: '🌟', title: 'تقييم أداء البوت', id: '.تقيم' }, { emoji: '👨‍💻', title: 'مطور البوت الرئيسي', id: '.المطور' },
      { emoji: '💬', title: 'شراء السورس أو البوت', id: '.شراء' }
    ].map(s => ({
      title: `⎔⋅• ──〔 🍫 𝚂𝙰𝚃𝙾 𝙱𝙾𝚃 🍫 〕── •⋅⎔\n⥍ ➟ ${s.emoji} ${s.title}\n⎔⋅• ──────────────── •⋅⎔`,
      highlight_label: '🍫 𝚂𝙰𝚃𝙾 𝙱𝙾𝚃 🍫',
      rows: [{ header: s.emoji, title: `⸂ ⚕️ ${s.title} 🍫 ⸃`, id: s.id }]
    }))

    const buttons = [  
      { name: 'single_select', buttonParamsJson: JSON.stringify({ title: '﹝ قائمة الأوامر الرئيسية ﹞', sections }) },  
      { name: 'single_select', buttonParamsJson: JSON.stringify({ title: '﹝ قسم الـمـعـلـومـات ﹞', sections: extraSections }) },  
      { name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: "﹝ قـنـاة الـبـوت ﹞", url: "https://whatsapp.com/channel/0029Vb83VLS9mrGeH1iPbH30u" }) },
      { name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: "﹝ تـواصـل مـع الـمـطـوّر ﹞", url: "https://wa.me/201015115056" }) }
    ]

    const text = `
*✧━━━━━[⤿ 🍫 مـرحـبـاً بـك 🍫 ⤾]━━━━━╮*
> *┤ ⚡ أهلاً بك يا : @${m.sender.split('@')[0]}*

> *┤ اختاࢪ الاقسام بل اسفل 😍♥*

> *┤ 🩸 الـمـطـوّر : 𝐁𝐄𝐋𝐀𝐋 ⦓ 𝐊 ⦔ 𝐁𝐎𝐃𝐑𝐀𝐆𝐄𝐀*
> *┤ 🔮 الـبـوت :* *🍫 𝐄𝐋 𝐏𝐎𝐏 𝙱𝙾𝚃 🍫*
> *┤ 🔋 الـتـشـغـيـل : ${uptime}*
> *┤ 👥 الـمـسـتـخـدمـيـن : ${rtotalreg}*

> *𝐄𝐋 𝐏𝐎𝐏 𝙱𝙾𝚃*

*✧━━━━━[ ⏱️ الـوقـت والـتـحـديـث ]━━━━━╮*
> *┤ 🗓️ الـتـاريـخ : ${new Date().toLocaleDateString('en-GB')}*
> *┤ 📆 الـيـوم : ${dayName}*
*╯──────────────────···*


*THE OŁD FATER DARK $ -*`

    const msg = generateWAMessageFromContent(m.chat, {  
      viewOnceMessage: {  
        message: {  
          messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },  
          interactiveMessage: proto.Message.InteractiveMessage.create({  
            header: proto.Message.InteractiveMessage.Header.create({ title: '', hasMediaAttachment: true, ...media }),  
            body: proto.Message.InteractiveMessage.Body.create({ text }),  
            footer: proto.Message.InteractiveMessage.Footer.create({ text: "🍫 𝚂𝙰𝚃𝙾 𝙱𝙾𝚃 🍫" }),  
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons })  
          })  
        }  
      }  
    }, { userJid: m.sender })  

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

  } catch (e) {
    console.error(e)
  }
}

handler.help = ['menu']
handler.tags = ['main']
handler.command = ['menu', 'الاوامر', 'القائمة', 'اوامر', 'مهام']

export default handler