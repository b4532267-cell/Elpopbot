// م࣬ــࢪحہּٰـبٚأ بٚـڪٰٖ فَــي أوٰأم࣬ـࢪ 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓 ؍ 🌸♡゙ ُ𓂁
// أوٰأم࣬ــࢪ م࣬ٺم࣬يــژۿ . ⊹
// حہּٰقَــــوٰقَ 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓 🐦☕
// أسٰـم࣬ أݪأم࣬ــࢪ شغل.js
// ࢪأبٚــطَ قَنٰــأۿ أݪم࣬ــطَــوٰࢪ ..)✘🖤🧸.
// https://whatsapp.com/channel/0029VbCS3Q34SpkER26xwJ3u

import yts from 'yt-search';
import axios from 'axios';

// استيراد بايلز المتوافق مع نسخة البوت
const { generateWAMessageContent, generateWAMessageFromContent, proto } = (await import("@whiskeysockets/baileys")).default;

const myCredit = `*_ .𓏲⋆˙ 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 𓏲⋆˙ _*`;
const emojis = `🌳🌴🍀 🍍🌿🍇 🍉`;

function secondString(sec) {
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    return `${h ? h + " ساعة " : ""}${m ? m + " دقيقة " : ""}${s ? s + " ثانية" : ""}`.trim();
}

function MilesNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

// دالة إرسال الرسالة التفاعلية المدمجة لـ SATO BOT باستخدام كفر الفيديو المباشر
async function sendCombinedMessage(conn, chatId, video, results, usedPrefix, quoted) {
    // جلب صورة كفر الأغنية كـ Buffer مباشرة بدون استهلاك بروسيسور أو رام
    const response = await axios.get(video.thumbnail, { responseType: 'arraybuffer' });
    const coverBuffer = Buffer.from(response.data);

    const { imageMessage } = await generateWAMessageContent(
        { image: coverBuffer },
        { upload: conn.waUploadToServer }
    );

    // ربط الأزرار مع أوامر يوتيوب الافتراضية في سكريبت Michi (ytmp3 / ytmp4)
    const sections = [  
        {  
            title: '🎵 تحميل صوت (MP3)',  
            rows: results.map(v => ({  
                title: v.title,  
                description: `⏱ ${v.timestamp} | 📺 ${v.author.name}`,  
                id: `${usedPrefix}ytmp3 ${v.url}`  
            }))  
        },  
        {  
            title: '🎬 تحميل فيديو (MP4)',  
            rows: results.map(v => ({  
                title: v.title,  
                description: `⏱ ${v.timestamp} | 📺 ${v.author.name}`,  
                id: `${usedPrefix}ytmp4 ${v.url}`  
            }))  
        }  
    ];  

    const caption = `🎵 *معلومات الأغنية* 🎵\n\n` +  
        `🎬 *العنوان:* ${video.title}\n` +  
        `📺 *القناة:* ${video.author.name}\n` +  
        `⏱️ *المدة:* ${secondString(video.duration.seconds)}\n` +  
        `📅 *تاريخ النشر:* ${video.ago}\n` +  
        `👁️ *المشاهدات:* ${MilesNumber(video.views)}\n` +  
        `🔗 *الرابط:* ${video.url}\n\n` +  
        `${myCredit}\n${emojis}`;  

    const interactiveMessage = proto.Message.InteractiveMessage.fromObject({  
        body: proto.Message.InteractiveMessage.Body.fromObject({  
            text: caption  
        }),  
        footer: proto.Message.InteractiveMessage.Footer.fromObject({  
            text: "يـوٰٺـيوٰبٚ 𓆩 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 𓆪"  
        }),  
        header: proto.Message.InteractiveMessage.Header.fromObject({  
            hasMediaAttachment: true,  
            imageMessage: imageMessage  
        }),  
        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({  
            buttons: [  
                {  
                    name: 'single_select',  
                    buttonParamsJson: JSON.stringify({ title: '📥 خيارات التحميل', sections })  
                },  
                {  
                    name: "cta_url",  
                    buttonParamsJson: JSON.stringify({  
                        display_text: ".𓏲⋆˙ 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 𓏲⋆˙",  
                        url: "https://whatsapp.com/channel/0029Vb83VLS9mrGeH1iPbH30"  
                    })  
                }  
            ]  
        })  
    });  

    const msg = generateWAMessageFromContent(chatId, {  
        viewOnceMessage: { message: { interactiveMessage } }  
    }, { userJid: conn.user.jid, quoted });  

    await conn.relayMessage(chatId, msg.message, { messageId: msg.key.id });
}

const handler = async (m, { conn, text, usedPrefix }) => {
    if (!text) {
        return m.reply(`∘₊✧──────🌹──────✧₊∘\n┊ ⚠️ *يرجى إدخال نص أو رابط للبحث*\n∘₊✧──────🌹──────✧₊∘`);
    }

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });  

    try {  
        let query = text.trim();  
        const yt_play = await yts.search(query);  
        if (!yt_play.videos.length) throw 'لا يوجد نتائج';  

        const video = yt_play.videos[0];  
        const results = yt_play.videos.slice(0, 10);  

        // استدعاء دالة الإرسال الخفيفة بدون الحاجة للـ Canvas
        await sendCombinedMessage(conn, m.chat, video, results, usedPrefix, m);  

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });  
    } catch (e) {  
        console.error(e);  
        m.reply(`❌ حدث خطأ أثناء المعالجة.`);  
    }
};

handler.command = /^(شغل)$/i;
handler.tags = ['search'];
export default handler;