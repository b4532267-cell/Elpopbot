let handler = async (m) => {

  const text = m.text?.toLowerCase()
  if (!text) return

  // الكلمة اللي البوت هيرد عليها
  if (!/^(بوتت|بوت)$/i.test(text)) return

  const replies = [
    "> *ما قولنا شغال 🐤✨*",
    "> *معاك ي قلب البوت 🐤✨*"
  ]

  // اختيار رد عشوائي
  const reply = replies[Math.floor(Math.random() * replies.length)]

  await m.conn.sendMessage(m.chat, {
    text: reply,
    contextInfo: {
      isForwarded: true,
      forwardingScore: 999,
      forwardedNewsletterMessageInfo: {
        newsletterJid: '120363407666513777@newsletter',
        newsletterName: '𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻',
        serverMessageId: 100
      }
    }
  }, { quoted: m })
}

handler.customPrefix = /^(بوتت|بوت)$/i
handler.command = new RegExp
handler.exp = 0

export default handler