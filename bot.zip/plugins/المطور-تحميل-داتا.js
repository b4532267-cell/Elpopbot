import fs from 'fs'

// 👻 قائمة الأرقام المسموح لها فقط
const allowedNumbers = [
  '966567158348@s.whatsapp.net', // الرقم الأول
  '201015115056@s.whatsapp.net'  // الرقم الثاني
]

let handler = async (m, { conn, command, usedPrefix }) => {

  // 👻 التحقق من الرقم المسموح
  if (!allowedNumbers.includes(m.sender)) {
    return m.reply('🚫 👻 هذا الرقم غير مسموح له باستخدام هذا الأمر.\n👻 اتصل بالمالك إذا كنت تريد الوصول.\n\n𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻 👻')
  }

  // 👻 التحقق من وجود نص إضافي (لشرح الاستخدام)
  if (!command) {
    let example = `${usedPrefix}getdb`
    let explain = `👻 لتنزيل نسخة من قاعدة بيانات البوت، استخدم الأمر هكذا:\nمثال: ${example}\n👻 فقط للأرقام المسموح لها.\n\n𝑺𝑨𝑻𝑶 | 𝑩𝑶𝑻 👻`
    return m.reply(explain)
  }

  // 👻 إخطار المستخدم بالانتظار
  m.reply('👻 انتظر قليلاً، جارٍ تحميل ملف قاعدة البيانات...\n𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻👻')

  try {
    let sesi = fs.readFileSync('./database.json')
    await conn.sendMessage(
      m.chat, 
      { document: sesi, mimetype: 'application/json', fileName: 'database.json' }, 
      { quoted: m }
    )
  } catch (e) {
    m.reply(`❌ 👻 حدث خطأ أثناء تحميل الملف: ${e.message}\n𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻 👻`)
  }
}

handler.help = ['getdb', 'تحميل-داتا']
handler.tags = ['owner']
handler.command = /^(getdb|تحميل-داتا)$/i
handler.mods = true

export default handler