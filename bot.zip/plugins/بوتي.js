// قائمة أرقام المطورين المصرح لهم باستخدام الأمر
const developers = [
  '966567158348',
  '201015115056',
  '201505601859'
];

let handler = async (m, { conn }) => {

  // استخراج الرقم من معرف المرسل
  const sender = m.sender.split('@')[0];

  // التحقق: إذا لم يكن المرسل مطوراً، يتوقف البوت عن الرد
  if (!developers.includes(sender)) return;

  // نص الرسالة
  let teks = `*مطوري 😗*`;

  // إرسال الرسالة مع تزييف حالة التوجيه من القناة الرسمية
  await conn.sendMessage(m.chat, {
    text: teks,
    mentions: [m.sender],
    contextInfo: {
      forwardingScore: 999, // لإظهار علامة "محولة"
      isForwarded: true,    // تفعيل خاصية التوجيه
      forwardedNewsletterMessageInfo: {
        newsletterJid: '120363407666513777@newsletter', // معرف قناتك الخاص
        serverMessageId: 143,
        newsletterName: '𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻' // اسم القناة الذي سيظهر فوق الرسالة
      }
    }
  }, { quoted: m });

};

// تشغيل الأمر عند كتابة "بوتي" (يدعم الحروف الكبيرة والصغيرة)
handler.customPrefix = /بوتي/i;
handler.command = new RegExp;

export default handler;