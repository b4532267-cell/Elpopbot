//𝐊𝐄𝐌𝐎! ⦓ 𝐊 ⦔ 𝐁𝐎𝐃𝐑𝐀𝐆𝐄𝐀 🇮🇱 )): 
// https://whatsapp.com/channel/0029VbCS3Q34SpkER26xwJ3u

import axios from 'axios';
import yts from 'yt-search';
import pkg from '@whiskeysockets/baileys';
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg;

// الإعدادات والخلفية
const myCredit = `*_ .𓏲⋆˙𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓🎀 _*`;

// الزخارف المطلوبة
const startDeco = `☽⚝ͫ͢❏ِꏍ🍡﴿ۦٕۛ۬٭ۦٕۛ۬❏ِ ﷽⎆☽⚝ͫ͢❏ِ🍡ꏍﭕ﴿ۦٕۛ۬٭ۦٕۛ۬❏ِ\n╮ ⊰✫⊱─⊰✫⊱─⊰✫⊱╭`;
const endDeco = `┘⊰✫⊱─⊰✫⊱─⊰✫⊱└\n☽⚝ͫ͢❏ِꏍ🍡﴿ۦٕۛ۬٭ۦٕۛ۬❏ِ ﷽⎆☽⚝ͫ͢❏ِꏍﭕ🍡﴿ۦٕۛ۬٭ۦٕۛ۬❏ِ`;

/* ========= دالة جهة الاتصال (Quote) ========= */
function contactQuote(m) {
  return {
    key: { participants: '0@s.whatsapp.net', remoteJid: 'status@broadcast', fromMe: false, id: 'HULK' },
    message: {
      contactMessage: {
        displayName: m.pushName || 'Unknown',
        vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${m.pushName || 'User'};;;;\nFN:${m.pushName || 'User'}\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:📞 WhatsApp\nORG:HULK BOT ✓\nTITLE:Verified\nEND:VCARD`
      }
    },
    participant: '0@s.whatsapp.net'
  };
}

const handler = async (m, { conn, usedPrefix, command, text }) => {
  const fkontak = contactQuote(m);
  
  if (!text) {
    return conn.reply(m.chat, `${startDeco}\n\nيرجى كتابة اسم الفيديو للبحث على YouTube.\n\nمثال: \`${usedPrefix + command} اغنية حزينة\`\n\n${endDeco}`, fkontak);
  }

  await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

  try {
    const results = await yts(text);
    const videos = results.videos.slice(0, 10);

    if (!videos.length) {
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
        return conn.reply(m.chat, `${startDeco}\n\nلم يتم العثور على أي نتائج!\n\n${endDeco}`, fkontak);
    }

    const firstVideo = videos[0];

    // جلب الصورة المصغرة للفيديو كـ Buffer بدلاً من استخدام canvas
    const response = await axios.get(firstVideo.thumbnail, { responseType: 'arraybuffer' });
    const imageBuffer = Buffer.from(response.data);

    const media = await prepareWAMessageMedia(
        { image: imageBuffer },
        { upload: conn.waUploadToServer }
    );

    const sections = videos.map(video => ({
        title: video.title,
        rows: [
        {
            title: `🎵 تحميل صوت | المدة: ${video.timestamp}`,
            description: `الناشر: ${video.author.name}`,
            id: `${usedPrefix}صوت ${video.url}`
        },
        {
            title: `🎬 تحميل فيديو | المدة: ${video.timestamp}`,
            description: `الناشر: ${video.author.name}`,
            id: `${usedPrefix}فيديو ${video.url}`
        }
        ]
    }));

    const interactiveMessage = {
        body: {
        text: `${startDeco}\n\nتم العثور على: \`${videos.length}\` نتيجة\n\nالعنوان: \`${firstVideo.title}\`\n\n${endDeco}`
        },
        footer: { text: '.𓏲⋆˙𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓🎀' },
        header: {
        title: '```🍉 نتائج البحث في YouTube```',
        hasMediaAttachment: true,
        imageMessage: media.imageMessage
        },
        nativeFlowMessage: {
        buttons: [
            {
            name: 'single_select',
            buttonParamsJson: JSON.stringify({
                title: '🍷️ خيارات التحميل',
                sections: sections
            })
            }
        ]
        }
    };

    const userJid = conn?.user?.jid || m.key.participant || m.chat;
    const msg = generateWAMessageFromContent(m.chat, { interactiveMessage }, { userJid, quoted: fkontak });
    
    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (error) {
      console.error(error);
      m.reply('حدث خطأ أثناء معالجة البحث.');
  }
};

handler.help = ['يوتيوب <الاسم>'];
handler.tags = ['search'];
handler.command = ['يوتيوب'];

export default handler;