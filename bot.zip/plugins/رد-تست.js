let handler = async (m) => {

  const text = m.text?.toLowerCase()
  if (!text) return

  // الكلمة اللي البوت هيرد عليها
  if (!/^(تصتو|تست)$/i.test(text)) return

  const replies = [
    "> *شـــغال يا قـــلـــب 𝐁𝐄𝐋𝐀𝐋 🤭♥*",
    "> *شـــغـــال يـــقــلـبـــي 🐤💋*"
  ]

  // اختيار رد عشوائي
  const reply = replies[Math.floor(Math.random() * replies.length)]

  await m.conn.sendMessage(m.chat, {
    text: reply,
    contextInfo: {
      isForwarded: true,
      forwardingScore: 999,
      forwardedNewsletterMessageInfo: {
        newsletterJid: '120363407666513777@newsletter',
        newsletterName: '𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓',
        serverMessageId: 100
      }
    }
  }, { quoted: m })
}

handler.customPrefix = /^(تست)$/i
handler.command = new RegExp
handler.exp = 0

export default handler