import axios from "axios";
import crypto from "crypto";

const spotifyTrackDownloader = async (spotifyTrackUrl) => {
  const client = new axios.create({
    baseURL: "https://spotisongdownloader.to",
    headers: {
      "Accept-Encoding": "gzip, deflate, br",
      cookie: `PHPSESSID=${crypto.randomBytes(16).toString("hex")}; _ga=GA1.1.2675401.${Math.floor(
        Date.now() / 1000
      )}`,
      referer: "https://spotisongdownloader.to",
      "Content-Type": "application/x-www-form-urlencoded",
    },
  });
  const { data: meta } = await client.get("/api/composer/spotify/xsingle_track.php", {
    params: { url: spotifyTrackUrl },
  });
  await client.post("/track.php");
  const { data: dl } = await client.post("/api/composer/spotify/ssdw23456ytrfds.php", {
    url: spotifyTrackUrl,
    zip_download: "false",
    quality: "m4a",
  });
  return { ...dl, ...meta };
};

let handler = async (m, { conn, args, usedPrefix, command, isOwner }) => {
  try {
    // الرسالة التوضيحية بناءً على اسم الأمر المستخدم
    const commandName = command === "spotify" ? "سبوتيفاي" : "Spotify";
    const commandExample = `${usedPrefix}${command} https://open.spotify.com/track/5ljSDO6UpH02bQllrMR4Al?si=FTVovKgRQf6kXt_04eNCAA`;

    // التوضيح للمستخدم
    const usageText = `
*👻 كيف تستخدم هذا الأمر؟*
1. قم بإرسال رابط أغنية سبوتيفاي.
2. ستحصل على معلومات عن الأغنية مثل اسمها والفنان والألبوم.
3. سيتم إرسال الرابط المباشر لتحميل الأغنية.

*👻 مثال:*
📌 *${commandExample}*`;

    // إذا لم يتم تقديم رابط، نقوم بإرجاع توضيح للمستخدم
    if (!args[0]) {
      return m.reply(usageText);
    }

    let result = await spotifyTrackDownloader(args[0]);
    let text = `*${result.song_name}* 👻
    
*👻 الفنان :* ${result.artist}
*👻 الألبوم :* ${result.album_name}
*👻 المدة :* ${result.duration}
*👻 الإصدار :* ${result.released}
*👻 الرابط :* ${result.url}
    
> *👻 انتظر، جاري إرسال الأغنية...*`;

    // إرسال المعلومات للمستخدم مع الصورة إذا كانت موجودة
    if (result.img) {
      await conn.sendMessage(m.chat, { image: { url: result.img }, caption: text }, { quoted: m });
    } else {
      await m.reply(text);
    }

    // إرسال الأغنية للمستخدم
    await conn.sendMessage(m.chat, { audio: { url: result.dlink }, mimetype: "audio/mpeg" }, { quoted: m });
  } catch (e) {
    m.reply(`👻 حدث خطأ أثناء معالجة الطلب: ${e.message}`);
  }
};

handler.help = ["spotify", "سبوتيفاي"]; // إضافة الأمرين بالعربية والإنجليزية
handler.command = ["spotify", "سبوتيفاي"]; // إضافة الأمرين بالعربية والإنجليزية
handler.tags = ["downloader"];
export default handler;