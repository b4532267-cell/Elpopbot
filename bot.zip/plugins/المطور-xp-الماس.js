let handler = async (m, { conn, command, text }) => {
  const pajak = 0;
  let who;
  if (m.isGroup) who = m.mentionedJid[0];
  else who = m.chat;
  if (!who) return m.reply(`🐦‍🔥 من فضلك قم بعمل منشن للمستخدم الذي تريد منحه النقاط أو الماس.\n\nمثال:\n.الماس @رقم 50\n𝑺𝑨𝑻𝑶 | 𝑩𝑶𝑻`);
  
  const txt = text.replace('@' + who.split`@`[0], '').trim();
  if (!txt) return m.reply(`🐦‍🔥 من فضلك أضف الكمية التي تريد تحويلها.\n\nمثال:\n.xp @رقم 100\n𝑺𝑨𝑻𝑶 | 𝑩𝑶𝑻¹🐦‍🔥`);
  if (isNaN(txt)) return m.reply(`🐦‍🔥 أدخل رقمًا صحيحًا فقط، دون رموز أو حروف.\n𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻¹🐦‍🔥`);

  const value = parseInt(txt);
  const pjk = Math.ceil(value * pajak);
  const total = value + pjk;
  if (total < 1) return;

  const users = global.db.data.users;

  if (command === 'addxp' || command === 'añadirxp' || command === 'xp' || command === 'اضف-xp') {
    users[who].exp += value;
    m.reply(`🐦‍🔥 تمت إضافة نقاط خبرة بنجاح:
≡ *إجمالي نقاط الخبرة: ${value}*
𝑺𝑨𝑻𝑶 | 𝑩𝑶𝑻¹🐦‍🔥`);
  }

  if (command === 'addlimit' || command === 'añadirdiamantes' || command === 'dardiamantes' || command === 'الماس') {
    users[who].limit += value;
    m.reply(`🐦‍🔥 تمت إضافة الماس بنجاح:
≡ *إجمالي الماس: ${value}*
𝑺𝑨𝑻𝑶 | 𝑩𝑶𝑻 𝚅¹🐦‍🔥`);
  }
}

handler.help = ['addxp', 'addlimit', 'xp', 'الماس', 'اضف-xp']
handler.tags = ['owner']
handler.command = /^(addxp|añadirxp|xp|اضف-xp|addlimit|añadirdiamantes|dardiamantes|الماس)$/i
handler.owner = true
handler.register = true

export default handler