import fs from 'fs';
import path from 'path';

const allowedNumbers = ['966567158348@s.whatsapp.net', '201015115056@s.whatsapp.net'];

const yourChannelLink = 'https://whatsapp.com/channel/0029Vb5Vczr7j6g3foFrXM2x';

const handler = async (m, { conn }) => {
  if (!allowedNumbers.includes(m.sender)) {
    await conn.sendMessage(m.chat, {
      text: `🚫 هذا الأمر مخصص للمطور فقط.`,
    }, { quoted: m });
    return;
  }

  const basePath = 'plugins';
  const files = fs.readdirSync(basePath).filter(file => file.endsWith('.js'));
  let changedFiles = 0;
  let totalReplaced = 0;
  let errors = [];

  // regex لروابط قنوات واتساب
  const channelRegex = /https?:\/\/whatsapp\.com\/channel\/[a-zA-Z0-9]+/gi;

  for (let file of files) {
    const filePath = path.join(basePath, file);
    try {
      let content = fs.readFileSync(filePath, 'utf-8');
      const matches = [...content.matchAll(channelRegex)];

      if (matches.length > 0) {
        totalReplaced += matches.length;
        const newContent = content.replace(channelRegex, yourChannelLink);
        fs.writeFileSync(filePath, newContent, 'utf-8');
        changedFiles++;
      }
    } catch (err) {
      errors.push({ file, error: err.message });
    }
  }

  let message = `✅ تم استبدال روابط القنوات في ${changedFiles} ملف.\n🔁 عدد الروابط التي تم تغييرها: ${totalReplaced}`;
  if (errors.length > 0) {
    message += `\n⚠️ حصلت أخطاء في الملفات التالية:\n`;
    errors.forEach(({ file, error }) => {
      message += `- ${file}: ${error}\n`;
    });
  }

  await conn.sendMessage(m.chat, { text: message }, { quoted: m });
};

handler.help = ['بدل-قناة'];
handler.tags = ['owner'];
handler.command = /^بدل-قناة$/i;
handler.owner = true;

export default handler;