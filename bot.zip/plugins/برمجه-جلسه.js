//كود عمل جلسة
//مصدر السكراب: https://whatsapp.com/channel/0029Vb5Vczr7j6g3foFrXM2x
import axios from 'axios';
import fs from 'fs';

let pendingCodes = {};

const handler = async (m, { conn, text }) => {
    if (!text) {
        return conn.reply(m.chat, '❗ *أدخل رقم الهاتف الدولي بدون "+" أو مسافات*\nمثال: جلسه 201284211604', m);
    }

    // تحقق من أن النص عبارة عن رقم دولي صالح فقط
    if (/^\d{9,15}$/.test(text)) {
        try {
            let res = await axios.get(`https://knight-bot-paircode.onrender.com/code?number=${text}`);
            let code = res.data?.code;
            //مصدر api https://whatsapp.com/channel/0029Vb5Vczr7j6g3foFrXM2x/3904
            if (!code) return conn.reply(m.chat, '❌ لم يتم إرسال الرمز، حاول لاحقاً', m);

            pendingCodes[m.sender] = code;
            return conn.reply(m.chat, `${code}`, m); // إرسال الرمز فقط بدون أي نص

        } catch (e) {
            return conn.reply(m.chat, '❌ حدث خطأ أثناء الاتصال بالخادم، حاول لاحقاً', m);
        }
    }

    // التحقق من الرمز
    if (pendingCodes[m.sender]) {
        if (text === pendingCodes[m.sender]) {
            delete pendingCodes[m.sender];
            return conn.sendMessage(m.chat, {
                document: fs.readFileSync('./sussycode.json'),
                fileName: 'session.json',
                mimetype: 'application/json',
                caption: '✅ تم إنشاء الجلسة بنجاح'
            }, { quoted: m });
        } else {
            delete pendingCodes[m.sender];
            return conn.reply(m.chat, '❌ الرمز غير صحيح، يرجى البدء من جديد.', m);
        }
    }

    return conn.reply(m.chat, '❗ رقم غير صالح\n📌 يجب أن يكون الرقم الدولي مكوّن من 9 إلى 15 رقمًا مثل:\n201284211604', m);
};

handler.command = /^(جلسه|جلسة|سيسيو|ربط|session|sess|sessio|link|connect)$/i;
export default handler;
//مصدر الكود تائب🐦‍🔥: https://whatsapp.com/channel/0029Vb5Vczr7j6g3foFrXM2x