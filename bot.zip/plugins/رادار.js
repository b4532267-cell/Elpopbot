// plugins/رادار.js
// ⧼ 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓 ⧽ — رصد تغييرات المجموعة 🔍
// 𝐊𝐄𝐌𝐎! ⦓ 𝐊 ⦔ 𝐁𝐎𝐃𝐑𝐀𝐆𝐄𝐀

import { theme } from '../core/theme.js'

// ══════════════════════════════════════════════
// 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓 ✦ حقوق محفوظة لـ KEMO! ⦓ K ⦔ BODRAGEA
// ══════════════════════════════════════════════

const lidCache = new Map()

// ═══════════════════════════════
// معالج أحداث المجموعة (before)
// ═══════════════════════════════
const handler = m => m

handler.before = async function (m, { conn }) {
    if (!m.messageStubType || !m.isGroup) return true

    const chat = global.db.data.chats[m.chat]
    if (!chat?.detect) return true

    const users = m.messageStubParameters?.[0]
    const usuario = await resolveLidToRealJid(m?.sender, conn, m?.chat)

    const fuser = `@${usuario.split('@')[0]}`
    const tuser = users ? `@${users.split('@')[0]}` : ''

    let mentions = [usuario]
    if (users) mentions.push(users)

    const contextInfo = {
        mentionedJid: mentions,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: global.idcanal || '120363424951931854@newsletter',
            newsletterName: global.namecanal || '𝐒𝐀𝐓𝐎 𝐁𝐎𝐓',
            serverMessageId: ''
        }
    }

    let txt = ''

    // ══ تغييرات الإعدادات ══
    if (m.messageStubType == 21)
        txt = theme.build([
            { type: 'title',    text: '⚙️ تـغـيـيـر اسـم الـمـجـمـوُعـة' },
            { type: 'info',     label: '👤 بواسطة', value: fuser },
            { type: 'info',     label: '📝 الاسم الجديد', value: m.messageStubParameters[0] },
            { type: 'divider' },
            { type: 'line',     text: '> 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ✦ 𝐁𝐄𝐋𝐀𝐋! ⦓ 𝐊 ⦔' }
        ])

    else if (m.messageStubType == 24)
        txt = theme.build([
            { type: 'title',    text: '⚙️ تـغـيـيـر وُصـف الـمـجـمـوُعـة' },
            { type: 'info',     label: '👤 بواسطة', value: fuser },
            { type: 'info',     label: '📝 الوصف الجديد', value: m.messageStubParameters[0] || 'تـم حـذِف الـوُصـف' },
            { type: 'divider' },
            { type: 'line',     text: '> 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ✦ 𝐁𝐄𝐋𝐀𝐋! ⦓ 𝐊 ⦔' }
        ])

    else if (m.messageStubType == 22)
        txt = theme.build([
            { type: 'title',    text: '🖼️ تـغـيـيـر صـوُرة الـمـجـمـوُعـة' },
            { type: 'info',     label: '👤 بواسطة', value: fuser },
            { type: 'info',     label: '✨ الحالة', value: 'تـم تـحـدِيـث الـصـوُرة بـنـجـاح' },
            { type: 'divider' },
            { type: 'line',     text: '> 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ✦ 𝐁𝐄𝐋𝐀𝐋! ⦓ 𝐊 ⦔' }
        ])

    else if (m.messageStubType == 23)
        txt = theme.build([
            { type: 'title',    text: '🔗 تـغـيـيـر رابـط الـمـجـمـوُعـة' },
            { type: 'info',     label: '👤 بواسطة', value: fuser },
            { type: 'info',     label: '🔄 الحالة', value: 'تـم إعـادِة تـعـيـيـن الـرابـط' },
            { type: 'divider' },
            { type: 'line',     text: '> 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ✦ 𝐁𝐄𝐋𝐀𝐋! ⦓ 𝐊 ⦔' }
        ])

    else if (m.messageStubType == 26)
        txt = theme.build([
            { type: 'title',    text: '🔒 تـغـيـيـر إعـدِادِات الإرسـال' },
            { type: 'info',     label: '👤 بواسطة', value: fuser },
            { type: 'info',     label: '📋 الحالة', value: m.messageStubParameters[0] == 'on' ? 'مـغـلـوُقـة (لـلـمـشـرفـيـن فـقـط)' : 'مـفـتـوُحـة (لـلـجـمـيـع)' },
            { type: 'divider' },
            { type: 'line',     text: '> 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ✦ 𝐁𝐄𝐋𝐀𝐋! ⦓ 𝐊 ⦔' }
        ])

    // ══ ترقية وإعفاء مشرف ══
    else if (m.messageStubType == 29 || m.messageStubType == 30)
        txt = theme.build([
            { type: 'title',    text: m.messageStubType == 29 ? '⬆️ تـرقـيـة مـشـرف' : '⬇️ إعـفـاء مـشـرف' },
            { type: 'info',     label: '👤 العضو', value: tuser },
            { type: 'info',     label: '👮 بواسطة', value: fuser },
            { type: 'divider' },
            { type: 'line',     text: '> 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ✦ 𝐁𝐄𝐋𝐀𝐋! ⦓ 𝐊 ⦔' }
        ])

    if (txt) await conn.sendMessage(m.chat, { text: txt, contextInfo }, { quoted: null })
    return true
}

export default handler

// ═══════════════════════════════
// دالة تحويل LID لـ JID حقيقي
// ═══════════════════════════════
async function resolveLidToRealJid(lid, conn, groupChatId) {
    const inputJid = lid?.toString()
    if (!inputJid) return `0@s.whatsapp.net`
    if (!inputJid.endsWith('@lid')) return inputJid.includes('@') ? inputJid : `${inputJid}@s.whatsapp.net`
    if (lidCache.has(inputJid)) return lidCache.get(inputJid)
    try {
        const metadata = await conn.groupMetadata(groupChatId)
        for (const participant of metadata.participants) {
            if (participant.jid.split('@')[0] === inputJid.split('@')[0]) {
                lidCache.set(inputJid, participant.jid)
                return participant.jid
            }
        }
    } catch {}
    return inputJid
}
