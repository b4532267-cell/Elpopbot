import axios from "axios";
import {
  generateWAMessageContent,
  generateWAMessageFromContent
} from "@whiskeysockets/baileys";

let handler = async (m, { conn, text, usedPrefix, command }) => {

  if (!text) {
    return conn.sendMessage(m.chat, {
      text: `*⇝ ⟦ طـريـقـة الـاسـتـخـدام ⟧ ↯*

*مـثـال لـلـبـحـث عـن إيـديـت:*

> ${usedPrefix + command} asta
> ${usedPrefix + command} naroto`
    }, { quoted: m });
  }

  await conn.sendPresenceUpdate("composing", m.chat);

  await conn.sendMessage(m.chat, {
    text: `*⏳⃟̱̅͟͞ ⇝ جـاري الـبـحـث عـن الإيـديـت الـمـطـلـوب...*`
  }, { quoted: m });

  try {
    const { data } = await axios.get(
      "https://tikwm.com/api/feed/search",
      {
        params: {
          keywords: `${text} anime edit`,
          count: 20,
          cursor: 0
        },
        headers: { "User-Agent": "Mozilla/5.0" },
        timeout: 20000
      }
    );

    const videos = data?.data?.videos || [];
    if (!videos.length) throw "NO_RESULTS";

    const selected = videos
      .filter(v => v?.play && v.duration && v.duration <= 60)
      .slice(0, 6); 

    if (!selected.length) throw "NO_VALID_VIDEOS";

    const createVideoMessage = async (url) => {
      const { videoMessage } = await generateWAMessageContent(
        { video: { url } },
        { upload: conn.waUploadToServer }
      );
      return videoMessage;
    };

    const videoMessages = await Promise.all(
      selected.map(v => createVideoMessage(v.play))
    );

    const cards = videoMessages.map(videoMsg => ({
      body: {
        text: `> *│🎬⃟̱̅͟͞ ⇝𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓*`
      },
      header: {
        hasMediaAttachment: true,
        videoMessage: videoMsg
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
              display_text: "🎬 طـلـب إيـديـت آخـر",
              id: `${usedPrefix + command} ${text}`
            })
          }
        ]
      }
    }));

    const msgFinal = generateWAMessageFromContent(
      m.chat,
      {
        interactiveMessage: {
          body: {
            text: `*⇝ تـم الـتـحـمـيـل بـنـجـاح*`
          },
          carouselMessage: { cards }
        }
      },
      { quoted: m }
    );

    await conn.relayMessage(m.chat, msgFinal.message, {
      messageId: msgFinal.key.id
    });

  } catch (e) {
    await conn.sendMessage(
      m.chat,
      { text: "❌ فـشـل جـلـب الإيـديـت (تـأكـد مـن الـاسـم)" },
      { quoted: m }
    );
  }
};

handler.command = /^(ايديت|edit)$/i;
handler.tags = ["media"];
handler.help = ["ايديت <كلمة>"];
handler.limit = true;

export default handler;