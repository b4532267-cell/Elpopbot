import fs from 'fs';

const allowedNumbers = ['966567158348@s.whatsapp.net', '201015115056@s.whatsapp.net'];

const handler = async (m, { text, usedPrefix, command, conn }) => {
  if (!allowedNumbers.includes(m.sender)) {
    await conn.sendMessage(m.chat, { text: `غير مسموح لك يا عبد` }, { quoted: m });
    return;
  }

  if (!text) throw `امم.. ما الاسم الذي أعطيه للأمر؟ 🐦‍🔥`;

  const filePath = `plugins/${text}.js`;

  if (command === 'ضيف' || command === 'addp' || command === 'addplugin') {
    if (!m.quoted || !m.quoted.text) throw `الرد على الرسالة ليتم حفظها! 🐦‍🔥`;
    fs.writeFileSync(filePath, m.quoted.text);
    m.reply(`تم الحفظ باسم ${filePath} بنجاح! 🐦‍🔥`);
  } else if (command === 'امسح') {
    if (!fs.existsSync(filePath)) throw `الملف "${filePath}" غير موجود لحذفه! 🐦‍🔥`;
    fs.unlinkSync(filePath);
    m.reply(`تم حذف الملف ${filePath} بنجاح! 🐦‍🔥`);
  }
};

handler.help = ['saveplugin', 'deleteplugin'].map((v) => v + ' <nombre>');
handler.tags = ['owner'];
handler.command = ['ضيف', 'addp', 'addplugin', 'امسح'];
handler.owner = true;

export default handler;
