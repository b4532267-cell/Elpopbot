import pkg from '@whiskeysockets/baileys'
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg

const handler = async (m, { conn }) => {
  try {
    // 🖼️ الصورة المثبتة اللي اتفقنا عليها خلاص
    const imageUrl = "https://files.catbox.moe/5o36un.jpg"
    const media = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer })

    await conn.sendMessage(m.chat, { react: { text: '📥', key: m.key } })

    // 📋 تنسيق الأوامر والاسم تحت بعض بالملي وبدون أي زيادات
    const caption = `
╭━━〔📥 ﻗـسـم الـتـحـمـيـلات 📥〕━━⬣
┃ ➟ *مرحباً بك يا* 『${m.pushName}』
┃ ➟ *داخل بوت* 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 🃏
╰━━━━━━━━━━━━⬣

╭━━〔📥 أوامـر الـتـحـمـيـلات 📥〕━━⬣
┃ ➟ 📝 *.بين-فيديو*
┃ ➟ 📍 *.تويتر*
┃ ➟ 🗃️ *.جيبهاب*
┃ ➟ 🗄️ *.جيبتهوب*
┃ ➟ 💌 *.كابكات*
┃ ➟ 📤 *.ميجا*
┃ ➟ 📥 *.تطبيق*
┃ ➟ 📯 *.إنستا*
┃ ➟ 💎 *.تيكتوك*
┃ ➟ 🛢️ *.تيك-صوت*
┃ ➟ ⚙️ *.تيك-جوده*
┃ ➟ 🖼️ *.بين-صور*
╰━━━━━━━━━━━━⬣
`.trim()

    const msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            header: proto.Message.InteractiveMessage.Header.create({ title: '', hasMediaAttachment: true, ...media }),
            body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
            footer: proto.Message.InteractiveMessage.Footer.create({ text: '⦓ 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ⦔' }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "⬅️ العودة للقائمة الرئيسية",
                    id: ".menu"
                  })
                }
              ]
            })
          })
        }
      }
    }, { userJid: m.sender })

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

  } catch (err) {
    console.error(err)
    await conn.sendMessage(m.chat, { text: '❌ حدث خطأ أثناء تنفيذ الأمر.' }, { quoted: m })
  }
}

handler.command = /^قسم-التحميلات$/i
handler.tags = ["download"]
handler.help = ["قسم-التحميلات"]

export default handler