// plugins/اضف-امر.js
// ⧼ 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓 ⧽ — إضافة أوامر جديدة من الشات 🛠️
// 𝐊𝐄𝐌𝐎! ⦓ 𝐊 ⦔ 𝐁𝐎𝐃𝐑𝐀𝐆𝐄𝐀

import { writeFileSync, existsSync } from 'fs'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'
import { theme } from '../core/theme.js'

// ══════════════════════════════════════════════
// 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓 ✦ حقوق محفوظة لـ KEMO! ⦓ K ⦔ BODRAGEA
// ══════════════════════════════════════════════

const __dirname = dirname(fileURLToPath(import.meta.url))

// ─── انتظار الكود من المطور ───
const pendingPlugin = new Map()

let handler = async (m, { conn, text, usedPrefix, command }) => {

    // ══ لو ما في نص — اشرح الاستخدام ══
    if (!text) {
        return m.reply(theme.build([
            { type: 'title',    text: '🛠️ إضـافـة أمـر جـديـد' },
            { type: 'subtitle', text: '𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ✦ 𝐁𝐄𝐋𝐀𝐋! ⦓ 𝐊 ⦔' },
            { type: 'divider' },
            { type: 'line',     text: '> الاستخدام:' },
            { type: 'info',     label: '1️⃣ الخطوة الأولى', value: `${usedPrefix}${command} اسم_الملف` },
            { type: 'line',     text: '> مثال: `اضف-امر تيك`' },
            { type: 'divider' },
            { type: 'line',     text: '> بعدها ابعت الكود مباشرة' }
        ]))
    }

    // ══ تحقق من اسم الملف ══
    const fileName = text.trim()
        .replace(/\.js$/i, '')
        .replace(/[^a-zA-Z0-9\u0600-\u06FF_\-]/g, '')

    if (!fileName) {
        return m.reply(theme.build([
            { type: 'title', text: '❌ اسـم غـيـر صـحـيـح' },
            { type: 'line',  text: '> اكتب اسم الملف بدون مسافات أو رموز خاصة' }
        ]))
    }

    // ══ حفظ اسم الملف وانتظار الكود ══
    pendingPlugin.set(m.sender, {
        fileName,
        ts: Date.now()
    })

    return m.reply(theme.build([
        { type: 'title', text: '✅ جـاهـز لاسـتـقـبـال الـكـود' },
        { type: 'info',  label: '📄 اسم الملف', value: `${fileName}.js` },
        { type: 'divider' },
        { type: 'line',  text: '> ابـعـت الـكـود دِلـوُقـتـي 👇' },
        { type: 'line',  text: '> المهلة: دقيقتين' }
    ]))
}

// ══════════════════════════════════════════════
// handler.before — استقبال الكود
// ══════════════════════════════════════════════
handler.before = async function (m, { conn }) {
    if (!pendingPlugin.has(m.sender)) return true

    // تجاهل الأوامر
    if (/^[.!/#$%]/.test(m.text || '')) return true

    const pending = pendingPlugin.get(m.sender)

    // انتهت المهلة
    if (Date.now() - pending.ts > 2 * 60 * 1000) {
        pendingPlugin.delete(m.sender)
        return true
    }

    const code = m.text?.trim()
    if (!code || code.length < 10) return true

    pendingPlugin.delete(m.sender)

    const filePath = join(__dirname, `${pending.fileName}.js`)

    // ══ تحقق لو الملف موجود ══
    if (existsSync(filePath)) {
        await m.reply(theme.build([
            { type: 'title', text: '⚠️ الـمـلـف مـوُجـوُدِ مـسـبـقـاً' },
            { type: 'info',  label: '📄 الملف', value: `${pending.fileName}.js` },
            { type: 'line',  text: '> استخدم اسم مختلف أو احذف الملف القديم أولاً' }
        ]))
        return true
    }

    try {
        // ══ حفظ الكود ══
        writeFileSync(filePath, code, 'utf-8')

        // ══ تحميل البلجن مباشرة بدون ريستارت ══
        try {
            const pluginUrl = `file://${filePath}?update=${Date.now()}`
            const newPlugin = await import(pluginUrl)
            global.plugins[`${pending.fileName}.js`] = newPlugin.default
        } catch (loadErr) {
            // الملف اتحفظ بس فيه خطأ في الكود
            await m.reply(theme.build([
                { type: 'title', text: '⚠️ تـم الـحـفـظ بـس فـيـه خـطـأ' },
                { type: 'info',  label: '📄 الملف', value: `${pending.fileName}.js` },
                { type: 'line',  text: `> ${loadErr.message}` },
                { type: 'line',  text: '> الملف اتحفظ — هيشتغل بعد ريستارت البوت' }
            ]))
            return true
        }

        await m.react('✅')
        await m.reply(theme.build([
            { type: 'title',    text: '✅ تـم إضـافـة الأمـر بـنـجـاح' },
            { type: 'info',     label: '📄 الملف',   value: `${pending.fileName}.js` },
            { type: 'info',     label: '📍 المسار',  value: `plugins/${pending.fileName}.js` },
            { type: 'info',     label: '⚡ الحالة',  value: 'شغال دلوقتي بدون ريستارت' },
            { type: 'divider' },
            { type: 'line',     text: '> 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ✦ 𝐁𝐄𝐋𝐀𝐋! ⦓ 𝐊 ⦔ 𝐁𝐎𝐃𝐑𝐀𝐆𝐄𝐀' }
        ]))

    } catch (e) {
        await m.react('❌')
        await m.reply(theme.build([
            { type: 'title', text: '❌ فشـل حـفـظ الأمـر' },
            { type: 'line',  text: `> ${e.message}` }
        ]))
    }

    return true
}

// ══════════════════════════════════════════════
// Metadata — 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓
// ══════════════════════════════════════════════
handler.help    = ['اضف-امر']
handler.tags    = ['owner']
handler.command = /^(اضف.?امر|addplugin|add.?cmd)$/i
handler.owner   = true

export default handler
