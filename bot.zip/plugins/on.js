import fetch from 'node-fetch'

let linkRegex = /chat\.whatsapp\.com\/[0-9A-Za-z]{20,24}/i
let linkRegex1 = /whatsapp\.com\/channel\/[0-9A-Za-z]{20,24}/i
const defaultImage = 'https://files.catbox.moe/i65jk4.jpg'

const handler = async (m, { conn, command, args, isAdmin, isOwner }) => {
  if (!m.isGroup) return m.reply('🔒 *هـذا الأمـࢪ مـخـصـص لـلـجـࢪوُبـات فـقـط.*')

  if (!global.db.data.chats[m.chat]) global.db.data.chats[m.chat] = {}
  const chat = global.db.data.chats[m.chat]
  const typeInput = (args[0] || '').toLowerCase()
  const enable = command === 'تشغيل'

  // تحويل الكلمات العربي للغات البرمجة المخزنة في قاعدة البيانات
  let type = ''
  if (typeInput === 'الروابط') type = 'antilink'
  else if (typeInput === 'الترحيب') type = 'welcome'
  else if (typeInput === 'منع-الخليج') type = 'antiarabe' // حافظنا على اسم المتغير في القاعدة عشان السيرفر
  else if (typeInput === 'الاسبام') type = 'antispam'

  if (!['antilink', 'welcome', 'antiarabe', 'antispam'].includes(type)) {
    return m.reply(`✨ *اسـتـخـدِم الأمـࢪ كـالـتـالـي يـخـوُيـا:* ✨

 ❖ *.تشغيل الروابط*  /  *.ايقاف الروابط*
 ❖ *.تشغيل الترحيب*  /  *.ايقاف الترحيب*
 ❖ *.تشغيل منع-الخليج*  /  *.ايقاف منع-الخليج*
 ❖ *.تشغيل الاسبام*  /  *.ايقاف الاسبام*

⎔⋅• ─┈╌⬪ 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓 ⬪╌┈─ •⋅⎔`)
  }

  if (!(isAdmin || isOwner)) return m.reply('❌ *هـذا الأمـࢪ مـخـصـص لـلـمـشـࢪفـيـن فـقـط!*')

  chat[type] = enable
  
  let arabicTypeName = typeInput
  return m.reply(`✅ *تـم ${enable ? 'تـفـعـيـل' : 'إيـقـاف'} مـيـزة [ ${arabicTypeName} ] بـنـجـاح مـعـاڪ.*\n\n> 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ⸻ 𝐁𝐄𝐋𝐀𝐋! 🇮🇱`)
}

handler.command = ['تشغيل', 'ايقاف']
handler.group = true
handler.register = true
handler.tags = ['group']
handler.help = ['تشغيل الروابط', 'ايقاف الروابط', 'تشغيل الترحيب', 'ايقاف الترحيب', 'تشغيل منع-الخليج', 'ايقاف منع-الخليج', 'تشغيل الاسبام', 'ايقاف الاسبام']

handler.before = async (m, { conn, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) return
  if (!global.db.data.chats[m.chat]) global.db.data.chats[m.chat] = {}
  const chat = global.db.data.chats[m.chat]

  // 1. ميزة منع الاسبام (حذف الرسائل الطويلة جداً)
  if (chat.antispam && m.text && m.text.length > 5000) {
    const delet = m.key.participant
    const msgID = m.key.id
    const userTag = `@${m.sender.split('@')[0]}`

    const fakemek = {
      key: { participant: '0@s.whatsapp.net', remoteJid: '0@s.whatsapp.net' },
      message: {
        groupInviteMessage: {
          groupJid: '51995386439-1616969743@g.us',
          inviteCode: 'm',
          groupName: 'P',
          caption: '⚠️ تم اكتشاف رسالة اسبام',
          jpegThumbnail: null
        }
      }
    }

    if (!isBotAdmin) {
      await conn.sendMessage(m.chat, {
        text: `⚠️ *تـم اكـتـشـاف ࢪسـالـة طـوُيـلـة جـداً (اسـبـام) مـن* ${userTag}\n*لـكـنـنـي لـسـت مـشـࢪفـاً هـنـا لـذا لا أسـتـطـيـع حـذفـهـا!*`,
        mentions: [m.sender]
      }, { quoted: fakemek })
      return false
    }

    try {
      await conn.sendMessage(m.chat, {
        delete: {
          remoteJid: m.chat,
          fromMe: false,
          id: msgID,
          participant: delet
        }
      })

      await conn.sendMessage(m.chat, {
        text: `🚫 *تـم حـذف ࢪسـالـة طـوُيـلـة جـداً (اسـبـام)*\n*الـمـسـتـخـدِم:* ${userTag}`,
        mentions: [m.sender]
      }, { quoted: fakemek })
    } catch (error) {
      console.error("Error:", error)
    }

    return false
  }

  // 2. ميزة طرد أرقام الخليج + الأجانب + المغاربة (212)
  if (chat.antiarabe && m.messageStubType === 27) {
    const newJid = m.messageStubParameters?.[0]
    if (!newJid) return

    const number = newJid.split('@')[0].replace(/\D/g, '')
    
    // البادئات: المغرب (212)، دول الخليج (966، 971، 965، 974، 973، 968)، والأجانب (أمريكا 1، أوروبا وغيرها)
    // البوت هيطرد أي رقم يبدأ بهذه الأرقام، وهيسمح بالمصري (20)
    const blockPrefixes = [
      '212', // المغرب
      '966', // السعودية
      '971', // الإمارات
      '965', // الكويت
      '974', // قطر
      '973', // البحرين
      '968', // عمان
      '1',   // أمريكا / كندا
      '44',  // المملكة المتحدة
      '33',  // فرنسا
      '49'   // ألمانيا
    ]
    
    const shouldBlock = blockPrefixes.some(prefix => number.startsWith(prefix))

    if (shouldBlock) {
      await conn.sendMessage(m.chat, { text: `🚫 *الـمـسـتـخـدِم* @${number} *تـم طـࢪدِه بـسـبـب الـتـفـعـيـل الـتـلـقـائـي لـمـيـزة [ منع-الخليج والأجانب ]*`, mentions: [newJid] })
      await conn.groupParticipantsUpdate(m.chat, [newJid], 'remove')
      return true
    }
  }

  // 3. ميزة منع الروابط (Anti-Link)
  if (chat.antilink) {
    const groupMetadata = await conn.groupMetadata(m.chat)
    const isUserAdmin = groupMetadata.participants.find(p => p.id === m.sender)?.admin
    const text = m?.text || ''

    if (!isUserAdmin && (linkRegex.test(text) || linkRegex1.test(text))) {
      const userTag = `@${m.sender.split('@')[0]}`
      const delet = m.key.participant
      const msgID = m.key.id

      try {
        const ownGroupLink = `https://chat.whatsapp.com/${await conn.groupInviteCode(m.chat)}`
        if (text.includes(ownGroupLink)) return
      } catch {}

      try {
        await conn.sendMessage(m.chat, {
          text: `🚫 *يـا* ${userTag}, *مـمـنـوع نـشـࢪ الـࢪوُابـط هـنـا! تـم الـطـࢪدِ.*`,
          mentions: [m.sender]
        }, { quoted: m })

        await conn.sendMessage(m.chat, {
          delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: msgID,
            participant: delet
          }
        })

        await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
      } catch {
        await conn.sendMessage(m.chat, {
          text: `⚠️ *لـم أتـمـكـن مـن حـذف الـࢪابـط أو طـࢪدِ* ${userTag}, *تـأكـدِ أنـنـي مـشـࢪف!*`,
          mentions: [m.sender]
        }, { quoted: m })
      }

      return true
    }
  }

  // 4. ميزة الترحيب والمغادرة (Welcome / Bye)
  if (chat.welcome && [27, 28, 32].includes(m.messageStubType)) {
    const groupMetadata = await conn.groupMetadata(m.chat)
    const groupSize = groupMetadata.participants.length
    const userId = m.messageStubParameters?.[0] || m.sender
    const userMention = `@${userId.split('@')[0]}`
    let profilePic

    try {
      profilePic = await conn.profilePictureUrl(userId, 'image')
    } catch {
      profilePic = defaultImage
    }

    if (m.messageStubType === 27) {
      const txtWelcome = `⎔⋅• ─┈╌⬪─═✥═─⬪╌┈─ •⋅⎔\n  *مـــنـــوُࢪ/ه يــقــلــب اخـوُك/ي* ✨\n⎔⋅• ─┈╌⬪─═✥═─⬪╌┈─ •⋅⎔`
      const bienvenida = `
*مـــنـــوُࢪ جـࢪوُبـنـا الـمـتـوُاضـع :*  ${groupMetadata.subject}  
*الـعـضـوُ الـجـدِيـدِ:* ${userMention}
*عـدِدِ الأعـضـاء الآن:* *${groupSize}*    

*قـوُانـيـن الـجـࢪوُب الـرسـمـيـة:* 📜
❖ *ممنوع إرسال الروابط = طرد فوري*
❖ *ممنوع السب أو الإهانة = طرد نهائي*
❖ *ممنوع نشر أي محتوى غير لائق (صور أو فيديوهات)*
❖ *ممنوع الإعلان عن جروبات أو قنوات أخرى*
❖ *ممنوع التكرار أو الإزعاج (الاسبام) في الرسائل*
❖ *يجب احترام جميع الأعضاء والمشرفين*

> 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ⸻ 𝐁𝐄𝐋𝐀𝐋! 🇮🇱
`.trim()

      await conn.sendMessage(m.chat, {
        image: { url: profilePic },
        caption: `${txtWelcome}\n\n${bienvenida}`,
        contextInfo: { mentionedJid: [userId] }
      })
    }

    if (m.messageStubType === 28 || m.messageStubType === 32) {
      const txtBye = `⎔⋅• ─┈╌⬪─═✥═─⬪╌┈─ •⋅⎔\n  *مــع الــســلامـه مـنـجـيـش فـ حـاجـه حـلـوُه* 👋\n⎔⋅• ─┈╌⬪─═✥═─⬪╌┈─ •⋅⎔`
      const despedida = `
*والــيــوُم خــࢪج مــن جــࢪوُبــنـا عــضــوُ خــايــن:* ${groupMetadata.subject}   
*الـخـايـن:* ➪ ${userMention}
*عـدِدِ الأعـضـاء الآن:* 🙂💔 *${groupSize}* 

> اﻟــﻲ ﺑــﻌــﺪِوُ..
> 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ⸻ 𝐁𝐄𝐋𝐀𝐋! 🇮🇱
`.trim()

      await conn.sendMessage(m.chat, {
        image: { url: profilePic },
        caption: `${txtBye}\n\n${despedida}`,
        contextInfo: { mentionedJid: [userId] }
      })
    }
  }
}

export default handler