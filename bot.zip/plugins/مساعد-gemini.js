import axios from 'axios';
import fs from 'fs';
import path from 'path';
import fetch from 'node-fetch';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

// ═══════════════════════════════════════════════
//              تصدير معلومات الأمر
// ═══════════════════════════════════════════════
export const command     = ['مساعد', 'dev', 'gemini-dev', 'terminal'];
export const description = '🤖 مساعد المطور المتقدم - تحكم كامل في السيرفر والملفات عبر Gemini';
export const category    = 'admin';
export const hidden      = false;

// ═══════════════════════════════════════════════
//         جلسات المستخدمين (ذاكرة المحادثة)
// ═══════════════════════════════════════════════
const sessions = {};

// ═══════════════════════════════════════════════
//              أدوات النظام والملفات
// ═══════════════════════════════════════════════
function getFilesTree(dirPath, depth = 0) {
    let results = [];
    if (!fs.existsSync(dirPath) || depth > 3) return results;
    try {
        fs.readdirSync(dirPath).forEach(file => {
            const fullPath = path.join(dirPath, file);
            const stat = fs.statSync(fullPath);
            if (stat.isDirectory()) {
                if (!['node_modules', '.git', '.npm'].includes(file)) {
                    results = results.concat(getFilesTree(fullPath, depth + 1));
                }
            } else if (/\.(js|json|cjs|mjs|txt|md|html|css|py|sh)$/.test(file)) {
                results.push(fullPath);
            }
        });
    } catch {}
    return results;
}

async function executeShell(command) {
    try {
        const { stdout, stderr } = await execAsync(command, { timeout: 30000 });
        return stdout || stderr || '✅ تم التنفيذ بنجاح (لا يوجد مخرج)';
    } catch (error) {
        return `❌ خطأ في التنفيذ:\n${error.message}`;
    }
}

// ═══════════════════════════════════════════════
//         أدوات معالجة النصوص والـ JSON
// ═══════════════════════════════════════════════
function stripCodeFence(text = '') {
    return String(text || '').trim()
        .replace(/^```[\w]*\n?/i, '')
        .replace(/\n?```$/i, '')
        .trim();
}

function safeJsonParse(value) {
    try { return JSON.parse(value); } catch { return null; }
}

function normalizeLanguage(lang = '') {
    const map = {
        js: 'javascript', javascript: 'javascript',
        ts: 'typescript', typescript: 'typescript',
        py: 'python',     python: 'python',
        sh: 'bash',       bash: 'bash',
        html: 'html',     css: 'css',
        json: 'json',     xml: 'xml',
        sql: 'sql',       php: 'php',
        java: 'java',     c: 'c',
        cpp: 'cpp',       'c++': 'cpp',
        go: 'go',         rust: 'rust',
        yml: 'yaml',      yaml: 'yaml',
        md: 'markdown',   txt: 'text', text: 'text'
    };
    const raw = String(lang || '').trim().toLowerCase();
    return map[raw] || raw || 'text';
}

function prettyLanguage(lang = '') {
    const map = {
        javascript: 'JavaScript', typescript: 'TypeScript',
        python: 'Python',         bash: 'Bash',
        html: 'HTML',             css: 'CSS',
        json: 'JSON',             xml: 'XML',
        sql: 'SQL',               php: 'PHP',
        java: 'Java',             c: 'C',
        cpp: 'C++',               go: 'Go',
        rust: 'Rust',             yaml: 'YAML',
        markdown: 'Markdown',     text: 'Text'
    };
    return map[normalizeLanguage(lang)] || lang;
}

// ═══════════════════════════════════════════════
//       تحويل رد الـ AI إلى عناصر منظمة
// ═══════════════════════════════════════════════
function parseStructuredResponse(rawText) {
    const cleaned = stripCodeFence(rawText);
    const parsed  = safeJsonParse(cleaned);
    const out     = [];

    if (parsed && typeof parsed === 'object') {
        const items =
            Array.isArray(parsed.messages) ? parsed.messages :
            Array.isArray(parsed.items)    ? parsed.items    :
            Array.isArray(parsed.response) ? parsed.response :
            Array.isArray(parsed)          ? parsed          : [];

        for (const item of items) {
            if (!item || typeof item !== 'object') continue;
            const type = String(item.type || item.kind || '').trim().toLowerCase();

            if (!type || type === 'text' || type === 'message' || type === 'paragraph') {
                const content = String(item.content ?? item.text ?? item.message ?? '').trim();
                if (content) out.push({ type: 'text', content });

            } else if (type === 'code') {
                const content = stripCodeFence(String(item.content ?? item.code ?? item.source ?? '')).trim();
                if (!content) continue;
                const language = normalizeLanguage(item.language || item.lang || 'text');
                out.push({ type: 'code', language, label: String(item.label || prettyLanguage(language)).trim(), content });

            } else if (type === 'shell' || type === 'terminal' || type === 'exec') {
                const command = String(item.command ?? item.content ?? '').trim();
                if (command) out.push({ type: 'shell', command });
            }
        }
        if (out.length > 0) return out;
        if (typeof parsed.content === 'string' && parsed.content.trim())
            return [{ type: 'text', content: parsed.content.trim() }];
    }

    return [{ type: 'text', content: cleaned || rawText }];
}

// ═══════════════════════════════════════════════
//        بناء رسالة Rich لـ WhatsApp (رش)
// ═══════════════════════════════════════════════
async function buildSubmessages(items = []) {
    const sub = [];
    for (const item of items) {
        if (item.type === 'text') {
            const content = String(item.content || '').trim();
            if (content) sub.push({ messageType: 2, messageText: content });

        } else if (item.type === 'code') {
            const content  = stripCodeFence(String(item.content || '').trim());
            if (!content) continue;
            const language = normalizeLanguage(item.language || 'text');
            const label    = String(item.label || prettyLanguage(language)).trim();
            sub.push({ messageType: 2, messageText: `📄 ملف: ${label}` });
            sub.push({
                messageType: 5,
                codeMetadata: {
                    codeLanguage: language,
                    codeBlocks: [{ highlightType: 1, codeContent: content }]
                }
            });

        } else if (item.type === 'shell') {
            sub.push({ messageType: 2, messageText: `💻 تنفيذ أمر: \`${item.command}\`` });
            const output = await executeShell(item.command);
            sub.push({
                messageType: 5,
                codeMetadata: {
                    codeLanguage: 'bash',
                    codeBlocks: [{ highlightType: 1, codeContent: output }]
                }
            });
        }
    }
    return sub;
}

async function sendRichMessage(conn, m, botJid, generateWAMessageFromContent, submessages) {
    const msg = await generateWAMessageFromContent(
        m.key.remoteJid,
        {
            botForwardedMessage: {
                message: {
                    richResponseMessage: {
                        messageType: 1,
                        submessages,
                        contextInfo: {
                            isForwarded: true,
                            forwardingScore: 999,
                            forwardedAiBotMessageInfo: { botJid: '867051314767696@bot' },
                            forwardOrigin: 4
                        }
                    }
                }
            }
        },
        {
            senderId: botJid,
            userJid: botJid,
            messageId: (conn.generateMessageIDV2 && typeof conn.generateMessageIDV2 === 'function')
                ? conn.generateMessageIDV2(botJid)
                : 'DEV-' + Date.now().toString(36).toUpperCase()
        }
    );
    await conn.relayMessage(m.key.remoteJid, msg.message, { messageId: msg.key.id });
}

// ═══════════════════════════════════════════════
//              Gemini API Engine
// ═══════════════════════════════════════════════
const gemini = {
    getNewCookie: async function () {
        try {
            const { headers } = await axios.post(
                'https://gemini.google.com/_/BardChatUi/data/batchexecute?rpcids=maGuAc&source-path=%2F&bl=boq_assistant-bard-web-server_20250814.06_p1&f.sid=-7816331052118000090&hl=en-US&_reqid=173780&rt=c',
                'f.req=%5B%5B%5B%22maGuAc%22%2C%22%5B0%5D%22%2Cnull%2C%22generic%22%5D%5D%5D&',
                { headers: { 'content-type': 'application/x-www-form-urlencoded;charset=UTF-8' }, timeout: 10000 }
            );
            const raw = headers['set-cookie'];
            if (!raw) return null;
            const cookie = Array.isArray(raw) ? raw[0] : raw;
            return cookie.split(';')[0];
        } catch { return null; }
    },

    ask: async function (prompt, previousId = null, systemInstruction = '') {
        if (!prompt?.trim()) throw new Error('الرجاء إدخال نص.');

        let resumeArray = null;
        if (previousId) {
            try { resumeArray = JSON.parse(Buffer.from(previousId, 'base64').toString('utf-8')).newResumeArray; } catch {}
        }

        const cookie     = await this.getNewCookie();
        const fullPrompt = systemInstruction ? `${systemInstruction}\n\n[USER REQUEST]:\n${prompt}` : prompt;
        const body       = new URLSearchParams({ 'f.req': JSON.stringify([null, JSON.stringify([[fullPrompt], ['en-US'], resumeArray])]) }).toString();

        const { data } = await axios.post(
            'https://gemini.google.com/_/BardChatUi/data/assistant.lamda.BardFrontendService/StreamGenerate?bl=boq_assistant-bard-web-server_20250729.06_p0&f.sid=4206607810970164620&hl=en-US&_reqid=2813378&rt=c',
            body,
            {
                headers: {
                    'content-type': 'application/x-www-form-urlencoded;charset=UTF-8',
                    'x-goog-ext-525001261-jspb': '[1,null,null,null,"9ec249fc9ad08861",null,null,null,[4]]',
                    'cookie': cookie || ''
                },
                responseType: 'text',
                timeout: 60000
            }
        );

        const chunks = Array.from(String(data).matchAll(/^\d+\n(.+?)\n/gm), x => x[1]);
        for (const chunk of [...chunks].reverse()) {
            try {
                const arr  = JSON.parse(chunk);
                const p    = JSON.parse(arr[0][2]);
                if (p?.[4]?.[0]?.[1] && typeof p[4][0][1][0] === 'string') {
                    const newResumeArray = [...p[1], p[4][0][0]];
                    return {
                        text: p[4][0][1][0],
                        id: Buffer.from(JSON.stringify({ newResumeArray })).toString('base64')
                    };
                }
            } catch {}
        }
        throw new Error('فشل استلام رد من Gemini.');
    }
};

// ═══════════════════════════════════════════════
//              الأمر الرئيسي
// ═══════════════════════════════════════════════
export default async function (conn, m, { args, prefix, command: cmd }) {
    const from  = m.key.remoteJid;
    const react = (e) => conn.sendMessage(from, { react: { text: e, key: m.key } }).catch(() => {});
    const reply = (t) => conn.sendMessage(from, { text: t }, { quoted: m });

    const text = args.join(' ').trim();

    // ─── رسالة المساعدة ───
    if (!text) {
        return reply(
`*╭──══─┈•⤣⚡⤤•┈─══──╮*
🤖 *مساعد المطور الخارق (Gemini Pro)*

تحكم كامل في السيرفر عبر الذكاء الاصطناعي.

*🛠️ القدرات المتاحة:*
← تعديل وإصلاح الأكواد تلقائياً.
← تنفيذ أوامر الـ Terminal (Shell).
← قراءة وتحليل ملفات المشروع.
← اختبار الـ APIs والروابط.

*📝 أمثلة:*
← \`${prefix}${cmd} حدث السيرفر وشغل npm start\`
← \`${prefix}${cmd} صلح الخطأ في ملف handler.js\`
← \`${prefix}${cmd} وريني مساحة الهارد ديسك كام\`

*🔄 الإدارة:*
← \`${prefix}${cmd} ريست\` (لمسح الذاكرة)
*╰──══─┈•⤣⚡⤤•┈─══──╯*`
        );
    }

    if (text === 'ريست' || text === 'مسح') {
        delete sessions[m.key.participant || from];
        return reply('🔄 تم تصفير الذاكرة بنجاح.');
    }

    await react('⚡');

    try {
        const uid = m.key.participant || from;
        if (!sessions[uid]) sessions[uid] = { id: null, memory: [] };

        // جلب هيكل الملفات
        const allFiles = getFilesTree('.');
        const serverStructure = allFiles.map(p => `- ${p}`).slice(0, 50).join('\n');

        // البحث عن سياق الملفات المذكورة
        let fileContext = '';
        for (const filePath of allFiles) {
            const base = path.basename(filePath);
            if (text.includes(base)) {
                try {
                    const content = fs.readFileSync(filePath, 'utf8');
                    fileContext += `\n\n[FILE: ${filePath}]:\n${content}\n`;
                    if (fileContext.length > 20000) break;
                } catch {}
            }
        }

        // اختبار الروابط
        let apiContext = '';
        const urls = text.match(/(https?:\/\/[^\s]+)/g);
        if (urls?.length > 0) {
            const url = urls[0];
            try {
                const res = await fetch(url, { timeout: 10000 });
                const raw = await res.text();
                apiContext = `\n\n[API TEST: ${url}]:\n${raw.slice(0, 2000)}`;
            } catch (e) { apiContext = `\n\n[API ERROR: ${url}]: ${e.message}`; }
        }

        const systemInstruction = `
You are "Supreme Dev-Assistant", a high-level system administrator and coder.
You have FULL ACCESS to the server via shell commands and file reading.

[CORE RULES]
1. Return response as a VALID JSON object.
2. DO NOT use markdown code fences (\`\`\`) in your final JSON output strings.
3. Supported types: "text", "code", "shell".
4. "shell" type is for executing terminal commands. Use it for npm, git, ls, df, top, etc.
5. "code" type is for displaying or editing file contents.
6. NO LENGTH LIMITS: Provide full code and full explanations.
7. NO TABLES: Do not use table structures.

[JSON SCHEMA EXAMPLE]
{
  "messages": [
    { "type": "text", "content": "I will check the disk space now." },
    { "type": "shell", "command": "df -h" },
    { "type": "text", "content": "Now I will update the file." },
    { "type": "code", "language": "javascript", "label": "config.js", "content": "const x = 1;" }
  ]
}

[ENVIRONMENT]
Current Directory: ${process.cwd()}
Files:
${serverStructure}
${fileContext}${apiContext}
`;

        let result;
        try {
            result = await gemini.ask(text, sessions[uid].id, systemInstruction);
        } catch {
            sessions[uid].id = null;
            result = await gemini.ask(text, null, systemInstruction);
        }

        sessions[uid].id = result.id;
        sessions[uid].memory.push(`U: ${text}`, `A: ${String(result.text).slice(0, 200)}`);
        if (sessions[uid].memory.length > 10) sessions[uid].memory.shift();

        const items = parseStructuredResponse(result.text);
        const submessages = await buildSubmessages(items);

        if (submessages.length > 0) {
            try {
                let baileysLib;
                try { baileysLib = await import('@whiskeysockets/baileys'); } catch { baileysLib = await import('baileys'); }
                const { generateWAMessageFromContent } = baileysLib.default ?? baileysLib;
                const botJid = conn.user?.id || conn.user?.jid || null;
                await sendRichMessage(conn, m, botJid, generateWAMessageFromContent, submessages);
                await react('✅');
                return;
            } catch (e) { console.error('Rich Message Error:', e); }
        }

        await react('✅');
        return reply(String(result.text || 'لم يتم استلام رد.').replace(/```/g, ''));

    } catch (err) {
        await react('❌');
        return reply(`❌ خطأ: ${err.message}`);
    }
}
