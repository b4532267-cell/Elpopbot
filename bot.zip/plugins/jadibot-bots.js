import ws from 'ws';

let handler = async (m, { conn }) => {
    let uniqueUsers = new Map();

    if (!global.conns || !Array.isArray(global.conns)) global.conns = [];

    // جلب البوتات الفرعية النشطة
    for (const connSub of global.conns) {
        if (connSub.user && connSub.ws?.socket?.readyState !== ws.CLOSED) {
            const jid = connSub.user.jid;
            const numero = jid?.split('@')[0];

            // الحصول على الاسم (من البوت الفرعي نفسه)
            let nombre = connSub.user.name || `بوت فرعي ${numero}`;
            uniqueUsers.set(jid, { nombre, numero });
        }
    }

    const totalUsers = uniqueUsers.size;
    const uptime = process.uptime() * 1000;
    const formatUptime = clockString(uptime);

    // الزخرفة المستخدمة (نفس الثيم السابق)
    const theme = {
        divider: "◑ • ─ ⌯┅┉⌯ •﹝📢﹞• ⌯┅┉⌯ ─ • ◐",
        smallDivider: "⎔⋅• ─┈╌⬪─═✥═─⬪╌┈─ •⋅⎔",
        endDivider: "◑ • ─ ⌯┅┉⌯ •﹝🩸﹞• ⌯┅┉⌯ ─ • ◐"
    };

    let txt = `> ${theme.divider}\n\n`;
    txt += `✧ *البــوتـات الــفــࢪعــيــة الـنـشـطـة* ✧\n\n`;
    txt += `> ${theme.smallDivider}\n`;
    txt += `✦ *وقـت الـتـشـغـيـل:* ${formatUptime}\n`;
    txt += `✦ *عـدد الـبـوتـات:* ${totalUsers}\n`;
    txt += `> ${theme.smallDivider}\n\n`;

    if (totalUsers > 0) {
        txt += `❀ *قـائـمـة الـبـوتـات الـمـتـصـلـة:* ❀\n\n`;
        let i = 1;
        for (const [jid, { nombre, numero }] of uniqueUsers) {
            txt += `✦ *${i++}.* ${nombre}\n`;
            txt += `   ❀ *الـرقـم:* wa.me/${numero}\n`;
            txt += `   ❀ *جـيـد:* ${jid}\n`;
            txt += `> ${theme.smallDivider}\n\n`;
        }
    } else {
        txt += `> ❀ *لا يـوجـد بـوتـات فـࢪعـيـة مـتـصـلـة حـالـيـاً.*\n`;
    }

    txt += `> ${theme.endDivider}`;

    await conn.reply(m.chat, txt.trim(), m);
};

handler.command = ['البوتات', 'بوتات', 'subbots'];
handler.help = ['bots'];
handler.tags = ['jadibot'];
handler.register = true;

export default handler;

function clockString(ms) {
    const h = Math.floor(ms / 3600000);
    const m = Math.floor((ms % 3600000) / 60000);
    const s = Math.floor((ms % 60000) / 1000);
    return [h, m, s].map(v => v.toString().padStart(2, '0')).join(':');
}