// plugins/xnxx-dl.js
import axios        from 'axios'
import * as cheerio from 'cheerio'

const emoji  = '🎬'
const emoji2 = '⚠️'
const msm    = '❌'

const HEADERS = {
    'User-Agent':      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Cookie':          'age_verified=1; nv=1; lang=en'
}

const handler = async (m, { conn, args, command, usedPrefix }) => {

    if (!args[0])
        return m.reply(
            `${emoji} ابعت رابط أو رقم الفيديو من نتائج البحث.\n\n` +
            `*بالرابط:*\n${usedPrefix + command} https://www.xnxx.com/video-xxx/title\n\n` +
            `*برقم من البحث:*\n${usedPrefix + command} 1`
        )

    await m.reply(`${emoji} جاري معالجة الفيديو، استنى لحظة...\n> وقت الإرسال بيعتمد على حجم الفيديو.`)

    try {
        let xnxxLink = ''

        if (args[0].includes('xnxx')) {
            xnxxLink = args[0]
        } else {
            const index = parseInt(args[0]) - 1
            if (isNaN(index) || index < 0)
                throw `${emoji2} اكتب رابط أو رقم صح.`

            const matchingItem = global.videoListXXX?.find(item => item.from === m.sender)
            if (!matchingItem)
                throw `${emoji2} ابحث الأول بـ: *${usedPrefix}xnxxs اسم الفيديو*`

            if (index >= matchingItem.urls.length)
                throw `${emoji2} الرقم أكبر من النتائج، اختار رقم بين 1 و ${matchingItem.urls.length}`

            xnxxLink = matchingItem.urls[index]
        }

        const res   = await xnxxDL(xnxxLink)
        const files = res.result.files

        const videoUrl = files.high || files.low || files.HLS
        if (!videoUrl) throw `${emoji2} مش قادر أجيب رابط الفيديو، جرب رابط تاني.`

        await conn.sendMessage(m.chat, {
            document: { url: videoUrl },
            mimetype:  'video/mp4',
            fileName:  `${res.result.title || 'xnxx'}.mp4`,
            caption:
                `🎬 *${res.result.title || 'XNXX'}*\n` +
                `⏱️ المدة: ${res.result.duration || '-'} ثانية\n` +
                `ℹ️ ${res.result.info || ''}`
        }, { quoted: m })

    } catch (e) {
        console.error('[xnxxdl]', e)
        return m.reply(
            `${msm} حصل خطأ!\n\n` +
            `الرابط لازم يكون زي كده:\n` +
            `◉ https://www.xnxx.com/video-14lcwbe8/title\n\n` +
            `التفاصيل: ${e?.message || e}`
        )
    }
}

handler.help     = ['xnxxdl <رابط أو رقم>']
handler.tags     = ['nsfw']
handler.command  = /^(xnxxdl|xnxxdown)$/i
handler.register = false
export default handler

// ══════════════════════════════════════
//  دالة التحميل
// ══════════════════════════════════════
async function xnxxDL(url) {
    const { data } = await axios.get(url, {
        headers: HEADERS,
        timeout: 20000
    })

    const $           = cheerio.load(data, { xmlMode: false })
    const title       = $('meta[property="og:title"]').attr('content')
    const duration    = $('meta[property="og:duration"]').attr('content')
    const image       = $('meta[property="og:image"]').attr('content')
    const videoType   = $('meta[property="og:video:type"]').attr('content')
    const videoWidth  = $('meta[property="og:video:width"]').attr('content')
    const videoHeight = $('meta[property="og:video:height"]').attr('content')
    const info        = $('span.metadata').text().trim()

    const videoScript = $('#video-player-bg > script:nth-child(6)').html() || data

    const files = {
        low:          (videoScript.match(/html5player\.setVideoUrlLow\('([^']+)'\)/)     || [])[1],
        high:         (videoScript.match(/html5player\.setVideoUrlHigh\('([^']+)'\)/)    || [])[1],
        HLS:          (videoScript.match(/html5player\.setVideoHLS\('([^']+)'\)/)        || [])[1],
        thumb:        (videoScript.match(/html5player\.setThumbUrl\('([^']+)'\)/)        || [])[1],
        thumb69:      (videoScript.match(/html5player\.setThumbUrl169\('([^']+)'\)/)     || [])[1],
        thumbSlide:   (videoScript.match(/html5player\.setThumbSlide\('([^']+)'\)/)      || [])[1],
        thumbSlideBig:(videoScript.match(/html5player\.setThumbSlideBig\('([^']+)'\)/)   || [])[1],
    }

    return {
        status: 200,
        result: { title, url, duration, image, videoType, videoWidth, videoHeight, info, files }
    }
}