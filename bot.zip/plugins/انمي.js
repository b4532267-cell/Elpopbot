import { translate } from '@vitalets/google-translate-api'
import fetch from 'node-fetch'

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply(`*[❗] من فضلك أدخل اسم الأنمي الذي تريد البحث عنه*`);
  try {
    let response = await fetch(`https://api.jikan.moe/v4/anime?q=${encodeURIComponent(text)}&limit=1`);
    let json = await response.json();
    if (!json.data || !json.data.length) return m.reply(`*[❗] لم يتم العثور على نتائج لـ "${text}"*`);
    let result = json.data[0];

    let synopsisRaw = result.synopsis || 'لا توجد سيرة متوفرة';
    let translatedSynopsis = await translate(synopsisRaw.slice(0, 400), { to: 'ar' }).catch(() => ({ text: synopsisRaw }));

    let AnimeInfo = `
*معلومات الأنمي:*

• الاسم: ${result.title}
• الاسم اليابانيّ: ${result.title_japanese || 'غير متوفر'}
• الشكل: ${result.type || 'غير معروف'}
• الحالة: ${result.status || 'غير معروف'}
• عدد الحلقات: ${result.episodes || 'غير معروف'}
• المدة: ${result.duration || 'غير معروفة'}
• مقتبس من: ${result.source || 'غير معروف'}
• أول عرض: ${result.aired?.from ? result.aired.from.split('T')[0] : 'غير متوفر'}
• تاريخ الانتهاء: ${result.aired?.to ? result.aired.to.split('T')[0] : 'غير متوفر'}
• الشعبية: ${result.popularity || 'غير معروفة'}
• عدد المفضلة: ${result.favorites || 0}
• التصنيف العمري: ${result.rating || 'غير محدد'}
• الترتيب العالمي: ${result.rank || 'غير مصنّف'}
• رابط MAL: ${result.url}

*السيرة:*
${translatedSynopsis.text}
    `.trim();

    conn.sendFile(m.chat, result.images?.jpg?.image_url || result.images?.jpg?.large_image_url, 'anime.jpg', AnimeInfo, m);
  } catch (e) {
    console.error(e);
    throw `*[❗] حدث خطأ أثناء جلب المعلومات، حاول مرة أخرى لاحقاً.*`;
  }
}

handler.command = /^(anime|انمي)$/i
export default handler
