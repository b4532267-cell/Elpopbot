import pkg from '@whiskeysockets/baileys'
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg

const handler = async (m, { conn }) => {
  try {
    let name = await conn.getName(m.sender)
    let user = global.db.data.users[m.sender]
    let role = user?.role || 'مشرف 🛡️'
    let warns = user?.warn || 0

    await conn.sendMessage(m.chat, { react: { text: '🛡️', key: m.key } })

    // 🖼️ الصورة المثبتة الرسمية لبوتك
    const imageUrl = 'https://files.catbox.moe/5o36un.jpg'
    const media = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer })

    // 💬 تنسيق أوامر المشرفين والاسم المعتمد 🍫 تحت بعض بالملي وبدون زيادات
    let caption = `
╭━━〔🍫 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 🍫〕━━⬣
┃ ➟ *مرحباً بك يا* 『${name}』
┃ ➟ *🤖 البوت:* 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 🍫
┃ ➟ *🛡️ قسم المشرفين جاهز لخدمتك*
╰━━━━━━━━━━━━━━⬣

╭━━〔🛡️ أوامـر المشرفين 🛡️〕━━⬣
┃ ➟ 👥 *.منشن*
┃ ➟ 🏠 *.جروب*
┃ ➟ ❌ *.طرد*
┃ ➟ 🚨 *.انذار*
┃ ➟ 🧭 *.الغاء_انذار*
┃ ➟ 📋 *.انذارات*
┃ ➟ 🔗 *.لينك*
┃ ➟ 🪄 *.اعفاء*
┃ ➟ 🧱 *.ترقيه*
┃ ➟ 🕵️ *.المتصلين*
┃ ➟ ♻️ *.تجديد*
┃ ➟ 🫥 *.مخفي*
┃ ➟ ⛔ *.حذف*
┃ ➟ 🔇 *.كتم/فك_الكتم*
┣━━━━━━━━━━━━━━⬣
`.trim()

    // ⚙️ الرسالة التفاعلية بالزرار العادي من غير أقسام
    const msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            header: proto.Message.InteractiveMessage.Header.create({ title: '', hasMediaAttachment: true, ...media }),
            body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
            footer: proto.Message.InteractiveMessage.Footer.create({ text: '⦓ 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ⦔' }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "⬅️ العودة للقائمة الرئيسية",
                    id: ".menu"
                  })
                }
              ]
            })
          })
        }
      }
    }, { userJid: m.sender })

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

  } catch (err) {
    console.error(err)
    await conn.sendMessage(m.chat, { text: '❌ حدث خطأ أثناء تنفيذ الأمر.' }, { quoted: m })
  }
}

handler.command = /^قسم-جروب$/i
handler.tags = ["group"]
handler.help = ["قسم-جروب"]

export default handler