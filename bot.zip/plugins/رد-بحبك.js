let handler = async (m, { conn }) => {
  // ✅ تجاهل رسائل البوت نفسه
  if (m.fromMe) return;

  // ✅ تجاهل أي بوت تاني (اللي غالبًا JID بتاعه بينتهي بـ "bot")
  if (m?.sender && /bot/i.test(m.sender)) return;

  if (/بحبك/i.test(m.text)) { // يرصد وجود "بحبك" في أي مكان بالنص
    let replies = [
      '🤢 حبك برص وسبعه خرص يعلق 🪳',
      '🙄 روح العب بعيد يروح امك 🚮',
      '🤮 لم نفسك ي شذ 🏳️‍🌈'
    ];

    // 🌀 اختيار رد عشوائي
    let randomReply = replies[Math.floor(Math.random() * replies.length)];

    await conn.sendMessage(m.chat, {
      text: randomReply,
      contextInfo: {
        isForwarded: true,
        forwardingScore: 999,
        forwardedNewsletterMessageInfo: {
          newsletterJid: '120363407666513777@newsletter,
          newsletterName: '𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻',
          serverMessageId: 100
        },
        externalAdReply: {
          title: '𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻',
          body: 'اضغط هنا دعم 𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻',
          mediaType: 2,
          thumbnailUrl: 'https://files.catbox.moe/lsy7s8.jpg',
          mediaUrl: 'https://whatsapp.com/channel/0029VbCS3Q34SpkER26xwJ3u',
          showAdAttribution: true,
          renderLargerThumbnail: false
        }
      }
    }, { quoted: m });
  }
};

handler.customPrefix = /بحبك/i;
handler.command = new RegExp;
export default handler;