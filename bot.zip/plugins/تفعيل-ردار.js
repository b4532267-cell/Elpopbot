// plugins/رادار-تفعيل.js
// ⧼ 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓 ⧽ — تفعيل/تعطيل رادار المراقبة
// 𝐊𝐄𝐌𝐎! ⦓ 𝐊 ⦔ 𝐁𝐎𝐃𝐑𝐀𝐆𝐄𝐀

import { theme } from '../core/theme.js'

// ══════════════════════════════════════════════
// 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓 ✦ حقوق محفوظة لـ KEMO! ⦓ K ⦔ BODRAGEA
// ══════════════════════════════════════════════

let handler = async (m, { conn, args, usedPrefix, command, isAdmin, isOwner }) => {
    if (!(isAdmin || isOwner)) return global.dfail('admin', m, conn)

    let chat = global.db.data.chats[m.chat]
    if (!chat) return

    // ══ عرض الحالة الحالية ══
    if (!args[0]) {
        return m.reply(theme.build([
            { type: 'title',    text: '📡 رادِار الـمـراقـبـة' },
            { type: 'subtitle', text: '𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ✦ 𝐁𝐄𝐋𝐀𝐋! ⦓ 𝐊 ⦔' },
            { type: 'divider' },
            { type: 'info',     label: '📊 الحالة', value: chat.detect ? '✅ مـفـعـل' : '❌ مـعـطـل' },
            { type: 'divider' },
            { type: 'line',     text: '> عـنـدِ الـتـشـغـيـل، يـرصـدِ الـنـظـام كـافـة تـغـيـيـرات الـمـجـمـوُعـة تـلـقـائـيـاً' },
            { type: 'divider' },
            { type: 'info',     label: '▶️ تشغيل', value: `${usedPrefix}${command} on` },
            { type: 'info',     label: '⏹️ إيقاف', value: `${usedPrefix}${command} off` }
        ]))
    }

    // ══ تشغيل ══
    if (/^(on|تشغيل|1)$/i.test(args[0])) {
        if (chat.detect) {
            return m.reply(theme.build([
                { type: 'title', text: '📡 الـرادِار' },
                { type: 'line',  text: '> ✅ الـرادِار مـفـعـل مـن الأصـل يـسـطـا' }
            ]))
        }
        chat.detect = true
        return m.reply(theme.build([
            { type: 'title', text: '📡 تـم تـشـغـيـل الـرادِار ✅' },
            { type: 'line',  text: '> الـنـظـام يـرصـدِ الآن كـافـة تـغـيـيـرات الـمـجـمـوُعـة' },
            { type: 'divider' },
            { type: 'line',  text: '> 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ✦ 𝐁𝐄𝐋𝐀𝐋! ⦓ 𝐊 ⦔' }
        ]))
    }

    // ══ إيقاف ══
    if (/^(off|إيقاف|0)$/i.test(args[0])) {
        if (!chat.detect) {
            return m.reply(theme.build([
                { type: 'title', text: '📡 الـرادِار' },
                { type: 'line',  text: '> ❌ الـرادِار مـعـطـل مـن الأصـل يـسـطـا' }
            ]))
        }
        chat.detect = false
        return m.reply(theme.build([
            { type: 'title', text: '📡 تـم إيـقـاف الـرادِار ❌' },
            { type: 'line',  text: '> الـنـظـام لـن يـرصـدِ تـغـيـيـرات الـمـجـمـوُعـة بـعـدِ الآن' },
            { type: 'divider' },
            { type: 'line',  text: '> 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ✦ 𝐁𝐄𝐋𝐀𝐋! ⦓ 𝐊 ⦔' }
        ]))
    }

    // ══ أمر غير معروف ══
    m.reply(theme.build([
        { type: 'title', text: '❌ أمـر غـيـر صـحـيـح' },
        { type: 'info',  label: '▶️ تشغيل', value: `${usedPrefix}${command} on` },
        { type: 'info',  label: '⏹️ إيقاف', value: `${usedPrefix}${command} off` }
    ]))
}

// ══════════════════════════════════════════════
// Metadata — 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓
// ══════════════════════════════════════════════
handler.help = ['رادار']
handler.tags = ['group']
handler.command = /^(رادار|detect|المراقب)$/i
handler.group = true
handler.admin = true

export default handler
