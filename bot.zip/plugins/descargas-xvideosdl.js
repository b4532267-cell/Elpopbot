// plugins/xvideos-dl.js
// المكتبات المستخدمة: axios, cheerio (موجودين في package.json)

import axios   from 'axios'
import * as cheerio from 'cheerio'

const emoji  = '🎬'
const emoji2 = '⏳'
const msm    = '❌'

const HEADERS = {
    'User-Agent':      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Cookie':          'age_verified=1; nv=1'
}

const handler = async (m, { conn, args, usedPrefix, command }) => {

    if (!args[0])
        return m.reply(
            `${emoji} ابعت رابط فيديو من Xvideos.\n\n` +
            `مثال:\n*${usedPrefix + command}* https://www.xvideos.com/video70389849/xxx`
        )

    if (!args[0].includes('xvideos.com'))
        return m.reply(`${msm} الرابط غلط!\nلازم يكون من xvideos.com`)

    await m.reply(`${emoji2} جاري معالجة الفيديو، استنى لحظة...\n> وقت الإرسال بيعتمد على حجم الفيديو.`)

    try {
        const res = await xvideosDL(args[0])

        await conn.sendMessage(m.chat, {
            document: { url: res.url },
            mimetype: 'video/mp4',
            fileName: `${res.title || 'xvideos'}.mp4`,
            caption:
                `🎬 *${res.title || 'Xvideos'}*\n` +
                `👁️ المشاهدات: ${res.views}\n` +
                `👍 الإعجابات: ${res.likes}\n`
        }, { quoted: m })

    } catch (e) {
        console.error('[xvideosdl]', e?.message)
        return m.reply(
            `${msm} حصل خطأ!\n\n` +
            `تأكد إن الرابط صح:\n` +
            `◉ https://www.xvideos.com/video70389849/xxx`
        )
    }
}

handler.help     = ['xvideosdl <رابط>']
handler.tags     = ['nsfw']
handler.command  = /^(xvideosdl|xviddl)$/i
handler.register = false

export default handler

// ══════════════════════════════════════
//  دالة التحميل
// ══════════════════════════════════════
async function xvideosDL(url) {
    const { data } = await axios.get(url, {
        headers: HEADERS,
        timeout: 20000
    })

    const $ = cheerio.load(data, { xmlMode: false })

    const title   = $("meta[property='og:title']").attr('content') || 'xvideos'
    const views   = $("div#video-tabs div div div div strong.mobile-hide").text().trim() + ' views'
    const likes   = $("span.rating-good-nbr").text().trim()
    const thumb   = $("meta[property='og:image']").attr('content')

    let videoUrl =
        $("#html5video #html5video_base div a").attr('href') ||
        $("a.download-btn").attr('href')

    if (!videoUrl) {
        const patterns = [
            /html5player\.setVideoUrlHigh\('([^']+)'\)/,
            /html5player\.setVideoUrlLow\('([^']+)'\)/,
            /setVideoUrlHigh\('([^']+)'\)/,
            /"videoUrl"\s*:\s*"([^"]+\.mp4[^"]*)"/
        ]
        for (const p of patterns) {
            const match = data.match(p)
            if (match?.[1]) { videoUrl = match[1]; break }
        }
    }

    if (!videoUrl) throw new Error('مش قادر أجيب رابط الفيديو')

    return { title, url: videoUrl, views, likes, thumb }
}