let handler = async (m, { args, isAdmin }) => {
if (!isAdmin) return m.reply('❌ للمشرفين فقط');

let chat = global.db.data.chats[m.chat];

if (args[0] === 'on') {
chat.antiLink = true;
m.reply('*شـــغـــال يـــكـــســـمـــك 🫩🫩*');
} else if (args[0] === 'off') {
chat.antiLink = false;
m.reply('*مـــش شـــغـــال يـــكـــســـمـــك 🫩🫩*');
} else {
m.reply('استخدم:\n.antilink on\n.antilink off');
}
};

handler.command = ['antilink'];
export default handler;