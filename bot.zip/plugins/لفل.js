import fetch from 'node-fetch';
import FormData from 'form-data';
import fs from 'fs';
import { canLevelUp, xpRange } from '../lib/levelling.js';

let handler = async (m, { conn }) => {
  let name = conn.getName(m.sender);
  let user = global.db.data.users[m.sender];
  
  let pp;
  try {
      pp = await conn.profilePictureUrl(m.sender, 'image');
  } catch {
      pp = 'https://i.ibb.co/m53WF9N/avatar-contact.png'; 
  }
  
  let data = await uploadFile(pp);
  let avatar = data.files[0]?.url;
  if (!avatar) throw "لم يتم العثور على رابط الصورة بعد الرفع.";


  const apiUrl = `https://qu.ax/dibUg.jpg`;

  try {
    const response = await fetch(apiUrl);
    const buffer = await response.buffer();
    const caption = `*⎔ ⋅ ───━ •﹝🐦‍🔥﹞• ━─── ⋅ ⎔*\n*⌝ معلومات حسابك┋⚙️⌞ ⇊*\n*🕋┊اسمك┊⇇『${name}』*\n*🪄┊المستوى الجديد┊⇇『${user.level}』*\n*📝┊نقاط الخبرة┊⇇『${user.exp}』*\n*😮‍💨┊نقاط المطلوبه للمستوى التالي┊⇇『${user.exp_to_next_level}』*\n*⎔ ⋅ ───━ •﹝🐦‍🔥﹞• ━─── ⋅ ⎔*\n> 𝐄𝐋 𝐏𝐎𝐏 BOT\n`;

    await conn.sendFile(m.chat, buffer, 'rank-image.png', caption, m);
  } catch (error) {
    console.error(error);
    await conn.reply(m.chat, '❌ حدث خطأ أثناء جلب صورة المستوى. يرجى المحاولة مرة أخرى لاحقًا.', m);
  }
};

handler.help = ['nivel', 'lvl', 'levelup', 'level'];
handler.tags = ['rpg'];
handler.command = ['لفل', 'nivel', 'lvl', 'levelup', 'level']; 
handler.register = true;

export default handler;

async function uploadFile(url) {
  const response = await fetch(url);
  const buffer = await response.buffer();
  const path = './temp_image.png';
  fs.writeFileSync(path, buffer);

  let form = new FormData();
  form.append('files[]', fs.createReadStream(path));

  let res = await (await fetch('https://uguu.se/upload.php', {
    method: 'POST',
    headers: {
      ...form.getHeaders()
    },
    body: form
  })).json();


  await fs.promises.unlink(path);
  return res;
}