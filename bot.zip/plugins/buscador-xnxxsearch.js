// plugins/xnxx-search.js
import axios   from 'axios';
import * as cheerio from 'cheerio';

const emoji = '🎬'
const msm   = '❌'

const handler = async (m, { conn, text, usedPrefix, command }) => {

    if (!text) {
        return m.reply(`${emoji} اكتب اسم الفيديو.\nمثال: *${usedPrefix + command} con mi prima*`)
    }

    try {
        if (!global.videoListXXX) global.videoListXXX = []
        const idx = global.videoListXXX.findIndex(v => v.from === m.sender)
        if (idx !== -1) global.videoListXXX.splice(idx, 1)

        const res  = await xnxxSearch(text)
        const json = res.result

        if (!json.length) {
            return m.reply(`😔 مفيش نتائج لـ: *${text}*`)
        }

        const vids_ = { from: m.sender, urls: [] }
        let cap = `*${emoji} نتائج البحث:* ${text.toUpperCase()}\n\n`
        let count = 1

        for (const v of json) {
            vids_.urls.push(v.link)
            cap += `*[${count}]*\n`
            cap += `• *🎬 العنوان:* ${v.title || 'غير متاح'}\n`
            cap += `• *🔗 الرابط:* ${v.link}\n`
            cap += `• *❗ معلومات:* ${v.info || '-'}\n\n`
            cap += '━━━━━━━━━━━━━━━━━━━━\n\n'
            count++
        }

        global.videoListXXX.push(vids_)
        await conn.sendMessage(m.chat, { text: cap }, { quoted: m })

    } catch (e) {
        console.error('[xnxx]', e?.message)
        return m.reply(`${msm} حصل خطأ: ${e?.message || 'حاول تاني'}`)
    }
}

handler.help    = ['xnxxsearch <query>']
handler.tags    = ['nsfw']
handler.command = /^(xnxxsearch|xnxxs)$/i
handler.register = false

export default handler

// ══════════════════════════════════════
//  دالة البحث
// ══════════════════════════════════════
async function xnxxSearch(query) {
    const baseurl  = 'https://www.xnxx.com'
    const page     = Math.floor(Math.random() * 3) + 1
    const { data } = await axios.get(
        `${baseurl}/search/${encodeURIComponent(query)}/${page}`,
        {
            headers: {
                'User-Agent':      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
                'Accept-Language': 'en-US,en;q=0.9'
            },
            timeout: 15000
        }
    )

    const $       = cheerio.load(data, { xmlMode: false })
    const titles  = []
    const urls    = []
    const descs   = []
    const results = []

    $('div.mozaique').each((_, b) => {
        $(b).find('div.thumb').each((_, d) => {
            const href = $(d).find('a').attr('href')
            if (href) urls.push(baseurl + href.replace('/THUMBNUM/', '/'))
        })
    })

    $('div.mozaique').each((_, b) => {
        $(b).find('div.thumb-under').each((_, d) => {
            descs.push($(d).find('p.metadata').text().trim())
            $(d).find('a').each((_, f) => {
                titles.push($(f).attr('title'))
            })
        })
    })

    for (let i = 0; i < Math.min(titles.length, 10); i++) {
        if (titles[i] && urls[i]) {
            results.push({ title: titles[i], info: descs[i] || '-', link: urls[i] })
        }
    }

    return { code: 200, status: true, result: results }
}