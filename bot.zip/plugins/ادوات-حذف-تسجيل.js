import db from '../lib/database.js';
import fetch from 'node-fetch';

let handler = async function (m, { conn }) {
  let user = global.db.data.users[m.sender];
  let name2 = conn.getName(m.sender);

  if (user.registered !== true) {
    return m.reply(`*⚡ يا ${name2}, لم يتم العثور على أي سجل نينجا لك!*`);
  }

  let imgUrl = 'https://qu.ax/dibUg.jpg';

  let imgBuffer;
  try {
    imgBuffer = await (await fetch(imgUrl)).buffer();
  } catch (error) {
    console.error('[ERROR] لم يتمكن من تحميل الصورة:', error);
    return m.reply('[⚡] حدث خطأ أثناء تحميل صورة الحذف.');
  }

  user.name = '';
  user.age = -1;
  user.regTime = -1;
  user.registered = false;

  let now = new Date();
  let date = now.toLocaleDateString('ar-AR', { year: 'numeric', month: 'long', day: 'numeric' });

  let txt = `╭══•ೋ✧⚡✧ೋ•══╮
*『 إلغاء تسجيل ألعصابة 』*
╰══•ೋ✧⚡✧ೋ•══╯
*❌ تم حذف بياناتك بنجاح!*
*🗓️ التاريخ:* ${date}
*⚠️ لا يمكنك استخدام ميزات ألعصابة إلا بعد إعادة التسجيل مجددًا.*

*إلى اللقاء أيها الوميض.. ربما نلتقي في مهمة أخرى.*`;

  let dev = '『 ⚡𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ⚡ 』';

  await conn.sendMessage(m.chat, {
    image: imgBuffer,
    caption: txt,
    footer: dev,
    buttons: [
      {
        buttonId: `.تسجيل`,
        buttonText: { displayText: '🔁 إعادة التسجيل' },
      },
      {
        buttonId: `.menu`,
        buttonText: { displayText: '☁️ القائمة' },
      },
    ],
    viewOnce: true,
    headerType: 4,
  }, { quoted: m });

  await m.react('❌');
};

handler.help = ['حذف-تسجيل'];
handler.tags = ['start'];
handler.command = ['unreg', 'unregister', 'delete', 'حذف-تسجيل'];

export default handler;