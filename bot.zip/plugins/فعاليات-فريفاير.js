import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';
import fetch from 'node-fetch';
import { translate } from '@vitalets/google-translate-api';

const timeout = 60000;

let handler = async (m, { conn }) => {
    try {
        conn.obito = conn.obito || {};
        let id = m.chat;

        if (conn.obito[id]) {
            return conn.reply(m.chat, "*⎔ ⋅ ───━ •﹝🐦‍🔥﹞• ━─── ⋅ ⎔*\n*_لا يمكنك بدء لعبة جديدة، اللعبة الحالية لم تنتهِ بعد ❌🐦‍🔥_*\n*⎔ ⋅ ───━ •﹝🐦‍🔥﹞• ━─── ⋅ ⎔*", m);
        }


        const response = await fetch('https://api.siputzx.my.id/api/games/karakter-freefire');
        const data = await response.json();

        if (!data || !data.status || !data.data) {
            throw new Error("❌ فشل الحصول على بيانات السؤال من API");
        }

        let { name, gambar } = data.data;


        let translatedAnswer = await translate(name, { to: 'ar' });
        translatedAnswer = translatedAnswer.text;


        const options = new Set([translatedAnswer]); 
        while (options.size < 4) {
            let randomResponse = await fetch('https://api.siputzx.my.id/api/games/karakter-freefire');
            let randomData = await randomResponse.json();
            if (randomData?.data?.name) {
                let translatedOption = await translate(randomData.data.name, { to: 'ar' });
                if (!options.has(translatedOption.text)) {
                    options.add(translatedOption.text);
                }
            }
        }

        let shuffledOptions = Array.from(options).sort(() => Math.random() - 0.5); 

        const media = await prepareWAMessageMedia({ image: { url: gambar } }, { upload: conn.waUploadToServer });

        const interactiveMessage = {
            body: {
                text: "*⎔ ⋅ ───━ •﹝🐦‍🔥﹞• ━─── ⋅ ⎔*\n*لعبة تخمين اسم شخصية فري فاير 🎮*\n\n*⌝ معلومات اللعبة ┋🪄⌞ ⇊*\n*🐦‍🔥┊الوقت┊⇇『60 ثانية』*\n*🐦‍🔥┊الجائزة┊⇇『500xp』*\n*⎔ ⋅ ───━ •﹝🐦‍🔥﹞• ━─── ⋅ ⎔*",
            },
            footer: { text: "𝑀𝐼𝑁𝐴𝑇𝛩 𝐵𝛩𝑇" },
            header: {
                title: "ㅤ",
                subtitle: "اختر اسم الشخصية الصحيحة من الخيارات ⇊",
                hasMediaAttachment: true,
                imageMessage: media.imageMessage,
            },
            nativeFlowMessage: {
                buttons: shuffledOptions.map((option, index) => ({
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: `🎮┊${index + 1}┊⇇『${option}』`,
                        id: `.اجابة_${index + 1}`
                    })
                })),
            },
        };

        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: { interactiveMessage },
            },
        }, { userJid: conn.user.jid, quoted: m });

        conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });


        conn.obito[id] = {
            correctAnswer: translatedAnswer,
            options: shuffledOptions,
            timer: setTimeout(async () => {
                if (conn.obito[id]) {
                await conn.reply(m.chat, `*⎔ ⋅ ───━ •﹝🐦‍🔥﹞• ━─── ⋅ ⎔*\n*⌛┊⇇ انتهى الوقت*\n*🐦‍🔥┊الإجابة الصحيحة┊⇇『${translatedAnswer}』*\n*⎔ ⋅ ───━ •﹝🐦‍🔥﹞• ━─── ⋅ ⎔*`, m);
                    delete conn.obito[id];
                }
            }, timeout),
            attempts: 2
        };

    } catch (e) {
        console.error(e);
        conn.reply(m.chat, "🚨 حدث خطأ أثناء جلب السؤال أو الترجمة من API", m);
    }
};

handler.help = ["لعبة_فري_فاير"];
handler.tags = ["games"];
handler.command = /^(فريفاير|فري|اجابة_\d+)$/i;

export default handler;