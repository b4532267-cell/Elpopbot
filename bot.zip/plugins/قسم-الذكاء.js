import pkg from '@whiskeysockets/baileys'
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg

const handler = async (m, { conn }) => {
  try {
    const imageUrl = "https://files.catbox.moe/5o36un.jpg"
    const media = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer })

    await conn.sendMessage(m.chat, { react: { text: '🕷️', key: m.key } })

    const caption = `
╭━━〔🤖 ﻗـسـم الـذكـاء 🤖〕━━⬣
┃ ➟ *مرحباً بك يا* 『${m.pushName}』
┃ ➟ *داخل بوت* 𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻
╰━━━━━━━━━━━━⬣

╭━━〔🧠 أوامـر الـذكـاء 🧠〕━━⬣
┃ ⇇ *اوبو* ⚡
┃ ⇇ *بودي* 💎
┃ ⇇ *بوت* 🤖
┃ ⇇ *اوبيتو* 🔥
┃ ⇇ *بروفيسور* 🎓
┃ ⇇ *بلاك* 🌑
┃ ⇇ *بوت2* ⚙️
┃ ⇇ *بودي2* 💎
┃ ⇇ *ديبسيك* 👁️
┃ ⇇ *شيخ* ☪️
┃ ⇇ *مريم* 🌹
┃ ⇇ *بـودي* 🕷️
┃ ⇇ *ناميكازي* ⚡
┃ ⇇ *هوكاجي2* 🌀
╰━━━━━━━━━━━━⬣

> 💡 *استمتع بالابداع مع مطور البوت 𝐁𝐄𝐋𝐀𝐋*
`.trim()

    let msg = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: caption },
            footer: { text: '⦓ 𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻 ⦔' },
            header: { hasMediaAttachment: true, ...media },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "⬅️ العودة للقائمة الرئيسية",
                    id: ".menu"
                  })
                }
              ]
            }
          }
        }
      }
    }

    await conn.relayMessage(m.chat, msg, {})

  } catch (err) {
    console.error(err)
    await conn.sendMessage(m.chat, { text: '❌ حدث خطأ.' }, { quoted: m })
  }
}

handler.command = /^قسم-الذكاء$/i
handler.tags = ["ai", "ذكاء"]
handler.help = ["قسم-الذكاء"]

export default handler