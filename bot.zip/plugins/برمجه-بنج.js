import { cpus as _cpus, totalmem, freemem } from 'os'
import os from 'os'
import fetch from 'node-fetch'
import { performance } from 'perf_hooks'
import { sizeFormatter } from 'human-readable'

let format = sizeFormatter({
  std: 'JEDEC',
  decimalPlaces: 2,
  keepTrailingZeroes: false,
  render: (literal, symbol) => `${literal} ${symbol}B`,
})

let handler = async (m, { conn, usedPrefix, command }) => {
  try {
    let _muptime
    if (process.send) {
      process.send('uptime')
      _muptime = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }

    let muptime = clockString(_muptime)
    const chats = Object.entries(conn.chats).filter(([id, data]) => id && data.isChats)
    const groupsIn = chats.filter(([id]) => id.endsWith('@g.us'))
    const used = process.memoryUsage()
    const cpus = _cpus().map(cpu => {
      cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
      return cpu
    })

    const cpu = cpus.reduce((last, cpu, _, { length }) => {
      last.total += cpu.total
      last.speed += cpu.speed / length
      last.times.user += cpu.times.user
      last.times.nice += cpu.times.nice
      last.times.sys += cpu.times.sys
      last.times.idle += cpu.times.idle
      last.times.irq += cpu.times.irq
      return last
    }, {
      speed: 0,
      total: 0,
      times: {
        user: 0,
        nice: 0,
        sys: 0,
        idle: 0,
        irq: 0
      }
    })

    let msgTxt = `🐦‍🔥 جاري اختبار السرعة...`
    let old = performance.now()
    const { key } = await conn.sendMessage(m.chat, { text: msgTxt }, { quoted: m })

    let neww = performance.now()
    let speed = neww - old
    let caption = `*🚀 سرعة البوت 🐦‍🔥*

📡 *الزمن المستغرق:* ${Math.round(speed)} مللي ثانية

⏱ *الوقت منذ التشغيل:* ${muptime}

*المحادثات النشطة:*
▢ *${groupsIn.length}* مجموعات
▢ *${chats.length - groupsIn.length}* محادثات خاصة
▢ *${chats.length}* المجموع الكلي

*معلومات النظام:*
🟢 *RAM:* ${format(totalmem() - freemem())} / ${format(totalmem())}
🔵 *RAM المتاح:* ${format(freemem())}
💻 *النظام:* \`${os.platform()}\`
📡 *اسم الجهاز:* ${os.hostname()}
⏳ *المدة:* ${toTime(os.uptime() * 1000)}

*🧠 استخدام الذاكرة:*
${'```' + Object.keys(used).map(key => `${key.padEnd(10)}: ${format(used[key])}`).join('\n') + '```'}

${cpus[0] ? `*🧠 استخدام المعالج:*
${cpus[0].model.trim()} (${cpu.speed} MHz)

${Object.keys(cpu.times).map(type => `- ${(type).padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}

*المعالجات (${cpus.length} نواة):*
${cpus.map((cpu, i) => `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHz)\n${Object.keys(cpu.times).map(type => `- ${(type).padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}`).join('\n\n')}` : ''}

𝐄𝐋 𝐏𝐎𝐏 𝐁Ⓧ𝐓🐦‍🔥
`
    await conn.sendMessage(m.chat, { text: caption, edit: key })
  } catch (e) {
    m.reply(`⚠️ حدث خطأ أثناء تنفيذ الأمر 🐦‍🔥\n\n*استخدم الأمر التالي للتبليغ:* #report\n\n> ${e}`)
    console.error(e)
  }
}
handler.help = ['ping', 'speed', 'بنج', 'السرعه', 'السرعة', 'سرعه']
handler.tags = ['main']
handler.command = /^(ping|speed|بنج|السرعه|السرعة|سرعه|velocidad|rapidez|velocity)$/i
handler.register = true
export default handler

function clockString(ms) {
  let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000)
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return `${d} يوم, ${h} ساعة, ${m} دقيقة, ${s} ثانية`
}

function toTime(ms) {
  const sec = Math.floor(ms / 1000)
  const min = Math.floor(sec / 60)
  const hrs = Math.floor(min / 60)
  const days = Math.floor(hrs / 24)
  return `${days} يوم, ${hrs % 24} ساعة, ${min % 60} دقيقة, ${sec % 60} ثانية`
}