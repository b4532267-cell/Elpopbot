import pkg from '@whiskeysockets/baileys'
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg

let handler = async (m, { conn }) => {
  try {
    await conn.sendMessage(m.chat, { react: { text: '⭐', key: m.key } })

    const Elsony = 'https://files.catbox.moe/wfs4py.jpeg'
    const media = await prepareWAMessageMedia(
      { image: { url: Elsony } },
      { upload: conn.waUploadToServer }
    )

    const sections = [
      {
        title: '━━━━━━━ ⚡ تـقـيـيـمـاتك ⚡ ━━━━━━━',
        highlight_label: '🌟 تقييم البوت',
        rows: [
          { title: '⭐',          description: 'تـحـت الـمـسـتـوي 🛠️',          id: 'rate_1' },
          { title: '⭐⭐',        description: 'مـقـبـول نـوعـاً مـا 📈',         id: 'rate_2' },
          { title: '⭐⭐⭐',      description: 'جـيـد جـداً يـا بـطـل ✨',        id: 'rate_3' },
          { title: '⭐⭐⭐⭐',    description: 'مـمـتـاز ورايـق 😍',              id: 'rate_4' },
          { title: '⭐⭐⭐⭐⭐',  description: 'أقـوي بـوت فـي الـمـجـال 👑',    id: 'rate_5' },
        ]
      }
    ]

    const buttons = [
      {
        name: 'single_select',
        buttonParamsJson: JSON.stringify({
          title: '🍫 قـائـمـة الـنـجـوم 🍫',
          sections
        })
      }
    ]

    const text = `
┏━━━━━━━━━━━━━━━┓
┃  🍫  *تــقــيــيــم الــبــوت* 🍫
┗━━━━━━━━━━━━━━━┛
┃ 👤 *الـمـطـور:* 𝐁𝐄𝐋𝐀𝐋 🩸
┃ 🤖 *الـبـوت:* 𝐄𝐋 𝐏𝐎𝐏 𝐁Ⓧ𝐓
┗━━━━━━━━━━━━━━━┛
🌟 اختـار تـقـيـيـمـك مـن القـائـمـة`

    const msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            header: proto.Message.InteractiveMessage.Header.create({
              title: '',
              hasMediaAttachment: true,
              ...media
            }),
            body:   proto.Message.InteractiveMessage.Body.create({ text }),
            footer: proto.Message.InteractiveMessage.Footer.create({ text: '🍫 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 🍫' }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons })
          })
        }
      }
    }, { userJid: m.sender })

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

  } catch (e) {
    console.error('[تقييم]', e)
    await conn.sendMessage(m.chat, { text: '❌ حدث خطأ، حاول مرة ثانية' }, { quoted: m })
  }
}

handler.command = /^(تقيم|تقييم)$/i
export default handler
