import { canLevelUp, xpRange } from '../lib/levelling.js'
import { levelup } from '../lib/canvas.js'

let handler = async (m, { conn, command }) => {
    let name = conn.getName(m.sender)
    let user = global.db.data.users[m.sender]

    // رسالة توضيحية بناءً على اسم الأمر المستخدم
    let usageMessage = ''
    if (command === 'nivel' || command === 'levelup') {
        usageMessage = `🎮 *كيفية استخدام الأمر:*\n\nاستخدم الأمر *${command}* للتحقق من مستوى حسابك وتجربة رفع مستوى جديد. مثال: \n➤ ${command}\n\n🔸 هذا الأمر يعرض لك مستوى حسابك الحالي والنقاط المطلوبة للترقية.`
    } else {
        usageMessage = `❗ *يرجى استخدام الأمر الصحيح*`
    }

    // التحقق من إذا كان المستخدم يمكنه الترقية
    if (!canLevelUp(user.level, user.role, user.exp, global.multiplier)) {
        let { min, xp, max } = xpRange(user.level, global.multiplier)
        throw `『 *إحصائياتك 🆙* 』

إحصائياتك في الوقت الفعلي 🕐

├─ ❏ *الاسم*:  ${name}
├─ ❏ *XP 🆙*: ${user.exp - min}/${xp}
├─ ❏ *المستوى*: ${user.level}
└─ ❏ *الرنق*: ${user.role}

> أنت بحاجة إلى *${max - user.exp}* من *XP* للترقية إلى المستوى التالي
`.trim()
    }

    let before = user.level * 1
    while (canLevelUp(user.level, user.exp, global.multiplier)) user.level++

    if (before !== user.level) {
        let teks = `🎊 مبروك ${conn.getName(m.sender)} لقد وصلت إلى مستوى جديد:`
        let str = `*[ LEVEL UP ]*
        
*• المستوى السابق*: ${before}
*• المستوى الحالي*: ${user.level}
*• الرنق*: ${user.role}

> _كلما تفاعلت أكثر مع البوتات، كلما زاد مستواك_
`.trim()
        
        try {
            const img = await levelup(teks, user.level)
            conn.sendFile(m.chat, img, 'levelup.jpg', str, m, null, fake)
        } catch (e) {
            conn.fakeReply(m.chat, str, '13135550002@s.whatsapp.net', `*إحصائياتك 🆙*`, 'status@broadcast', null, fake)
        }
    }
};

// إضافة أوامر عربية بجانب الأوامر الإنجليزية
handler.help = ['levelup', 'لفل']
handler.tags = ['rpg']
handler.command = ['nivel', 'lvl', 'levelup', 'level', 'لفل'] 

// إضافة التوقيع
handler.register = true
export default handler