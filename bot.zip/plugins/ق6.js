import pkg from '@whiskeysockets/baileys'
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg

const handler = async (m, { conn }) => {
  try {
    let name = conn.getName(m.sender) || 'مستخدم'

    await conn.sendMessage(m.chat, { react: { text: '🏦', key: m.key } })

    // 🖼️ الصورة المثبتة الرسمية لبوتك
    const imageUrl = "https://files.catbox.moe/5o36un.jpg"
    const media = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer })

    // 📋 تنسيق الأوامر والاسم الجديد بالإيموجي 🍫 تحت بعض بالملي وبدون أعلام
    const caption = `
╭━━〔🏦 ﻗـسـم الـبـنـك 🏦〕━━⬣
┃ ➟ *مرحباً بك يا* 『${name}』
┃ ➟ *داخل بوت* 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 🍫
╰━━━━━━━━━━━━⬣

╭━━〔🍬 أوامـر الـبـنـك 🍬〕━━⬣
┃ ➟ 🏦 *.بنك*
┃ ➟ 📊 *.رانك*
┃ ➟ 📤 *.سحب*
┃ ➟ 📥 *.ايداع*
┃ ➟ 📆 *.يومي*
┃ ➟ 🗓️ *.اسبوعي*
┃ ➟ 💼 *.محفظة*
┃ ➟ 📝 *.تسجيل*
┃ ➟ 🆔 *.تعريفي*
┃ ➟ 🎲 *.رهان*
┃ ➟ 🎡 *.عجلة_الحظ*
┃ ➟ 🪙 *.عملاتي*
┃ ➟ 💰 *.عملات*
┃ ➟ 💵 *.راتب*
┃ ➟ 💵 *.دولار*
┃ ➟ 💎 *.لجواهر*
┃ ➟ 💎 *.الماس*
┃ ➟ ⚔️ *.هجوم*
╰━━━━━━━━━━━━⬣
`.trim()

    const msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            header: proto.Message.InteractiveMessage.Header.create({ title: '', hasMediaAttachment: true, ...media }),
            body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
            footer: proto.Message.InteractiveMessage.Footer.create({ text: '⦓ 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ⦔' }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "⬅️ العودة للقائمة الرئيسية",
                    id: ".menu"
                  })
                }
              ]
            })
          })
        }
      }
    }, { userJid: m.sender })

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

  } catch (err) {
    console.error(err)
    await conn.sendMessage(m.chat, { text: '❌ حدث خطأ أثناء تنفيذ الأمر.' }, { quoted: m })
  }
}

handler.command = /^(ق6)$/i
handler.tags = ["economy"]
handler.help = ["ق6"]

export default handler