// plugins/kemo_fancy.js

const arabicWideMap = {
    'ا': ['ا', 'آ', 'أ', 'إ'],
    'ب': ['بـ', 'بّـ'],
    'ت': ['تـ', 'تّـ'],
    'ث': ['ثـ'],
    'ج': ['جـ', 'چـ'],
    'ح': ['حـ'],
    'خ': ['خـ'],
    'د': ['د'],
    'ذ': ['ذ'],
    'ر': ['ࢪ'],
    'ز': ['ز'],
    'س': ['سـ', 'ࡄـ'],
    'ش': ['شـ'],
    'ص': ['صـ'],
    'ض': ['ضـ'],
    'ط': ['طـ', 'طٌـ'],
    'ظ': ['ظـ'],
    'ع': ['؏ـ'],
    'غ': ['غـ'],
    'ف': ['فـ', 'ᓅـ'],
    'ق': ['قـ', 'ܧـ'],
    'ك': ['ڪـ', 'كـ'],
    'ل': ['لـ'],
    'م': ['مـ'],
    'ن': ['نـ', 'نّـ'],
    'ه': ['هـ', 'ہـ'],
    'و': ['و', 'ۉ'],
    'ي': ['يـ'],
    'ة': ['ة', 'ہ'],
    'ى': ['ى', 'ىٰ'],
    'ء': ['ء']
};

const endArabicMap = {
    'ل': ['ل', 'ݪ'],
    'ش': ['ش'], 'ن': ['ن'], 'ع': ['ع'], 'ي': ['ي', 'ىٰ'], 'ك': ['ك', 'ڪ'], 'ه': ['ه', 'ہ'],
    'ب': ['ب'], 'ت': ['ت'], 'ث': ['ث'], 'ج': ['ج'], 'ح': ['ح'], 'خ': ['خ'], 'ص': ['ص'],
    'ض': ['ض'], 'ط': ['ط'], 'ظ': ['ظ'], 'غ': ['غ'], 'ف': ['ف'], 'ق': ['ق'], 'م': ['م'],
    'ر': ['ࢪ'], 'ز': ['ز'], 'د': ['د'], 'ذ': ['ذ'], 'و': ['و']
};

const englishAndNumbersMap = {
    '0': '𝟎', '1': '𝟏', '2': '𝟐', '3': '𝟑', '4': '𝟒',
    '5': '𝟓', '6': '𝟔', '7': '𝟕', '8': '𝟖', '9': '𝟗',
    'A': '𝐀', 'B': '𝐁', 'C': '𝐂', 'D': '𝐃', 'E': '𝐄',
    'F': '𝐅', 'G': '𝐆', 'H': '𝐇', 'I': '𝐈', 'J': '𝐉',
    'K': '𝐊', 'L': '𝐋', 'M': '𝐌', 'N': '𝐍', 'O': '𝐎',
    'P': '𝐏', 'Q': '𝐐', 'R': '𝐑', 'S': '𝐒', 'T': '𝐓',
    'U': '𝐔', 'V': '𝐕', 'W': '𝐖', 'X': '𝐗', 'Y': '𝐘', 'Z': '𝐙',
    'a': '𝐚', 'b': '𝐛', 'c': '𝐜', 'd': '𝐝', 'e': '𝐞',
    'f': '𝐟', 'g': '𝐠', 'h': '𝐡', 'i': '𝐢', 'j': '𝐣',
    'k': '𝐤', 'l': '𝐥', 'm': '𝐦', 'n': '𝐧', 'o': '𝐨',
    'p': '𝐩', 'q': '𝐪', 'r': '𝐫', 's': '𝐬', 't': '𝐭',
    'u': '𝐮', 'v': '𝐯', 'w': '𝐰', 'x': '𝐱', 'y': '𝐲', 'z': '𝐳'
};

const nonConnecting = ['ا', 'آ', 'أ', 'إ', 'د', 'ذ', 'ر', 'ࢪ', 'ز', 'و', 'ۉ', 'ة', 'ہ'];

function makeWide(text) {
    const words = text.split(' ');
    return words.map(word => {
        const chars = word.split('');
        let renderedChars = [];
        for (let index = 0; index < chars.length; index++) {
            const char     = chars[index];
            const nextChar = index < chars.length - 1 ? chars[index + 1] : null;
            const isEnd    = index === chars.length - 1;
            const prevChar = index > 0 ? chars[index - 1] : null;

            if (englishAndNumbersMap[char]) {
                renderedChars.push(englishAndNumbersMap[char]);
                continue;
            }
            if (char === 'ل' && nextChar && ['ا', 'أ', 'إ', 'آ'].includes(nextChar)) {
                renderedChars.push(char + nextChar);
                index++;
                continue;
            }
            if (isEnd) {
                let endChar = char;
                if (endArabicMap[char]) {
                    const endOptions = endArabicMap[char];
                    endChar = endOptions[Math.floor(Math.random() * endOptions.length)];
                } else {
                    const decorated = arabicWideMap[char];
                    if (decorated) {
                        const randomChar = decorated[Math.floor(Math.random() * decorated.length)];
                        endChar = randomChar.endsWith('ـ') ? randomChar.slice(0, -1) : randomChar;
                    }
                }
                if (prevChar && nonConnecting.includes(prevChar) && endChar.startsWith('ـ')) {
                    endChar = endChar.slice(1);
                }
                renderedChars.push(endChar);
                continue;
            }
            const decorated = arabicWideMap[char];
            if (!decorated) { renderedChars.push(char); continue; }

            let randomChar = decorated[Math.floor(Math.random() * decorated.length)];
            if (prevChar && nonConnecting.includes(prevChar) && randomChar.startsWith('ـ')) {
                randomChar = randomChar.slice(1);
            }
            if (nonConnecting.includes(char)) {
                if (randomChar.endsWith('ـ')) randomChar = randomChar.slice(0, -1);
                renderedChars.push(randomChar);
                continue;
            }
            if (randomChar.endsWith('ـ') && char !== 'ل') {
                const decorations = [randomChar + 'ـ', randomChar + 'ـہـ'];
                randomChar = decorations[Math.floor(Math.random() * decorations.length)];
            }
            renderedChars.push(randomChar);
        }
        return renderedChars.join('');
    }).join(' ');
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw '*◑ • ─ ⌯┅┉⌯ •﹝📢﹞• ⌯┅┉⌯ ─ • ◐*\n\n*❖┊⪼ اكتب النص اللي عايز تزخرفه يا وحش*\n*مثال:* ' + usedPrefix + command + ' كيمو 10 SATO\n\n*⎔⋅• ─┈╌⬪─═✥═─⬪╌┈─ •⋅⎔*';

    let decoratedResult = makeWide(text);

    // ✅ إصلاح: استخدام string عادية بدل template literal عشان فيه backtick جوا النص
    let finalLayout =
        '*◑ • ─ ⌯┅┉⌯ •﹝🎭﹞• ⌯┅┉⌯ ─ • ◐*\n' +
        '*⥍˹ 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ˼\u200f⥌⥃⸂❄⸃*\n' +
        '*◑ • ─ ⌯┅┉⌯ •﹝🎭﹞• ⌯┅┉⌯ ─ • ◐*\n\n' +
        '*❖┊⪼ • `النص الأصلي` •*\n' +
        '*' + text + '*\n\n' +
        '*˼\u200f🍷˹┊الزخرفة ⬪⥃ ⸂ *『 *' + decoratedResult + '* 』* ⸃*\n\n' +
        '*⎔⋅• ─┈╌⬪─═✥═─⬪╌┈─ •⋅⎔*\n' +
        '*~`⧉┊ 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 🍷↯`~*';

    await conn.sendMessage(m.chat, { text: finalLayout }, { quoted: m });
};

handler.help    = ['زخرفه', 'زغرفه'];
handler.tags    = ['tools'];
handler.command = /^(زخرفه|زخرفة|زغرفه|زغرفة)$/i;

export default handler;
