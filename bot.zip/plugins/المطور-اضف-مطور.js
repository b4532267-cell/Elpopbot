let handler = async (m, { conn, text, usedPrefix, command }) => {
    let who;
    
    // ✅ تحسين طريقة تحديد المستخدم
    if (m.isGroup) {
        if (m.mentionedJid && m.mentionedJid[0]) {
            who = m.mentionedJid[0];
        } else if (m.quoted) {
            who = m.quoted.sender;
        } else if (text) {
            // ✅ معالجة النص إذا كان رقم أو معرف
            let input = text.trim();
            if (input.includes('@')) {
                who = input;
            } else if (input.match(/^\d+$/)) {
                who = input + '@s.whatsapp.net';
            } else {
                throw '❌ قم بالإشارة إلى الشخص أو أرسل الرقم بشكل صحيح';
            }
        } else {
            throw '❌ قم بالإشارة إلى الشخص الذي تريده أن يصبح مطوراً';
        }
    } else {
        who = m.chat;
    }
    
    const userId = who.split('@')[0];
    
    // ✅ التحقق من هيكل global.owner
    let ownerList = [];
    if (global.owner) {
        if (Array.isArray(global.owner)) {
            if (typeof global.owner[0] === 'string') {
                // إذا كانت المصفوفة تحتوي على أرقام فقط
                ownerList = global.owner;
            } else if (Array.isArray(global.owner[0])) {
                // إذا كانت المصفوفة تحتوي على مصفوفات [رقم, اسم]
                ownerList = global.owner.map(o => o[0]);
            }
        }
    }
    
    // ✅ التحقق إذا كان المستخدم مطوراً بالفعل
    if (ownerList.includes(userId)) {
        throw `❌ المستخدم @${userId} مطور بالفعل!`;
    }
    
    // ✅ التحقق من وجود قاعدة بيانات
    if (!global.db || !global.db.data) {
        throw '❌ قاعدة البيانات غير متاحة!';
    }
    
    // ✅ إضافة المطور إلى قاعدة البيانات (للحفظ الدائم)
    if (!global.db.data.users[who]) {
        global.db.data.users[who] = {
            name: m.name || userId,
            registered: false
        };
    }
    
    // ✅ إضافة إلى global.owner حسب هيكله
    if (global.owner) {
        if (Array.isArray(global.owner)) {
            if (typeof global.owner[0] === 'string') {
                // هيكل بسيط: ["رقم1", "رقم2"]
                global.owner.push(userId);
            } else if (Array.isArray(global.owner[0])) {
                // هيكل معقد: [["رقم1", "اسم1"], ["رقم2", "اسم2"]]
                global.owner.push([userId, global.db.data.users[who]?.name || userId, true]);
            }
        }
    } else {
        global.owner = [userId];
    }
    
    // ✅ حفظ التغييرات في قاعدة البيانات
    if (global.db && global.db.save) {
        global.db.save();
    }
    
    // ✅ إرسال رسالة التأكيد مع المنشن
    const caption = `✅ @${userId}  لقد أصبح مطوراً للبوت بنجاح ♥`;
    
    // ✅ طريقة آمنة للمنشن
    await conn.sendMessage(m.chat, {
        text: caption,
        mentions: [who]
    }, { quoted: m });
    
    // ✅ تسجيل في الكونسول
    console.log(`✅ تم إضافة مطور جديد: ${userId} بواسطة ${m.sender.split('@')[0]}`);
}

handler.help = ['addowner', 'اضف-مطور'];
handler.tags = ['owner'];
handler.command = /^(addowner|اضف-مطور|add-owner)$/i;
handler.owner = true;
handler.rowner = true; // ✅ فقط المطور الأساسي

export default handler;