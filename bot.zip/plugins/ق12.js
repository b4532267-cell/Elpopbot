import pkg from '@whiskeysockets/baileys'
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg

const handler = async (m, { conn }) => {
  try {
    let name = conn.getName(m.sender) || 'مستخدم'

    await conn.sendMessage(m.chat, { react: { text: '⚔️', key: m.key } })

    // 🖼️ الصورة المثبتة الرسمية لبوتك
    const imageUrl = "https://files.catbox.moe/5o36un.jpg"
    const media = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer })

    // 📋 تنسيق الأوامر والاسم الجديد بالإيموجي 🍫 تحت بعض بالملي وبدون أعلام
    const caption = `
╭━━〔⚔️ ﻗـسـم الـنـقـابـات ⚔️〕━━⬣
┃ ➟ *مرحباً بك يا* 『${name}』
┃ ➟ *داخل بوت* 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 🍫
╰━━━━━━━━━━━━⬣

╭━━〔🍬 أوامـر الـنـقـابـات 🍬〕━━⬣
┃ ➟ 🏷️ *.تلقيب*
┃ ➟ 🔒 *.حجز_لقب*
┃ ➟ 📋 *.الالقاب_المحجوزه*
┃ ➟ 🔓 *.الغاء_حجز*
┃ ➟ ✨ *.متوفر*
┃ ➟ 👤 *.لقبي*
┃ ➟ ❌ *.حذف_لقب*
┃ ➟ 🔍 *.لقبه*
┃ ➟ 🗑️ *.حذف_الألقاب*
┃ ➟ ✉️ *.رسايلي*
┃ ➟ 📊 *.اجمالي*
╰━━━━━━━━━━━━⬣
`.trim()

    let msg = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: caption },
            footer: { text: '⦓ 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ⦔' },
            header: { hasMediaAttachment: true, ...media },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "⬅️ العودة للقائمة الرئيسية",
                    id: ".menu"
                  })
                }
              ]
            }
          }
        }
      }
    }

    await conn.relayMessage(m.chat, msg, {})

  } catch (err) {
    console.error(err)
    await conn.sendMessage(m.chat, { text: '❌ حدث خطأ أثناء تنفيذ الأمر.' }, { quoted: m })
  }
}

handler.command = /^(ق12)$/i
handler.tags = ["clans"]
handler.help = ["ق12"]

export default handler