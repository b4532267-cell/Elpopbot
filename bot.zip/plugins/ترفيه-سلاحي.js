const dir = [
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
        "https://qu.ax/TzOSc.jpg",
        "https://qu.ax/AGwuU.jpg",
        "https://qu.ax/dQJQB.jpg",
        "https://qu.ax/dibUg.jpg",
        "https://qu.ax/TzOSc.jpg",
        "https://qu.ax/AGwuU.jpg",
        "https://qu.ax/dQJQB.jpg",
        "https://qu.ax/dibUg.jpg",
        "https://qu.ax/TzOSc.jpg",
        "https://qu.ax/AGwuU.jpg",
        "https://qu.ax/dQJQB.jpg",
        "https://qu.ax/dibUg.jpg",
        "https://qu.ax/TzOSc.jpg",
        "https://qu.ax/AGwuU.jpg",
        "https://qu.ax/dQJQB.jpg",
        "https://qu.ax/dibUg.jpg",
        "https://qu.ax/TzOSc.jpg",
        "https://qu.ax/AGwuU.jpg",
        "https://qu.ax/dQJQB.jpg",
        "https://qu.ax/dibUg.jpg",
        "https://qu.ax/TzOSc.jpg",
        "https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg",
"https://qu.ax/dQJQB.jpg",
"https://qu.ax/dibUg.jpg",
"https://qu.ax/TzOSc.jpg",
"https://qu.ax/AGwuU.jpg"
]
let handler = async (m, { conn }) => {
  conn.sendFile(m.chat, dir[Math.floor(Math.random() * dir.length)], 'dado.webp', '', m)
await conn.sendMessage(m.chat, { react: { text: '🔫', key: m.key } })
}
handler.help = ['dado']
handler.tags = ['game']
handler.command = ['سلاحي'] 

export default handler
