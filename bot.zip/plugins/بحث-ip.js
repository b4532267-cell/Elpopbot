import { getIPInfo } from '../plugins/سكراب-ip.js'
let handler = async (m, {
    conn,
    args,
    text,
    usedPrefix,
    command
}) => {
let input = `*المرجو تقديم الip بعد الأمر على سبيل المثال 💗❤️*
*${usedPrefix + command} 52.87.44.246*`
	if (!text) return m.reply(input)

    getIPInfo(text).then(ipInfo => {
 if (ipInfo) {
 const ip = `
  *⎔⋅• ━ ╼╃⎔ ˼💠˹ ⎔╄╾ ━ •⋅⎔*
*「 الآي بس╎⤋」*
*↲﹝ ${ipInfo.ip}﹞💗↳*
*「 المدينه ╎⤋」*
*↲﹝ ${ipInfo.city}﹞🪄↳*
*「 المنطقة╎⤋」*
*↲﹝ ${ipInfo.region} ﹞😍↳*
*「 البلد╎⤋」*
*↲﹝ ${ipInfo.country} ﹞⏳↳*
*「 الموقع╎⤋」*
*↲﹝  ${ipInfo.loc}﹞🎉↳*
*「 المنظه المشتركه╎⤋」*
*↲﹝ ${ipInfo.org} ﹞♟️↳*
*「 الرمز البريدي لي دوله╎⤋」*
*↲﹝ ${ipInfo.postal} ﹞🔥↳*
*「 المنطقة الزمنية╎⤋」*
*↲﹝  ${ipInfo.timezone} ﹞⏰↳*
*「 الموقع╎⤋」*
*↲﹝ ${ipInfo.loc}﹞📻↳*
*「 الاحداثيات╎⤋」*
*↲﹝ ${ipInfo.loc} ﹞📡↳*
*⎔⋅• ━ ╼╃⎔ ˼💠˹ ⎔╄╾ ━ •⋅⎔*
  `
m.reply(ip)
    }
})
}
handler.help = ['اوبيتو']
handler.tags = ['اوبيتو']
handler.command = /^(ip|بحث-ip)$/i
handler.premium = true
handler.limit = true

export default handler