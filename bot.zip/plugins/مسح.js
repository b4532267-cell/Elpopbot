import fs from 'fs';
import path from 'path';

const handler = async (m, { text, command }) => {
  const allowedNumber = '201015115056@s.whatsapp.net'; // ← رقمك

  // تحقق من رقم المرسل
  if (m.sender !== allowedNumber) {
    return m.reply('🚫 هذا الأمر مخصص للمطور فقط!');
  }

  // تحقق من وجود اسم الملف
  if (!text) throw `⚠️ اكتب اسم الملف الذي تريد حذفه بدون .js`;

  const filePath = path.join('plugins', `${text}.js`);

  // تحقق إن الملف موجود
  if (!fs.existsSync(filePath)) {
    return m.reply(`❌ الملف *${text}.js* غير موجود في مجلد plugins.`);
  }

  try {
    fs.unlinkSync(filePath);
    m.reply(`✅ تم حذف الملف بنجاح: *${filePath}*`);
  } catch (err) {
    m.reply(`❌ فشل في حذف الملف:\n${err.message}`);
  }
};

handler.help = ['delplugin <اسم>'];
handler.tags = ['owner'];
handler.command = ['delplugin', 'delp', 'امسح'];
handler.owner = false;

export default handler;