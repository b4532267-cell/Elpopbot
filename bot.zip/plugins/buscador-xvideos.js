// plugins/xvideos-search.js
import axios from 'axios';
import * as cheerio from 'cheerio';

const emoji  = '🎬'
const emoji2 = '😔'
const msm    = '❌'

const handler = async (m, { conn, args, command, usedPrefix }) => {

    if (!args[0]) {
        return m.reply(`${emoji} اكتب اسم الفيديو اللي عايز تدوّر عليه.\nمثال: *${usedPrefix + command} zorritas*`)
    }

    try {
        const results = await xvideosSearch(args.join(' '))

        if (!results.length) {
            return m.reply(`${emoji2} مفيش نتائج لـ: *${args.join(' ')}*`)
        }

        let msg = `${emoji} *نتائج البحث عن:* *${args.join(' ')}*\n\n`
        results.forEach((v) => {
            msg += `☁️ *العنوان:* ${v.title || 'غير متاح'}\n`
            msg += `🕒 *المدة:* ${v.duration || 'غير متاح'}\n`
            msg += `🎞️ *الجودة:* ${v.quality || 'عادية'}\n`
            msg += `🔗 *الرابط:* ${v.url}\n\n`
        })

        await conn.sendMessage(m.chat, { text: msg }, { quoted: m })

    } catch (e) {
        console.error('[xvideos]', e?.message)
        return m.reply(`${msm} حصل خطأ، حاول تاني بعد شوية.`)
    }
}

handler.command  = /^(xvideossearch|xvsearch)$/i
handler.tags     = ['nsfw']
handler.register = false

export default handler

// ══════════════════════════════════════
//  دالة البحث
// ══════════════════════════════════════
async function xvideosSearch(query) {
    const url      = `https://www.xvideos.com/?k=${encodeURIComponent(query)}`
    const { data } = await axios.get(url, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
            'Accept-Language': 'en-US,en;q=0.9'
        },
        timeout: 15000
    })

    const $       = cheerio.load(data)
    const results = []

    $('div.mozaique > div').each((i, el) => {
        if (i >= 10) return false
        const title    = $(el).find('p.title a').attr('title')
        const href     = $(el).find('p.title a').attr('href')
        const duration = $(el).find('span.duration').text().trim()
        const quality  = $(el).find('span.video-hd-mark').text().trim()

        if (title && href) {
            results.push({
                title,
                url:      'https://www.xvideos.com' + href,
                duration,
                quality
            })
        }
    })

    return results
}