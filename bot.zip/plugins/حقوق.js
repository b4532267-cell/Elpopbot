// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//   𝑺𝑨𝑻𝑶 | 𝑩𝑶𝑻 — حقوق.js
//   ✦ أمر إضافة الحقوق على الستيكر بزخرفة Unicode
//   ✦ التطوير: 𝑲𝑬𝑴𝑶 🩸
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

import { addExif } from '../lib/sticker.js'

// ── ثوابت الزخرفة ─────────────────────────────────────
const D = '◑ • ─ ⌯┅┉⌯ ─ • ◑'
const L = '┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄'

// ── Context الإرسال (معاد توجيهه من القناة) ────────────
const buildContext = (senderJid) => ({
  mentionedJid: [senderJid],
  isForwarded: true,
  forwardingScore: 999,
  forwardedNewsletterMessageInfo: {
    newsletterJid:  global.idcanal  || '120363424951931854@newsletter',
    newsletterName: global.namecanal || '⚝  𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓  ⚝',
    serverMessageId: 0,
  },
  externalAdReply: {
    title: global.namecanal || '⚝  𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓  ⚝',
    body: 'تابع قناتنا الرسمية على واتساب ✦',
    thumbnailUrl: 'https://files.catbox.moe/i65jk4.jpg',
    sourceUrl: global.canal || 'https://whatsapp.com/channel/0029VbCS3Q34SpkER26xwJ3u',
    mediaType: 1,
    renderLargerThumbnail: true,
    showAdAttribution: true,
  },
})

// ── رسالة المساعدة ─────────────────────────────────────
const helpMsg = (prefix, cmd) => `
╭━━━━『 📌 طريقة الاستخدام 』━━━━╮
┃  ${D}
┃
┃  🔹 *${prefix}${cmd} اسمك*
┃     ↳ يضع اسمك كحقوق للستيكر
┃
┃  🔹 *${prefix}${cmd} اسمك | وصفك*
┃     ↳ اسم الحزمة | اسم المؤلف
┃
┃  🔹 *${prefix}${cmd}* (بدون نص)
┃     ↳ يضع اسم البوت الرسمي
┃
┃  ${L}
┃  ⚠️  _يجب الرد على ستيكر أولاً_
┃  ${D}
╰━━━━『 𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻 』━━━━╯
`.trim()

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//   ✦ Handler الرئيسي
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

const handler = async (m, { conn, text, usedPrefix, command }) => {

  // ── ① التحقق من وجود رد على رسالة ──────────────────
  if (!m.quoted) {
    return conn.sendMessage(m.chat, {
      text: `
╭━━━━『 ⚠️ تنبيه 』━━━━╮
┃  ${D}
┃
┃  ❌ يجب الرد على *ستيكر* أولاً
┃
┃  ✦ ارد على الستيكر واكتب:
┃  *${usedPrefix}${command} اسمك*
┃
╰━━━━『 𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻 』━━━━╯`.trim(),
      contextInfo: buildContext(m.sender),
    }, { quoted: m })
  }

  // ── ② التحقق من نوع الرسالة المردود عليها ───────────
  const quoted = m.quoted
  const mime   = (quoted.msg || quoted).mimetype || quoted.mediaType || ''

  if (!/webp/i.test(mime)) {
    return conn.sendMessage(m.chat, {
      text: `
╭━━━━『 ⚠️ خطأ في النوع 』━━━━╮
┃  ${D}
┃
┃  ❌ الرسالة المردود عليها ليست *ستيكر*
┃
┃  ✦ قم بالرد على ستيكر واتساب فقط
┃  ${D}
╰━━━━『 𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻 』━━━━╯`.trim(),
    }, { quoted: m })
  }

  // ── ③ تحليل النص (اسم الحزمة | اسم المؤلف) ─────────
  let packname, author

  if (!text || !text.trim()) {
    // بدون نص → يستخدم اسم البوت الافتراضي
    packname = global.packname || '𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻'
    author   = global.author   || '𝐁𝐄𝐋𝐀𝐋 🩸'
  } else if (text.includes('|')) {
    // نص | مؤلف
    const parts = text.split('|').map(s => s.trim())
    packname = parts[0] || global.packname || '𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻'
    author   = parts[1] || global.author   || '𝐁𝐄𝐋𝐀𝐋 🩸'
  } else {
    // اسم واحد فقط → packname = الاسم، author = بوت سات
    packname = text.trim()
    author   = global.namebot || '𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻'
  }

  // ── ④ رسالة "جاري المعالجة" ─────────────────────────
  const processingMsg = await conn.sendMessage(m.chat, {
    text: `
╭━━━━『 ⚙️ 𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻 』━━━━╮
┃  ${D}
┃
┃  🔄 جاري إضافة الحقوق على الستيكر...
┃
┃  📛 *الاسم:*  ${packname}
┃  ✍️  *المؤلف:* ${author}
┃
╰━━━━『 انتظر قليلاً ⏳ 』━━━━╯`.trim(),
  }, { quoted: m })

  try {
    // ── ⑤ تحميل الستيكر ──────────────────────────────
    const stickerBuffer = await quoted.download()
    if (!stickerBuffer || stickerBuffer.length < 100) {
      throw new Error('فشل تحميل الستيكر، حجم البيانات صغير جداً')
    }

    // ── ⑥ إضافة بيانات الحقوق (EXIF) ─────────────────
    const modified = await addExif(stickerBuffer, packname, author)

    // ── ⑦ حذف رسالة "جاري المعالجة" ────────────────
    if (processingMsg?.key) {
      await conn.sendMessage(m.chat, { delete: processingMsg.key }).catch(() => {})
    }

    // ── ⑧ إرسال الستيكر المعدّل ────────────────────────
    await conn.sendMessage(m.chat, {
      sticker: modified,
      contextInfo: buildContext(m.sender),
    }, { quoted: m })

    // ── ⑨ رسالة النجاح بزخرفة Unicode ─────────────────
    await conn.sendMessage(m.chat, {
      text: `
╭━━━━『 ✅ تمت العملية بنجاح! 』━━━━╮
┃  ${D}
┃
┃  🏷️  *اسم الحزمة:*  ${packname}
┃  ✍️   *اسم المؤلف:*  ${author}
┃
┃  ${L}
┃  ✦ _افتح الستيكر في مكتبتك_
┃  ✦ _ستجد الحقوق في معلوماته_ 📋
┃  ${D}
┃
┃  ❤️  _شكراً لاستخدامك_ *𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻*
╰━━━━『 👑 𝐁𝐄𝐋𝐀𝐋 🩸 』━━━━╯`.trim(),
      contextInfo: buildContext(m.sender),
    }, { quoted: m })

    // ── ⑩ إحصائيات (اختياري) ───────────────────────────
    if (global.db?.data?.users?.[m.sender]) {
      global.db.data.users[m.sender].totalStickers =
        (global.db.data.users[m.sender].totalStickers || 0) + 1
    }

  } catch (err) {
    // ── معالجة الأخطاء ────────────────────────────────
    if (processingMsg?.key) {
      await conn.sendMessage(m.chat, { delete: processingMsg.key }).catch(() => {})
    }

    console.error('[حقوق Plugin]', err)

    await conn.sendMessage(m.chat, {
      text: `
╭━━━━『 ❌ حدث خطأ 』━━━━╮
┃  ${D}
┃
┃  ⚠️  ${err?.message || 'خطأ غير متوقع'}
┃
┃  ${L}
┃  ✦ _تأكد أن الستيكر صالح_
┃  ✦ _وليس ستيكر مشفر أو محمي_
┃  ${D}
╰━━━━『 𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻 』━━━━╯`.trim(),
    }, { quoted: m })
  }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//   ✦ إعدادات البلجن
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

handler.help    = ['حقوق <اسمك>', 'حقوق <اسمك | مؤلف>']
handler.tags    = ['sticker']
handler.command = ['حقوق', 'take', 'wm', 'watermark', 'حقوقي']

export default handler
