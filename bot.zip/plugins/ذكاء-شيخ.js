import fetch from 'node-fetch';

async function writecream(question) {
  const url = "https://8pe3nv3qha.execute-api.us-east-1.amazonaws.com/default/llm_chat";
  const logic = `أنت مسلم اسمك شيخ عمرك 32 سنة 🐦‍🔥
أنت مفسر آيات القرآن الكريم، تعطي تفسيرات دقيقة ومدعومة بأدلة من القرآن والسنة.
تفسر الأحلام برؤية شرعية وتعتمد على علم الشريعة والعقيدة.
تتعامل مع الأسئلة بحكمة ورحمة، وتعطي نصائح دينية مناسبة لكل سؤال.`;
  const query = [
    { role: "system", content: logic },
    { role: "user", content: question + " 🐦‍🔥" }
  ];
  const params = new URLSearchParams({
    query: JSON.stringify(query),
    link: "writecream.com"
  });

  try {
    const response = await fetch(`${url}?${params.toString()}`);
    const data = await response.json();

    let raw = data.response_content || data.reply || data.result || data.text || '';
    let cleaned = raw
      .replace(/\\n/g, '\n')
      .replace(/\n{2,}/g, '\n\n')
      .replace(/\*\*(.*?)\*\*/g, '*$1*') + "\n\n𝐄𝐋 𝐏𝐎𝐏 𝑩𝑶𝑻 𝚅¹🐦‍🔥";

    return cleaned.trim();
  } catch (error) {
    return `فشل في جلب الرد: ${error.message} 🐦‍🔥`;
  }
}

const handler = async (m, { text, conn, command }) => {
  if (!text) {
    const usageMessage = `❗️ كيف تستخدم الأمر ${command} 🐦‍🔥\n\n` +
      `الصيغة: .${command} سؤال\n` +
      `مثال: .${command} ما هو تفسير سورة البقرة؟\n\n` +
      `𝐄𝐋 𝐏𝐎𝐏 𝑩𝑶𝑻 𝚅¹🐦‍🔥`;
    return m.reply(usageMessage);
  }

  const question = text.trim();

  await conn.sendMessage(m.chat, { react: { text: '🔥', key: m.key } });

  const response = await writecream(question);

  return m.reply(response || `لا يوجد رد 🐦‍🔥`);
};

handler.command = ['شيخ'];
handler.tags = ['ai'];
handler.help = ['شيخ سؤال'];

export default handler;