// ملف: plugins/anti-private.js
/**
 * 🚫 نظام منع الخاص (Anti-Private Mode)
 * 🛠️ تطوير: KEMO EL BODRAGE
 * ⚡ الوظيفة: حظر تلقائي للحفاظ على خصوصية البوت الرئيسي
 */

let handler = async (m, { conn, isCreator }) => {
  // 1. تجاهل رسائل المجموعات تماماً
  if (m.isGroup) return;

  // 2. التحقق من معرف البوت الرئيسي (Main Bot JID)
  const mainBotJid = "584163908993@s.whatsapp.net";
  if (conn.user.jid !== mainBotJid) return;

  // 3. استثناء المطور أو البوت نفسه
  if (isCreator || m.fromMe) return;

  // 4. استثناء أرقام محددة (مثل المطور الأساسي)
  const allowedNumbers = ["201015115056@s.whatsapp.net"];
  if (allowedNumbers.includes(m.sender)) return;

  // روابط القناة والجروب
  const channelLink = "https://whatsapp.com/channel/0029Vb83VLS9mrGeH1iPbH30";
  const groupLink = "https://chat.whatsapp.com/KEIdC5qaCXRJGOmXiRoNEF?s=cl&p=a&mlu=4&amv=1";

  // 5. رسالة التحذير بالزخرفة العريضة
  let msg = `
┏━━━━━━━━━━━━━━━━━━┓
┃  🚫 تـم الـحـظـر تـلـقـائـيـاً 🚫  ┃
┗━━━━━━━━━━━━━━━━━━┛

*تـم رصـد مـحـاولـة تـواصـل فـي الـخـاص*
*الـتـواصـل مـع الـبـوت الـرئـيـسـي مـمـنـوع*

╭━━─━━─━━─━━─━━╮
  *📢 تـابـع جـديـدنـا هـنـا:*
  ${channelLink}
╰━━─━━─━━─━━─━━╯

╭━━─━━─━━─━━─━━╮
  *👥 جـروب الـدعـم:*
  ${groupLink}
╰━━─━━─━━─━━─━━╯

> *تـطـويـر: 𝐁𝐄𝐋𝐀𝐋 𝐄𝐋 𝐁𝐎𝐃𝐑𝐀𝐆𝐄*
> *𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻*`;

  try {
    // إرسال الرسالة أولاً
    await conn.reply(m.chat, msg, m);
    
    // تأخير بسيط لضمان وصول الرسالة قبل الحظر
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // تنفيذ الحظر
    await conn.updateBlockStatus(m.sender, "block");
    
    console.log(`[🚫] Anti-Private: تم حظر ${m.sender} بنجاح.`);
  } catch (err) {
    console.error("⚠️ خطأ في نظام المنع:", err);
  }
};

// إعدادات التشغيل التلقائي (الرادار)
handler.customPrefix = /.*/;
handler.command = new RegExp;
handler.all = true;

export default handler;