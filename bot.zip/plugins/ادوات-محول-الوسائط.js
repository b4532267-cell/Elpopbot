import cheerio from 'cheerio';
import fetch from 'node-fetch';

let handler = async (m, { conn, args, text, command }) => {
    let الخيارات = [
        "فيديو-إلى-جيف", "videotogif",
        "جيف-إلى-فيديو", "giftovideo",
        "تحسين-صورة", "optijpeg"
    ];

    let [الميزة, الرابط, نسبة, حجم] = text.split("|");
    
    if (!الخيارات.includes(الميزة)) return m.reply(`🐦‍🔥 *طريقة الاستخدام:*\n\nأرسل الأمر مع تحديد النوع المطلوب:\n
1️⃣ *فيديو إلى GIF:* \`.${command} فيديو-إلى-جيف|رابط-الفيديو\`
2️⃣ *GIF إلى فيديو:* \`.${command} جيف-إلى-فيديو|رابط-GIF\`
3️⃣ *تحسين صورة:* \`.${command} تحسين-صورة|رابط-الصورة|نسبة-التحسين|الحجم-المطلوب\`

🔹 *مثال:*  
\`.${command} فيديو-إلى-جيف|https://example.com/video.mp4\` 🐦‍🔥  
\`.${command} تحسين-صورة|https://qu.ax/dibUg.jpg|50|100\` 🐦‍🔥`);

    try {
        if (الميزة === "فيديو-إلى-جيف" || الميزة === "videotogif") {
            let النتيجة = await VideoToGif(الرابط);
            let الرد = `🐦‍🔥 *تم التحويل بنجاح!*  
📁 *حجم الملف:* ${النتيجة.fileSize}  
📏 *العرض:* ${النتيجة.width}  
📐 *الارتفاع:* ${النتيجة.height}  
🖼️ *عدد الإطارات:* ${النتيجة.frames}  
📄 *نوع الملف:* ${النتيجة.fileType}  

🔹 *رابط الملف:* ${النتيجة.outputImageUrl}`;

            await conn.sendMessage(m.chat, { video: { url: النتيجة.outputImageUrl }, gifPlayback: true, caption: الرد }, { quoted: m });
        }

        if (الميزة === "جيف-إلى-فيديو" || الميزة === "giftovideo") {
            let النتيجة = await GifToVideo(الرابط);
            let الرد = `🐦‍🔥 *تم التحويل بنجاح!*  
📁 *حجم الملف:* ${النتيجة.fileSize}  

🔹 *رابط الملف:* ${النتيجة.outputImageUrl}`;

            await conn.sendMessage(m.chat, { video: { url: النتيجة.outputImageUrl }, caption: الرد }, { quoted: m });
        }

        if (الميزة === "تحسين-صورة" || الميزة === "optijpeg") {
            let النتيجة = await OptiJpeg(الرابط, نسبة, حجم);
            let الرد = `🐦‍🔥 *تم تحسين الصورة!*  
📁 *حجم الملف:* ${النتيجة.fileSize}  

🔹 *رابط الملف:* ${النتيجة.outputImageUrl}`;

            await conn.sendMessage(m.chat, { image: { url: النتيجة.outputImageUrl }, caption: الرد }, { quoted: m });
        }
    } catch (e) {
        await m.reply("🐦‍🔥 حدث خطأ أثناء معالجة الطلب، يرجى المحاولة مرة أخرى.");
    }
};

handler.help = ["ezgif", "محول-الوسائط"];
handler.tags = ["tools", "أدوات"];
handler.command = /^(ezgif|محول-الوسائط)$/i;
export default handler;

/* 🐦‍🔥 دوال المعالجة */
async function VideoToGif(video_url) {
    const response = await fetch('https://ezgif.com/video-to-gif?url=' + video_url);
    const html = await response.text();
    const $ = cheerio.load(html);

    return {
        outputImageUrl: 'https:' + $('#output .outfile img').attr('src'),
        fileSize: $('#output .filestats strong').text(),
        width: $('#output .filestats').text().match(/width: (\d+)/)[1],
        height: $('#output .filestats').text().match(/height: (\d+)/)[1],
        frames: $('#output .filestats').text().match(/frames: (\d+)/)[1],
        fileType: $('#output .filestats').text().match(/type: (\w+)/)[1],
    };
}

async function GifToVideo(gif_url) {
    const response = await fetch('https://ezgif.com/gif-to-mp4?url=' + gif_url);
    const html = await response.text();
    const $ = cheerio.load(html);

    return {
        outputImageUrl: 'https:' + $('#output .outfile video source').attr('src'),
        fileSize: $('#output .filestats strong').text()
    };
}

async function OptiJpeg(image_url, percent, sizes) {
    const response = await fetch('https://ezgif.com/optijpeg?url=' + image_url);
    const html = await response.text();
    const $ = cheerio.load(html);

    return {
        outputImageUrl: 'https:' + $('#output .outfile img').attr('src'),
        fileSize: $('#output .filestats strong').text()
    };
}

/* 𝒁𝑶𝑹𝑶 𝑩𝑶𝑻 𝚅¹🐦‍🔥 */