import fs from 'fs';
import path from 'path';

const allowedNumbers = ['201015115056@s.whatsapp.net', '966567158348@s.whatsapp.net'];

const imageLinks = [
  'https://qu.ax/dibUg.jpg',
  'https://qu.ax/TzOSc.jpg',
  'https://qu.ax/AGwuU.jpg',
  'https://qu.ax/dQJQB.jpg',
];

const handler = async (m, { conn }) => {
  if (!allowedNumbers.includes(m.sender)) {
    await conn.sendMessage(m.chat, {
      text: `🚫 هذا الأمر مخصص للمطور فقط.`,
    }, { quoted: m });
    return;
  }

  const basePath = 'plugins';
  const files = fs.readdirSync(basePath).filter(file => file.endsWith('.js'));
  let changedFiles = 0;
  let totalReplaced = 0;
  let errors = [];

  const jpgRegex = /https?:\/\/[^\s'"]+\.jpg/gi;

  for (let file of files) {
    const filePath = path.join(basePath, file);
    try {
      let content = fs.readFileSync(filePath, 'utf-8');
      const matches = [...content.matchAll(jpgRegex)];

      if (matches.length > 0) {
        let i = 0;
        content = content.replace(jpgRegex, () => {
          const link = imageLinks[i % imageLinks.length];
          i++;
          totalReplaced++;
          return link;
        });
        fs.writeFileSync(filePath, content, 'utf-8');
        changedFiles++;
      }
    } catch (err) {
      errors.push({ file, error: err.message });
    }
  }

  let message = `✅ تم استبدال روابط الصور في ${changedFiles} ملف.\n🔁 عدد الروابط التي تم تغييرها: ${totalReplaced}`;
  if (errors.length > 0) {
    message += `\n⚠️ حصلت أخطاء في الملفات التالية:\n`;
    errors.forEach(({ file, error }) => {
      message += `- ${file}: ${error}\n`;
    });
  }

  await conn.sendMessage(m.chat, { text: message }, { quoted: m });
};

handler.help = ['بدل-الصور'];
handler.tags = ['owner'];
handler.command = /^بدل-الصور$/i;
handler.owner = true;

export default handler;