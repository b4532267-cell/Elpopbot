let handler = async (m, { conn, args, usedPrefix, command }) => {
    const taguser = '@' + m.sender.split("@s.whatsapp.net")[0];

    const buttons = Array.from({ length: 100 }, (v, i) => {
        const num = i + 1;
        return {
            header: 'الاناشــــــيد الاسلامية',
            title: `النشيد رقم ${num}`,
            description: 'نــــــــشيد إسلامي',
            id: `.نشيد ${num}`
        };
    });

    conn.relayMessage(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        title: `*⎔ ⋅ ───━ •﹝🐦‍🔥﹞• ━─── ⋅ ⎔*\n*المرجو اختيار نشيد الذي تريده يا اخي العزيز 😁🕋*\n*⎔ ⋅ ───━ •﹝🐦‍🔥﹞• ━─── ⋅ ⎔*`
                    },
                    body: {
                        text: ''
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: 'single_select',
                                buttonParamsJson: JSON.stringify({
                                    title: 'الاناشــــــيد المتــــوفرة',
                                    sections: [
                                        {
                                            title: 'قسم الاناشيد الاسلاميه',
                                            highlight_label: '𝐄𝐋 𝐏𝐎𝐏-BOT',
                                            rows: buttons
                                        }
                                    ]
                                }),
                                messageParamsJson: ''
                            }
                        ]
                    }
                }
            }
        }
    }, {});
};

handler.help = ['info'];
handler.tags = ['main'];
handler.command = ['اناشيد'];

export default handler;