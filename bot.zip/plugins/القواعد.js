/* 💎 تم التنسيق بواسطة 🃏 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓 💎 */
import pkg from '@whiskeysockets/baileys'
const { prepareWAMessageMedia } = pkg

const handler = async (m, { conn }) => {
  try {
    await conn.sendMessage(m.chat, { react: { text: '📜', key: m.key } })

    const imageUrl = 'https://files.catbox.moe/ritv42.jpg' // تقدر تغير الرابط بصورة القوانين الخاصة بك
    const media = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer })

    let caption = `
╭━━〔 📜 قـوانـيـن 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 📜 〕━━⬣
┃
┃ ➟ *1 -* ممنوع سب البوت أو المطور نهائياً. 🚫
┃ ➟ *2 -* ممنوع تكرار الأوامر (سبام) لتجنب الحظر. ⚠️
┃ ➟ *3 -* ممنوع نشر روابط مجموعات أخرى داخل البوت. 🔗
┃ ➟ *4 -* ممنوع طلب رتب أو صلاحيات من المطورين. 🎖️
┃ ➟ *5 -* البوت مخصص للمتعة والمساعدة، استخدمه باحترام. ✨
┃ ➟ *6 -* أي محاولة لاختراق البوت تؤدي لحظر رقمك فوراً. 🔒
┃
╰━━━━━━━━━━━━⬣

╭━━〔 💡 مـلاحـظـات 💡 〕━━⬣
┃ ➟ *في حال واجهت مشكلة، تواصل مع المطور.*
┃ ➟ *يتم تحديث القوانين بشكل دوري.*
╰━━━━━━━━━━━━⬣

> 📜 *قوانين البوت بإدارة 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓*
`.trim()

    let msg = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: caption },
            footer: { text: '⦓ 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ⦔' },
            header: { hasMediaAttachment: true, ...media },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "cta_url",
                  buttonParamsJson: JSON.stringify({
                    display_text: "🃏 قـنـاة الـمـطـور",
                    url: "https://whatsapp.com/channel/0029Vb83VLS9mrGeH1iPbH30"
                  })
                }
              ]
            }
          }
        }
      }
    }

    await conn.relayMessage(m.chat, msg, {})

  } catch (err) {
    console.error(err)
    await conn.sendMessage(m.chat, { text: '❌ حدث خطأ أثناء عرض القوانين.' }, { quoted: m })
  }
}

handler.command = ['القوانين', 'قوانين', 'القواعد', 'قواعد']
handler.tags = ['main']
handler.help = ['القوانين']

export default handler