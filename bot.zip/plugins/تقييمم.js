import moment from 'moment-timezone'

let handler = m => m

handler.before = async function (m, { conn }) {
  // التعامل مع التقييم سواء كان قديماً (list) أو جديداً (interactive)
  let id = null

  if (m.type === 'listResponseMessage') {
    id = m.msg?.singleSelectReply?.selectedRowId
  } else if (m.type === 'interactiveResponseMessage') {
    try {
      const body = m.msg?.nativeFlowResponseMessage?.paramsJson
      if (body) {
        const parsed = JSON.parse(body)
        id = parsed?.id || parsed?.rowId
      }
    } catch {}
  }

  if (!id || !id.startsWith('rate_')) return

  const pushname = m.pushName || 'مستخدم'
  const senderNumber = m.sender.split('@')[0]  // استخراج الرقم فقط
  const stars = parseInt(id.replace('rate_', '')) || 1
  const starsEmoji = '⭐'.repeat(stars)

  const time = moment.tz('Africa/Cairo').format('HH:mm:ss')
  const date = moment.tz('Africa/Cairo').format('DD/MM/YYYY')

  try {
    // رد حلو للمستخدم اللي قيّم
    await m.reply(`*⭐ شكراً لك يا* ${pushname} *على تقييمك القيم!* 🌟\n*لقد أعطيتني* ${starsEmoji}\n*رأيك يهمني جداً ويحفزني للأفضل 🚀*`)

    // رسالة خاصة للمطور (رقمك)
    const devMsg = `┏━━━━━━━━━━━━━━━━━━━━┓
┃ 📬 *تقرير تقييم جديد* 📬
┗━━━━━━━━━━━━━━━━━━━━┛
┃ 👤 *الاسم:* ${pushname}
┃ 📱 *الرقم:* ${senderNumber}
┃ ⭐ *التقييم:* ${starsEmoji}
┃ 📅 *التاريخ:* ${date}
┃ 🕒 *الوقت:* ${time}
┗━━━━━━━━━━━━━━━━━━━━┛`

    await conn.sendMessage('201015115056@s.whatsapp.net', { text: devMsg })

  } catch (e) {
    console.error('[تقييم] خطأ:', e)
  }

  return true
}

export default handler