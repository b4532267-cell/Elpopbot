import fs from 'fs'
import { join } from 'path'

let handler = async (m, { conn }) => {
    try {
        // 1. تحديد مكان الملف (بره في المجلد الرئيسي زي الصورة)
        const audioPath = join(process.cwd(), 'shakhra.mp3')

        // 2. التأكد إن الملف موجود
        if (!fs.existsSync(audioPath)) {
            return m.reply('❌ مش لاقي الملف بره.. تأكد إن اسمه shakhra.mp3 وموجود جنب sato.jpg')
        }

        // 3. إرسال الملف كـ "صوت عادي" (Audio) مش فويس نوت
        await conn.sendMessage(m.chat, { 
            audio: fs.readFileSync(audioPath), 
            mimetype: 'audio/mpeg',
            ptt: false // خليناها false عشان يتبعت كملف صوتي عادي
        }, { quoted: m })

        // 4. ريأكشن سريع
        await conn.sendMessage(m.chat, { react: { text: '🤬', key: m.key } })

    } catch (e) {
        console.error(e)
        m.reply('❌ حصل خطأ أثناء إرسال الصوت.')
    }
}

handler.help = ['اشخر']
handler.tags = ['fun']
handler.command = /^(اشخر|شخر)$/i 

export default handler