let linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i;
let linkRegex1 = /whatsapp.com\/channel\/([0-9A-Za-z]{20,24})/i;

export async function before(m, { conn, isAdmin, isBotAdmin, isOwner, isROwner, participants }) {

if (!m.isGroup) return;
if (!m.text) return;
if (isAdmin || isOwner || m.fromMe || isROwner) return;

let chat = global.db.data.chats[m.chat];
if (!chat.antiLink) return;

const user = `@${m.sender.split`@`[0]}`;
const isGroupLink = linkRegex.exec(m.text) || linkRegex1.exec(m.text);

// لو مش رابط اخرج
if (!isGroupLink) return;

// تجاهل رابط نفس الجروب
if (isBotAdmin) {
const linkThisGroup = `https://chat.whatsapp.com/${await conn.groupInviteCode(m.chat)}`;
if (m.text.includes(linkThisGroup)) return;
}

// رسالة تحذير
await conn.sendMessage(m.chat, { 
text: `🫩 *نـــرم نـــزل لـــيـــنـــك 🫩🫩*\n\n✦ ${user}  /*بـــرا يـــكـــســـمـــك 🫩🫩*`, 
mentions: [m.sender] 
}, { quoted: m });

// لو مش ادمن
if (!isBotAdmin) {
const groupAdmins = participants.filter(p => p.admin).map(v => v.id);

return conn.sendMessage(m.chat, { 
text: `*اࢪفـــعـــونـــي ࢪول عـــلشـــان اطـــࢪد ابـــن الـــزنـــيـــه‍ةةة دةة🫩*

*❖━═ 𝐄𝐋 𝐏𝐎𝐏 | 𝑩𝑶𝑻 ═━❖*`,
mentions: groupAdmins
}, { quoted: m });
}

// حذف الرسالة
await conn.sendMessage(m.chat, { 
delete: { 
remoteJid: m.chat, 
fromMe: false, 
id: m.key.id, 
participant: m.key.participant 
} 
});

// طرد العضو
await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove');

return !0;
}