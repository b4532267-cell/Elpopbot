let handler = async (m, { conn }) => {
  if (!m.quoted) return m.reply('❗ من فضلك قم بالرد على الرسالة التي تريد بثها.')

  let msg = m.quoted.fakeObj || m.quoted

  // جلب كل المستخدمين المسجلين
  let users = Object.keys(global.db.data.users)

  // جلب كل الجروبات المفتوحة فقط
  let groups = Object.entries(conn.chats)
    .filter(([jid, chat]) => jid.endsWith('@g.us') && chat.isChats)

  let total = 0, failed = 0

  // إرسال إلى الخاص
  for (let user of users) {
    try {
      await conn.copyNForward(user, msg, true)
      total++
    } catch (e) {
      failed++
    }
  }

  // إرسال إلى الجروبات
  for (let [jid, chat] of groups) {
    try {
      await conn.copyNForward(jid, msg, true)
      total++
    } catch (e) {
      failed++
    }
  }

  m.reply(`✅ تم إرسال البث بنجاح!\n✨ تم الإرسال إلى: ${total} دردشة\n❌ فشل في: ${failed} دردشة`)
}

handler.command = /^بث$/i
handler.owner = true // مخصص للمالك فقط
export default handler