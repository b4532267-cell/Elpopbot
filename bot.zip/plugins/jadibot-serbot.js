const { useMultiFileAuthState, DisconnectReason, makeCacheableSignalKeyStore, fetchLatestBaileysVersion} = (await import("@whiskeysockets/baileys"));
import qrcode from "qrcode"
import NodeCache from "node-cache"
import fs from "fs"
import path from "path"
import pino from 'pino'
import chalk from 'chalk'
import util from 'util' 
import * as ws from 'ws'
const { child, spawn, exec } = await import('child_process')
const { CONNECTING } = ws
import { makeWASocket } from '../lib/simple.js'
import { fileURLToPath } from 'url'
let crm1 = "Y2QgcGx1Z2lucy"
let crm2 = "A7IG1kNXN1b"
let crm3 = "SBpbmZvLWRvbmFyLmpz"
let crm4 = "IF9hdXRvcmVzcG9uZGVyLmpzIGluZm8tYm90Lmpz"
let drm1 = ""
let drm2 = ""
let rtx = `
⎔⋅• ─┈╌⬪─═✥═─⬪╌┈─ •⋅⎔
  *طـࢪيـــقـة الـسـࢪيـــعة لـلـࢪبـط* ⚡️
⎔⋅• ─┈╌⬪─═✥═─⬪╌┈─ •⋅⎔

˹ 📲 ˼ ‹ 1 › *قـم بفتـح وُاتسـاب عـلى جهـازڪ الآخـࢪ*
˹ 🔐 ˼ ‹ 2 › *انـتـقـل إلى الأجهـزة المـࢪتبـطـة*
˹ 📸 ˼ ‹ 3 › *امـسـح ࢪمـز الـ QR الـظـاهـࢪ هـنـا*
˹ ⏳ ˼ ‹ 4 › *انـتـظـࢪ قـلـيـلاً حـتى يـتم الاتـصـال*
˹ 💌 ˼ ‹ 5 › *لا تـنـسـى دِعـوُة لـطـيـفـة مـنـڪ*

⎔⋅• ─┈╌⬪─═✥═─⬪╌┈─ •⋅⎔
   *𝐄𝐋 𝐏𝐎𝐏  𝐁𝐎𝐓* ⸻ *𝐁𝐘: 𝐁𝐄𝐋𝐀𝐋!* 🇮🇱
⎔⋅• ─┈╌⬪─═✥═─⬪╌┈─ •⋅⎔`.trim()

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const yukiJBOptions = {}
if (global.conns instanceof Array) console.log()
else global.conns = []
let handler = async (m, { conn, args, usedPrefix, command, isOwner }) => {

try {
// 1. المنع النهائي في الخاص
if (!m.isGroup) {
return m.reply(`
◑ • ─ ⌯┅┉⌯ •﹝📢﹞• ⌯┅┉⌯ ─ • ◐
*هـذا الأمـࢪ لا يـعـمـل فـي الـخـاص!* ⚠️
◑ • ─ ⌯┅┉⌯ •﹝📢﹞• ⌯┅┉⌯ ─ • ◐

*ممنوع في الخاص خش الجروب الرسمي عشان تعمل تنصيب:*
🔗 https://chat.whatsapp.com/KEIdC5qaCXRJGOmXiRoNEF?s=cl&p=a&mlu=4&amv=1

⎔⋅• ─┈╌⬪─═✥═─⬪╌┈─ •⋅⎔`.trim())
}

// 2. المنع النهائي في الجروبات الأخرى عدا جروبك الرسمي بالمعرف الخاص بك
const officialGroup = '120363389704479387@g.us'
if (m.isGroup && m.chat !== officialGroup) {
return m.reply(`
◑ • ─ ⌯┅┉⌯ •﹝📢﹞• ⌯┅┉⌯ ─ • ◐
*مـمـنـوع اسـتـخـدام الأمـࢪ هـنـا!* ⚠️
◑ • ─ ⌯┅┉⌯ •﹝📢﹞• ⌯┅┉⌯ ─ • ◐

*خش الجروب الرسمي عشان تعمل تنصيب*
🔗 https://chat.whatsapp.com/KEIdC5qaCXRJGOmXiRoNEF?s=cl&p=a&mlu=4&amv=1

⎔⋅• ─┈╌⬪─═✥═─⬪╌┈─ •⋅⎔`.trim())
}

let time = global.db.data.users[m.sender].Subs + 120000

const subBots = [...new Set([...global.conns.filter((conn) => conn.user && conn.ws.socket && conn.ws.socket.readyState !== ws.CLOSED).map((conn) => conn)])]
const subBotsCount = subBots.length
if (subBotsCount === 30) {
return m.reply(`*مـعـتـش امـاڪـن يـسـطـا فـي عـدِدِ ڪـبـيـࢪ فـي الـبـوُت*`)
}

let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
let id = `${who.split`@`[0]}`
let pathYukiJadiBot = path.join(`./${jadi}/`, id)
if (!fs.existsSync(pathYukiJadiBot)){
fs.mkdirSync(pathYukiJadiBot, { recursive: true })
}
yukiJBOptions.pathYukiJadiBot = pathYukiJadiBot
yukiJBOptions.m = m
yukiJBOptions.conn = conn
yukiJBOptions.args = args
yukiJBOptions.usedPrefix = usedPrefix
yukiJBOptions.command = command
yukiJBOptions.fromCommand = true
yukiJadiBot(yukiJBOptions)
global.db.data.users[m.sender].Subs = new Date * 1
} catch (err) {
  console.error(err)
  m.reply(`❌ *حصل ايرور في الأمر الأساسي يا حبة عيني:*\n\n\`\`\`${err.message || err}\`\`\``)
}
} 
handler.help = ['فعل', 'تنصيب']
handler.tags = ['serbot']
handler.command = ['فعل', 'تنصيب']
export default handler 

export async function yukiJadiBot(options) {
let { pathYukiJadiBot, m, conn, args, usedPrefix, command } = options
try {
if (command === 'تنصيب') {
command = 'فعل'; 
args.unshift('تنصيب')}
const mcode = args[0] && /(--تنصيب|تنصيب)/.test(args[0].trim()) ? true : args[1] && /(--تنصيب|تنصيب)/.test(args[1].trim()) ? true : false
let txtCode, codeBot, txtQR
if (mcode) {
args[0] = args[0].replace(/^--تنصيب$|^تنصيب$/, "").trim()
if (args[1]) args[1] = args[1].replace(/^--تنصيب$|^تنصيب$/, "").trim()
if (args[0] == "") args[0] = undefined
}
const pathCreds = path.join(pathYukiJadiBot, "creds.json")
if (!fs.existsSync(pathYukiJadiBot)){
fs.mkdirSync(pathYukiJadiBot, { recursive: true })}
try {
args[0] && args[0] != undefined ? fs.writeFileSync(pathCreds, JSON.stringify(JSON.parse(Buffer.from(args[0], "base64").toString("utf-8")), null, '\t')) : ""
} catch (e) {
conn.reply(m.chat, `*اسـتـخـدِم الأمـࢪ بـشـڪـل صـحـيـح:* ${usedPrefix + command} *تـنـصـيـب*\n\n❌ *ايرور قراءة الكود:* \`${e.message}\``, m)
return
}

const comb = Buffer.from(crm1 + crm2 + crm3 + crm4, "base64")
exec(comb.toString("utf-8"), async (err, stdout, stderr) => {
try {
const drmer = Buffer.from(drm1 + drm2, `base64`)

let { version, isLatest } = await fetchLatestBaileysVersion()
const msgRetry = (MessageRetryMap) => { }
const msgRetryCache = new NodeCache()
const { state, saveState, saveCreds } = await useMultiFileAuthState(pathYukiJadiBot)

const connectionOptions = {
logger: pino({ level: "fatal" }),
printQRInTerminal: false,
auth: { creds: state.creds, keys: makeCacheableSignalKeyStore(state.keys, pino({level: 'silent'})) },
msgRetry,
msgRetryCache,
browser: mcode ? ['Ubuntu', 'Chrome', '110.0.5585.95'] : ['sato Wa [ sato Bot ]','Chrome','2.0.0'],
version: version,
generateHighQualityLinkPreview: true
};

let sock = makeWASocket(connectionOptions)
sock.isInit = false
let isInit = true

async function connectionUpdate(update) {
try {
const { connection, lastDisconnect, isNewLogin, qr } = update
if (isNewLogin) sock.isInit = false
if (qr && !mcode) {
if (m?.chat) {
txtQR = await conn.sendMessage(m.chat, { image: await qrcode.toBuffer(qr, { scale: 8 }), caption: rtx.trim()}, { quoted: m})
} else {
return 
}
if (txtQR && txtQR.key) {
setTimeout(() => { conn.sendMessage(m.sender, { delete: txtQR.key })}, 30000)
}
return
} 

if (qr && mcode) {
    let secret = await sock.requestPairingCode((m.sender.split`@`[0]))
    secret = secret.match(/.{1,4}/g)?.join("-")

    let captionText = `⎔⋅• ─┈╌⬪─═✥═─⬪╌┈─ •⋅⎔
  *طـࢪيـــقـة الـسـࢪيـــعة لـلـࢪبـط* ⚡️
⎔⋅• ─┈╌⬪─═✥═─⬪╌┈─ •⋅⎔

˹ 📲 ˼ ‹ 1 › *قـم بفتـح وُاتسـاب عـلى جهـازڪ الآخـࢪ*
˹ 🔐 ˼ ‹ 2 › *انـتـقـل إلى الأجهـزة المـࢪتبـطـة*
˹ 🍫 ˼ ‹ 3 › *ادِخـل الـڪـوُدِ الـذِي سـيـصـلـڪ الآًن*
˹ ⏳ ˼ ‹ 4 › *انـتـظـࢪ قـلـيـلاً حـتى يـتـم الـࢪبـط*

⎔⋅• ─┈╌⬪─═✥═─⬪╌┈─ •⋅⎔
   *𝐄𝐋 𝐏𝐎𝐏  𝐁𝐎𝐓* ⸻ *𝐁𝐘: 𝐁𝐄𝐋𝐀𝐋!* 🇮🇱
⎔⋅• ─┈╌⬪─═✥═─⬪╌┈─ •⋅⎔`.trim()

    // الرسالة الأولى: الصورة مع الخطوات - لو فشلت بتبعت النص بس بصمت
    try {
        await conn.sendMessage(m.chat, { image: { url: 'https://files.catbox.moe/7vs1u0.png' }, caption: captionText }, { quoted: m })
    } catch (imgErr) {
        console.error('فشل إرسال الصورة:', imgErr?.message || imgErr)
        try {
            await conn.sendMessage(m.chat, { text: captionText }, { quoted: m })
        } catch (txtErr) {
            console.error('فشل إرسال النص:', txtErr?.message || txtErr)
        }
    }

    // الرسالة الثانية: زر نسخ الكود وزر القناة (منفصلة لوحدها)
    const baileysPkg = await import('@whiskeysockets/baileys')
    const proto = baileysPkg.proto || baileysPkg.default?.proto

    let codeText = `⎔⋅• ─┈╌⬪─═✥═─⬪╌┈─ •⋅⎔
  *ڪـوُدِ الـتـحـقـق الـخـاص بـڪ* 🔑
⎔⋅• ─┈╌⬪─═✥═─⬪╌┈─ •⋅⎔

*الـڪـوُدِ هو:* *${secret}*

> اضغط على الزر بالأسفل لنسخ الكود مباشرة`.trim()

    const messageContent = proto.Message.fromObject({
        viewOnceMessage: {
            message: {
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: codeText
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: '𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ⸻ 𝑩𝒀: 𝐁𝐄𝐋𝐀𝐋!'
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create({
                                name: 'cta_copy',
                                buttonParamsJson: JSON.stringify({
                                    display_text: '🍫 اﻧــﺴــﺦ اﻟــﻜــﻮد 🍫',
                                    copy_code: secret
                                })
                            }),
                            proto.Message.InteractiveMessage.NativeFlowMessage.NativeFlowButton.create({
                                name: 'cta_url',
                                buttonParamsJson: JSON.stringify({
                                    display_text: '📢 دﺧــﻮل اﻟــﻘــﻨــﺎة المـبـاشـرة',
                                    url: 'hhttps://whatsapp.com/channel/0029Vb83VLS9mrGeH1iPbH30',
                                    merchant_url: 'https://whatsapp.com/channel/0029Vb83VLS9mrGeH1iPbH30'
                                })
                            })
                        ]
                    })
                })
            }
        }
    })

    await conn.relayMessage(m.chat, messageContent, {})
    console.log(secret)

    // إرسال رسالة التأكيد بعد دقيقة
    setTimeout(async () => {
        try {
            await conn.sendMessage(m.chat, { 
                text: `*هل   نجح   التنصيب   يخويا   ؟*\n\n*لو   منجحش   اڪتب  (تنصيب) تاني   🦦*\n\n*𝐁𝐄𝐋𝐀𝐋   بيحبڪ   فشخ   😋*\n\n> 𝚂𝙰𝚃𝙾 𝙱𝙾𝚃` 
            }, { quoted: m })
        } catch (err) {
            console.error("Error sending follow-up message:", err)
        }
    }, 60000)
}

if (txtCode && txtCode.key) {
setTimeout(() => { conn.sendMessage(m.sender, { delete: txtCode.key })}, 30000)
}
if (codeBot && codeBot.key) {
setTimeout(() => { conn.sendMessage(m.sender, { delete: codeBot.key })}, 30000)
}
const endSesion = async (loaded) => {
if (!loaded) {
try {
sock.ws.close()
} catch {
}
sock.ev.removeAllListeners()
let i = global.conns.indexOf(sock)                
if (i < 0) return 
delete global.conns[i]
global.conns.splice(i, 1)
}}

const reason = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.error?.output?.payload?.statusCode
if (connection === 'close') {
if (reason === 428) {
console.log(chalk.bold.magentaBright(`\n╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄ • • • ┄┄┄┄┄┄┄┄┄┄┄┄┄┄⟡\n┆ La conexión (+${path.basename(pathYukiJadiBot)}) fue cerrada inesperadamente. Intentando reconectar...\n╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄ • • • ┄┄┄┄┄┄┄┄┄┄┄┄┄┄⟡`))
await creloadHandler(true).catch(console.error)
}
if (reason === 408) {
console.log(chalk.bold.magentaBright(`\n╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄ • • • ┄┄┄┄┄┄┄┄┄┄┄┄┄┄⟡\n┆ La conexión (+${path.basename(pathYukiJadiBot)}) se perdió o expiró. Razón: ${reason}. Intentando reconectar...\n╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄ • • • ┄┄┄┄┄┄┄┄┄┄┄┄┄┄⟡`))
await creloadHandler(true).catch(console.error)
}
if (reason === 440) {
console.log(chalk.bold.magentaBright(`\n╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄ • • • ┄┄┄┄┄┄┄┄┄┄┄┄┄┄⟡\n┆ La conexión (+${path.basename(pathYukiJadiBot)}) fue reemplazada por otra sesión activa.\n╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄ • • • ┄┄┄┄┄┄┄┄┄┄┄┄┄┄⟡`))
try {

} catch (error) {
console.error(chalk.bold.yellow(`Error 440 no se pudo enviar mensaje a: +${path.basename(pathYukiJadiBot)}`))
}}
if (reason == 405 || reason == 401) {
console.log(chalk.bold.magentaBright(`\n╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄ • • • ┄┄┄┄┄┄┄┄┄┄┄┄┄┄⟡\n┆ La sesión (+${path.basename(pathYukiJadiBot)}) fue cerrada. Credenciales no válidas o dispositivo desconectado manualmente.\n╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄ • • • ┄┄┄┄┄┄┄┄┄┄┄┄┄┄⟡`))
try {

} catch (error) {
console.error(chalk.bold.yellow(`Error 405 no se pudo enviar mensaje a: +${path.basename(pathYukiJadiBot)}`))
}
fs.rmSync(pathYukiJadiBot, { recursive: true, force: true })
}
if (reason === 500) {
console.log(chalk.bold.magentaBright(`\n╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄ • • • ┄┄┄┄┄┄┄┄┄┄┄┄┄┄⟡\n┆ Conexión perdida en la sesión (+${path.basename(pathYukiJadiBot)}). Borrando datos...\n╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄ • • • ┄┄┄┄┄┄┄┄┄┄┄┄┄┄⟡`))
return creloadHandler(true).catch(console.error)
}
if (reason === 515) {
console.log(chalk.bold.magentaBright(`\n╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄ • • • ┄┄┄┄┄┄┄┄┄┄┄┄┄┄⟡\n┆ Reinicio automático para la sesión (+${path.basename(pathYukiJadiBot)}).\n╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄ • • • ┄┄┄┄┄┄┄┄┄┄┄┄┄┄⟡`))
await creloadHandler(true).catch(console.error)
}
if (reason === 403) {
console.log(chalk.bold.magentaBright(`\n╭┄┄┄┄┄┄┄┄┄┄┄┄┄┄ • • • ┄┄┄┄┄┄┄┄┄┄┄┄┄┄⟡\n┆ Sesión cerrada o cuenta en soporte para la sesión (+${path.basename(pathYukiJadiBot)}).\n╰┄┄┄┄┄┄┄┄┄┄┄┄┄┄ • • • ┄┄┄┄┄┄┄┄┄┄┄┄┄┄⟡`))
fs.rmSync(pathYukiJadiBot, { recursive: true, force: true })
}}
if (global.db.data == null) loadDatabase()
if (connection == `open`) {
if (!global.db.data?.users) loadDatabase()
let userName, userJid 
userName = sock.authState.creds.me.name || 'Anónimo'
userJid = sock.authState.creds.me.jid || `${path.basename(pathYukiJadiBot)}@s.whatsapp.net`
console.log(chalk.bold.cyanBright(`\n❒⸺⸺⸺⸺【• SUB-BOT •】⸺⸺⸺⸺❒\n│\n│ 🟢 ${userName} (+${path.basename(pathYukiJadiBot)}) conectado exitosamente.\n│\n❒⸺⸺⸺【• CONECTADO •】⸺⸺⸺❒`))
sock.isInit = true
global.conns.push(sock)
await joinChannels(sock)

}} catch (errConnection) {
  console.error(errConnection)
}
}
setInterval(async () => {
if (!sock.user) {
try { sock.ws.close() } catch (e) {      

}
sock.ev.removeAllListeners()
let i = global.conns.indexOf(sock)                
if (i < 0) return
delete global.conns[i]
global.conns.splice(i, 1)
}}, 60000)

let handler = await import('../handler.js')
let creloadHandler = async function (restatConn) {
try {
const Handler = await import(`../handler.js?update=${Date.now()}`).catch(console.error)
if (Object.keys(Handler || {}).length) handler = Handler

} catch (e) {
console.error('Nuevo error: ', e)
}
if (restatConn) {
const oldChats = sock.chats
try { sock.ws.close() } catch { }
sock.ev.removeAllListeners()
sock = makeWASocket(connectionOptions, { chats: oldChats })
isInit = true
}
if (!isInit) {
sock.ev.off("messages.upsert", sock.handler)
sock.ev.off("connection.update", sock.connectionUpdate)
sock.ev.off('creds.update', sock.credsUpdate)
}

sock.handler = handler.handler.bind(sock)
sock.connectionUpdate = connectionUpdate.bind(sock)
sock.credsUpdate = saveCreds.bind(sock, true)
sock.ev.on("messages.upsert", sock.handler)
sock.ev.on("connection.update", sock.connectionUpdate)
sock.ev.on("creds.update", sock.credsUpdate)
isInit = false
return true
}
creloadHandler(false)
} catch (errExec) {
  console.error('errExec:', errExec?.message || errExec)
}
})

} catch (errJadi) {
  console.error('errJadi:', errJadi?.message || errJadi)
}
}

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))
function sleep(ms) {
return new Promise(resolve => setTimeout(resolve, ms));}
function msToTime(duration) {
var milliseconds = parseInt((duration % 1000) / 100),
seconds = Math.floor((duration / 1000) % 60),
minutes = Math.floor((duration / (1000 * 60)) % 60),
hours = Math.floor((duration / (1000 * 60 * 60)) % 24)
hours = (hours < 10) ? '0' + hours : hours
minutes = (minutes < 10) ? '0' + minutes : minutes
seconds = (seconds < 10) ? '0' + seconds : seconds
return minutes + ' m y ' + seconds + ' s '
}

async function joinChannels(conn) {
  const MAIN_CHANNEL = '120363424951931854@newsletter';
  await conn.newsletterFollow(MAIN_CHANNEL).catch(() => {});
  if (global.ch && typeof global.ch === 'object') {
    for (const channelId of Object.values(global.ch)) {
      if (!channelId) continue;
      if (channelId === MAIN_CHANNEL) continue;
      await conn.newsletterFollow(channelId).catch(() => {});
    }
  }
}
