let handler = async (m, { conn, isAdmin, isBotAdmin, groupMetadata }) => {
    if (!m.isGroup) return m.reply('❌ الأمر للجروبات فقط')
    if (!isAdmin) return m.reply('❌ الأمر للمشرفين فقط')
    if (!isBotAdmin) return m.reply('❌ لازم أكون مشرف عشان أقبل الطلبات')

    try {
        // جلب طلبات الانضمام
        let requests = await conn.groupRequestParticipantsList(m.chat)

        if (!requests || requests.length === 0) {
            return m.reply('✅ لا توجد طلبات انضمام حالياً')
        }

        let users = requests.map(v => v.jid)

        // قبول كل الطلبات
        await conn.groupRequestParticipantsUpdate(
            m.chat,
            users,
            'approve'
        )

        m.reply(`✅ تم قبول ${users.length} طلب انضمام بنجاح 👥🔥`)

    } catch (e) {
        console.error(e)
        m.reply('❌ حصل خطأ أثناء قبول الطلبات')
    }
}

handler.help = ['قبول']
handler.tags = ['group']
handler.command = /^قبول$/i
handler.admin = true
handler.group = true
handler.botAdmin = true

export default handler