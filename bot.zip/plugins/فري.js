import axios from 'axios';
let sharp = null;
try { sharp = (await import('sharp')).default; } catch {}

const handler = async (m, { conn, text }) => {
  if (!sharp) return m.reply('❌ مكتبة sharp غير مثبتة، قم بتثبيتها: npm install sharp');
  if (!text) throw "*المرجو تقديم ايدي الحساب للبحث عنه في فري فاير 😃🤞*";
  const playerId = text;
  const apiUrl = `https://api.aboud-coding.store/api/games/info-player-ff?id=${playerId}`;
  try {
    const response = await axios.get(apiUrl);
    if (response.data.status !== 'success ✅') throw "*[❗] خطأ، لا يمكن الوصول إلى خادم API*";
    const playerInfo = response.data.freefire[0];
    const basicInfo = playerInfo.basicInfo;
    const profileInfo = playerInfo.profileInfo;
    const petInfo = playerInfo.petInfo;
    const socialInfo = playerInfo.socialInfo;
    const infoText = ` 
*⎔ ⋅ ───━ •﹝🐦‍🔥﹞• ━─── ⋅ ⎔*
*⸂معلومات عن الحساب فري فاير 😀🪄*
*∞┇━━━ •『🐦‍🔥』• ━━━┇∞*
*⌝ معلومات الحساب ┋🪽⌞ ⇊*
*〄┊الاسم⇇『 ${basicInfo.nickname} 』*
*〄┊الايدي⇇『 ${basicInfo.accountId} 』*
*〄┊المنطقه⇇『 ${basicInfo.region} 』*
*〄┊المستوى⇇『 ${basicInfo.level} 』*
*〄┊الرتبة⇇『 ${basicInfo.rank} 』*
*〄┊النقاط⇇『 ${basicInfo.rankingPoints} 』*
*⌝ معلومات الملف الشخصي ┋🪽⌞ ⇊*
*〄┊الايدي⇇『 ${profileInfo.avatarId} 』*
*〄┊الملابس المختاره⇇『 ${profileInfo.clothes.ids.join(', ')} 』*
*〄┊المهارات⇇『 ${profileInfo.equippedSkills.map(skill => `Skill ID: ${skill.skillId}`).join(', ')} 』*
*⌝ معلومات الحيوانات الاليفه ┋🪽⌞ ⇊*
*〄┊الاسم⇇『 ${petInfo.name} 』*
*〄┊المستوى⇇『 ${petInfo.level} 』*
*〄┊الخبرة⇇『 ${petInfo.exp} 』*
*⌝ معلومات اضافية ┋🪽⌞ ⇊*
*〄┊الوصف ⇇『 ${socialInfo.signature} 』*
*〄┊الغة⇇『 ${socialInfo.language} 』*
*∞┇━━━ •『🐦‍🔥』• ━━━┇∞*
*⸂🐦‍🔥╎الشرح╎🐦‍🔥⸃*
*〄┊📖⇇『هذه معلومات عن الحساب 『 ${petInfo.name} 』 تقريبا هذه معلومات دقيقه علا الحساب 』*
*⎔ ⋅ ───━ •﹝🐦‍🔥﹞• ━─── ⋅ ⎔* `;
    const avatarUrl = playerInfo.basicInfo.avatars[0];
    const responseAvatar = await axios.get(avatarUrl, { responseType: 'arraybuffer' });
    const image = await sharp(responseAvatar.data);
    const resizedImage = await image.resize(168, 43);
    const buffer = await resizedImage.toBuffer();
    await conn.sendMessage(m.chat, { text: infoText });
    await conn.sendMessage(m.chat, { image: buffer });
    const images = playerInfo.images;
    if (images && images.length > 0) {
      const imageUrl = images[0];
      const responseImage = await axios.get(imageUrl, { responseType: 'arraybuffer' });
      const image2 = await sharp(responseImage.data);
      const resizedImage2 = await image2.resize(168, 43);
      const buffer2 = await resizedImage2.toBuffer();
      await conn.sendMessage(m.chat, { image: buffer2 });
    }
  } catch (error) {
    console.error('Error:', error.message);
    m.reply(`*[❗] خطأ، لا يمكن الوصول إلى خادم API*\nالخطأ: ${error.message}`);
  }
};

handler.command = /^(فري-فاير)$/i;
export default handler;