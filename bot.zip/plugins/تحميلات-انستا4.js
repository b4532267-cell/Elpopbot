import axios from "axios"
import * as cheerio from "cheerio"

let handler = async (m, { conn, args, command }) => {
  try {
    if (!args[0]) {
      const usageMsg = `👻 *يا رفيقي، كيف تريدني أحمل من الانستقرام بدون رابط؟*\n\n` +
                     `📱 *طريقة الاستخدام:*\n` +
                     `.${command} <رابط انستقرام>\n\n` +
                     `🔗 *مثال:*\n` +
                     `.${command} https://www.instagram.com/p/DQHpUbPD184/\n\n` +
                     `ᎧᎶᏗᎷᎥ ᏰᎧᏖ 👻`
      return m.reply(usageMsg)
    }
    
    await m.reply('🔄 *جاري تحميل المحتوى من الانستقرام...* 👻')
    
    const form = new URLSearchParams({ url: args[0] + "&lang=en" })
    const headers = { "Content-Type": "application/x-www-form-urlencoded" }
    const res = await axios.post("https://api.downloadgram.app/media", form, { headers })
    
    const html = (res.data.match(/innerHTML\s*=\s*"([^]+?)";/)?.[1] || "").replace(/\\"/g, '"').replace(/\\n/g, "").replace(/\\t/g, "")
    const $ = cheerio.load(html)
    const links = $(".download-items__btn a").map((_, el) => $(el).attr("href")).get()
    
    if (links.length === 0) {
      return m.reply('👻 *ما قدرت أحمل المحتوى، تأكد من الرابط يا حبيبي* ᎧᎶᏗᎷᎥ ᏰᎧᏖ 👻')
    }
    
    let successCount = 0
    let errorCount = 0
    
    for (let link of links) {
      if (!link) {
        errorCount++
        continue
      }
      
      try {
        if (link.includes(".mp4")) {
          await conn.sendMessage(m.chat, { 
            video: { url: link }, 
            caption: `📹 *فيديو انستقرام*\n\nتم التحميل بواسطة ᎧᎶᏗᎷᎥ ᏰᎧᏖ 👻`
          }, { quoted: m })
        } else {
          await conn.sendMessage(m.chat, { 
            image: { url: link }, 
            caption: `🖼️ *صورة انستقرام*\n\nتم التحميل بواسطة ᎧᎶᏗᎷᎥ ᏰᎧᏖ 👻`
          }, { quoted: m })
        }
        successCount++
        await new Promise(resolve => setTimeout(resolve, 1000))
      } catch (e) {
        errorCount++
        console.error('Error sending media:', e)
      }
    }
    
    if (successCount > 0) {
      await conn.sendMessage(m.chat, { 
        text: `✅ *تم تحميل ${successCount} ملف بنجاح!*\n${errorCount > 0 ? `❌ فشل في تحميل ${errorCount} ملف` : ''}\n\nᎧᎶᏗᎷᎥ ᏰᎧᏖ 👻` 
      }, { quoted: m })
    }
    
  } catch (e) {
    m.reply(`👻 *خطأ: ${e.message}*\n\nجرب رابط ثاني أو حاول لاحقاً ᎧᎶᏗᎷᎥ ᏰᎧᏖ 👻`)
  }
}

handler.help = ['انستا4', 'انستجرام4']
handler.command = ['instagram', 'انستا4', 'انستجرام4', 'انستا4', 'انستجرام4']
handler.tags = ['downloader']

export default handler