import pkg from '@whiskeysockets/baileys'
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = pkg

const handler = async (m, { conn }) => {
  try {
    // 🖼️ الصورة الخاصة بالقسم
    const imageUrl = "https://files.catbox.moe/5o36un.jpg"
    const media = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: conn.waUploadToServer })

    await conn.sendMessage(m.chat, { react: { text: '💀', key: m.key } })

    // 📋 كل أمر في سطر لوحده من غير أي لغبطة
    const caption = `
╭━━〔🪄 ﻗـسـم الأدوات 🪄〕━━⬣
┃ ➟ *مرحباً بك يا* 『${m.pushName}』
┃ ➟ *داخل بوت* 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 💀
╰━━━━━━━━━━━━⬣

╭━━〔💀 أوامـر الأدوات 💀〕━━⬣
┃ ➟ 🌐 *.كروم*
┃ ➟ ⚠️ *.ابلاغ*
┃ ➟ 🎵 *.اسم-الاغنية*
┃ ➟ 📺 *.جوده*
┃ ➟ 🎨 *.تحسين*
┃ ➟ 🖌️ *.ارسم*
┃ ➟ 🌤️ *.الطقس*
┃ ➟ 📌 *.ايدي-جروب*
┃ ➟ 🆔 *.ايدي*
┃ ➟ 🏛️ *.بايدن*
┃ ➟ 🎭 *.تاثير*
┃ ➟ 🎤 *.تسجيل*
┃ ➟ 📷 *.بروفايل*
┃ ➟ 📏 *.مسافات*
┃ ➟ 🖼️ *.ازالة-الخلفية*
┃ ➟ 🔗 *.رابط*
┃ ➟ 📊 *.الاحصائيات*
┃ ➟ 🔗 *.لرابط2*
┃ ➟ 🌍 *.دي-ان-اس*
┃ ➟ 🗣️ *.انطق*
┃ ➟ 🔤 *.ترجم*
┃ ➟ 🌐 *.اي-بي*
┃ ➟ 📌 *.توبتيف*
┃ ➟ 📄 *.بي-دي-اف*
┃ ➟ 🔗 *.لرابط1*
┃ ➟ 🔗 *.لرابط2*
┃ ➟ 🔗 *.لرابط3*
┃ ➟ 🔊 *.لصوت*
┃ ➟ ✂️ *.اختصر*
┃ ➟ 🎨 *.واتستوك*
┃ ➟ 🔄 *.تحريك-جانبي*
┃ ➟ 🖼️ *.ازاله-الخلفيه2*
┃ ➟ ⚠️ *.سبويلر*
┃ ➟ 💬 *.تفاعل*
┃ ➟ 📜 *.لباركود*
┃ ➟ 📞 *.بحث-ارقام*
┃ ➟ 🏷️ *.هيدر*
┃ ➟ 📷 *.بروفايله*
┃ ➟ 🔄 *.محول-الوسائط*
┃ ➟ 🔑 *.كيوار*
┃ ➟ 📩 *.بحث-رساله*
┃ ➟ 👻 *.تخفي*
┃ ➟ 🌍 *.فلسطين*
┃ ➟ 📡 *.معلومات-القناه*
┃ ➟ 🔍 *.فحص-الموقع*
┃ ➟ 🥘 *.وصفه*
┃ ➟ 🍳 *.طبخ*
┃ ➟ 🔊 *.صوتكوبو*
┃ ➟ 🗣️ *.انطق2*
┃ ➟ 📑 *.نماذج*
┃ ➟ 🗣️ *.انطق3*
┃ ➟ 🔗 *.لرابط11*
┃ ➟ 🔄 *.تبادل*
┃ ➟ 🎭 *.جمال*
┃ ➟ 🔗 *.لرابط12*
┃ ➟ 🎭 *.ملصق*
┃ ➟ 🎭 *.ملصق2*
┃ ➟ 🎨 *.تحسين2*
┃ ➟ 🎭 *.للللللملصق3*
┃ ➟ 🎵 *.تفاصيل-الاغنيه*
┃ ➟ 💰 *.عمله*
┃ ➟ 🤖 *.تخيل*
┃ ➟ ⚫ *.لاسود*
╰━━━━━━━━━━━━⬣

> 💎 *بواسطة المطور 𝐁𝐄𝐋𝐀𝐋*
`.trim()

    const msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            header: proto.Message.InteractiveMessage.Header.create({ title: '', hasMediaAttachment: true, ...media }),
            body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
            footer: proto.Message.InteractiveMessage.Footer.create({ text: '⦓ 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓 ⦔' }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "⬅️ العودة للقائمة الرئيسية",
                    id: ".menu"
                  })
                }
              ]
            })
          })
        }
      }
    }, { userJid: m.sender })

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

  } catch (err) {
    console.error(err)
    await conn.sendMessage(m.chat, { text: '❌ حدث خطأ أثناء تنفيذ الأمر.' }, { quoted: m })
  }
}

handler.command = /^قسم-الادوات$/i
handler.tags = ["tools"]
handler.help = ["قسم-الادوات"]

export default handler