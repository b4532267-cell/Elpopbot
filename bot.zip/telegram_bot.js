/**
 * ╔══════════════════════════════════════════════╗
 * ║     ⚝  تـنـصـيـب ¦ 𝐒𝐀𝐓𝐎 𝐁𝐎𝐓  ⚝            ║
 * ║     Telegram Pairing System                  ║
 * ║     Developer: 𝐊𝐄𝐌𝐎! ⦓ 𝐊 ⦔ 𝐁𝐎𝐃𝐑𝐀𝐆𝐄𝐀 🇮🇱   ║
 * ╚══════════════════════════════════════════════╝
 */

import './config.js';

// ═══════════════════════════════════════════
//  ⚠️ مهم: يجب تعريف global.opts قبل أي import
//  لأن lib/simple.js يقرأ global.opts['legacy']
// ═══════════════════════════════════════════
if (!global.opts) {
  global.opts = { legacy: false };
}
if (!global.conns) {
  global.conns = [];
}

import { Telegraf, Markup } from 'telegraf';
import {
  useMultiFileAuthState,
  makeCacheableSignalKeyStore,
  fetchLatestBaileysVersion,
  Browsers,
} from '@whiskeysockets/baileys';
import NodeCache from 'node-cache';
import fs from 'fs';
import path from 'path';
import pino from 'pino';
import chalk from 'chalk';
import { makeWASocket, protoType, serialize } from './lib/simple.js';
import { readFileSync, watch as watchFs } from 'fs';
import syntaxerror from 'syntax-error';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);

// ═══════════════════════════════════════════
//            إعدادات البوت الأساسية
// ═══════════════════════════════════════════
const BOT_TOKEN   = '8843524822:AAGl0hirtuXRQlXEG21ZVgzq7PATOZhWyqs';
const DEV_TG      = 'KE_MO_x1';
const DEV_CHANNEL = 'https://t.me/TAEM_E_L_BODRGEA';
const CHANNEL_ID  = '@TAEM_E_L_BODRGEA';
const BOT_NAME    = '⚝  تـنـصـيـب ¦ 𝐄𝐋 𝐏𝐎𝐏 𝐁𝐎𝐓  ⚝';
const DEV_NAME    = '𝐄𝐋 𝐏𝐎𝐏! ⦓ B ⦔ 𝐁𝐎𝐃𝐑𝐀𝐆𝐄𝐀 🇮🇱';
const MAX_SESSIONS = 30;
// تفعيل String.prototype.decodeJid وباقي prototypes
protoType();
serialize();

const SESSIONS_DIR = path.join(__dirname, global.jadi || 'JadiBots');

// إنشاء كل المجلدات الضرورية
for (const _dir of [
  SESSIONS_DIR,
  path.join(__dirname, 'tmp'),
  path.join(__dirname, 'storage'),
  path.join(__dirname, 'storage/databases'),
]) {
  if (!fs.existsSync(_dir)) fs.mkdirSync(_dir, { recursive: true });
}

// ═══════════════════════════════════════════
//     Logger احترافي ملون (تم نقله هنا لتجنب إيرور الترتيب)
// ═══════════════════════════════════════════
const log = {
  info:    (msg) => console.log(chalk.bold.cyanBright(`\n╭─[TG-BOT] ℹ️\n╰ ${msg}`)),
  success: (msg) => console.log(chalk.bold.greenBright(`\n╭─[TG-BOT] ✅\n╰ ${msg}`)),
  warn:    (msg) => console.log(chalk.bold.yellowBright(`\n╭─[TG-BOT] ⚠️\n╰ ${msg}`)),
  error:   (msg) => console.log(chalk.bold.redBright(`\n╭─[TG-BOT] ❌\n╰ ${msg}`)),
};

// ═══════════════════════════════════════════
//   تهيئة قاعدة البيانات والـ Plugins
//   (ضروري لأن telegram_bot يعمل كـ process منفصل)
// ═══════════════════════════════════════════
import { Low, JSONFile } from 'lowdb';
import lodash from 'lodash';
import { pathToFileURL } from 'url';
import yargs from 'yargs';

if (!global.opts) global.opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse());
if (!global.prefix) global.prefix = new RegExp("^[" + (global.opts["prefix"] || "‎z/#$%.\\-").replace(/[|\\{}()[\]^$+*?.\-\^]/g, "\\$&") + "]");

// تحميل قاعدة البيانات
if (!global.db) {
  global.db = new Low(new JSONFile("storage/databases/database.json"));
  global.DATABASE = global.db;
  global.loadDatabase = async function loadDatabase() {
    if (global.db.READ) return new Promise(resolve => setInterval(async function() { if (!global.db.READ) { clearInterval(this); resolve(global.db.data == null ? global.loadDatabase() : global.db.data); } }, 1000));
    if (global.db.data !== null) return;
    global.db.READ = true;
    await global.db.read().catch(console.error);
    global.db.READ = null;
    global.db.data = { users: {}, chats: {}, stats: {}, msgs: {}, sticker: {}, settings: {}, ...(global.db.data || {}) };
    global.db.chain = lodash.chain(global.db.data);
  };
  await global.loadDatabase();
  // حفظ قاعدة البيانات كل 30 ثانية
  setInterval(async () => { if (global.db?.data) await global.db.write().catch(() => {}); }, 30000);
}

// تحميل الـ Plugins
const __pluginFolder = path.join(__dirname, "./plugins");
const pluginFilter = (f) => /\.js$/.test(f);
if (!global.plugins) global.plugins = {};

async function filesInit() {
  for (const filename of fs.readdirSync(__pluginFolder).filter(pluginFilter)) {
    try {
      const file = pathToFileURL(path.join(__pluginFolder, filename)).toString();
      const mod  = await import(`${file}?t=${Date.now()}`);
      global.plugins[filename] = mod.default || mod;
    } catch (e) {
      console.error(chalk.red("[TG-BOT] Plugin error: " + filename), e.message);
      delete global.plugins[filename];
    }
  }
  // طباعة رسالة النجاح في مكانها الصحيح بعد اكتمال التحميل والـ Logger جاهز
  log.success("Plugins loaded: " + Object.keys(global.plugins).length);
}
await filesInit();

// مراقبة تغييرات الـ Plugins تلقائياً
watchFs(__pluginFolder, async (_, filename) => {
  if (!filename || !pluginFilter(filename)) return;
  const dir = path.join(__pluginFolder, filename);
  try {
    if (fs.existsSync(dir)) {
      const mod = await import(pathToFileURL(dir).toString() + "?update=" + Date.now());
      global.plugins[filename] = mod.default || mod;
    } else {
      delete global.plugins[filename];
    }
  } catch(e) { console.error(e); }
});

// ═══════════════════════════════════════════
//       إعداد البوت وأنظمة الإدارة
// ═══════════════════════════════════════════
const bot = new Telegraf(BOT_TOKEN);

const processingQueue = new Map();  // userId -> true
const pendingSockets  = new Map();  // userId -> { sock, timeout }
const codeCache       = new NodeCache({ stdTTL: 180 });

// ═══════════════════════════════════════════
//    أزرار المطور الشفافة (تظهر في كل رسالة)
// ═══════════════════════════════════════════
const devButtons = () =>
  Markup.inlineKeyboard([
    [
      Markup.button.url('👨‍💻 المطور', `https://t.me/${DEV_TG}`),
      Markup.button.url('📢 القناة', DEV_CHANNEL),
    ],
  ]);

// ═══════════════════════════════════════════
//    بناء connectionOptions صحيح مثل main.js
// ═══════════════════════════════════════════
function buildConnectionOptions(state) {
  const logger = pino({ level: 'fatal' });
  return {
    version:                    undefined, // سيُحدَّث بعد fetchLatestBaileysVersion
    logger,
    printQRInTerminal:          false,
    auth: {
      creds: state.creds,
      keys:  makeCacheableSignalKeyStore(state.keys, logger),
    },
    browser:                    Browsers.ubuntu('Chrome'),
    markOnlineOnclientect:      false,
    generateHighQualityLinkPreview: true,
    syncFullHistory:            true,
    retryRequestDelayMs:        10,
    transactionOpts:            { maxCommitRetries: 10, delayBetweenTriesMs: 10 },
    maxMsgRetryCount:           15,
    appStateMacVerification:    { patch: false, snapshot: false },
    getMessage:                 async () => '',
  };
}

// ═══════════════════════════════════════════
//   التحقق من اشتراك القناة
// ═══════════════════════════════════════════
async function checkChannelSub(ctx) {
  try {
    const member = await ctx.telegram.getChatMember(CHANNEL_ID, ctx.from.id);
    return ['member', 'administrator', 'creator'].includes(member.status);
  } catch {
    return true;
  }
}

// ═══════════════════════════════════════════
//    رسالة ترحيب /start
// ═══════════════════════════════════════════
bot.start(async (ctx) => {
  const isSub = await checkChannelSub(ctx);
  if (!isSub) {
    return ctx.replyWithHTML(
      `🚫 <b>اشتراك إجباري!</b>\n\nاشترك في قناة المطور أولاً ثم أعد /start`,
      Markup.inlineKeyboard([[Markup.button.url('📢 اشترك الآن', DEV_CHANNEL)]])
    );
  }

  await ctx.replyWithHTML(
    `╔══════════════════════════════╗\n` +
    `║  🤖 ${BOT_NAME}\n` +
    `╚══════════════════════════════╝\n\n` +
    `أهلاً <b>${ctx.from.first_name}</b>! 👋\n\n` +
    `📱 <b>أرسل رقم واتساب مع كود البلد بدون +</b>\n\n` +
    `<b>أمثلة:</b>\n` +
    `• مصر: <code>201234567890</code>\n` +
    `• السعودية: <code>966501234567</code>\n` +
    `• الكويت: <code>96551234567</code>\n\n` +
    `⚠️ <b>واتساب العادي فقط</b> (ليس الأعمال)\n\n` +
    `👨‍💻 <b>المطور:</b> ${DEV_NAME}`,
    devButtons()
  );
});

// ═══════════════════════════════════════════
//    معالجة رقم الهاتف
// ═══════════════════════════════════════════
bot.on('text', async (ctx) => {
  const userId = ctx.from.id;
  const text   = ctx.message.text.trim();

  if (text.startsWith('/')) return;

  // التحقق من الاشتراك
  const isSub = await checkChannelSub(ctx);
  if (!isSub) {
    return ctx.replyWithHTML(
      `🚫 <b>يجب الاشتراك في القناة أولاً!</b>`,
      Markup.inlineKeyboard([[Markup.button.url('📢 اشترك', DEV_CHANNEL)]])
    );
  }

  // التحقق من صيغة الرقم
  if (!/^[0-9]{7,15}$/.test(text)) {
    return ctx.replyWithHTML(
      `❌ <b>رقم غير صحيح!</b>\n\nأرسل الرقم بدون + أو مسافات\nمثال: <code>201234567890</code>`,
      devButtons()
    );
  }

  // منع التعارض
  if (processingQueue.get(userId)) {
    return ctx.replyWithHTML(
      `⏳ <b>طلبك السابق لا يزال قيد المعالجة...</b>\nانتظر قليلاً أو حاول بعد دقيقة.`,
      devButtons()
    );
  }

  // التحقق من سعة الجلسات
  const activeCount = global.conns.filter(
    (c) => c?.user && c?.ws?.socket?.readyState !== 3
  ).length;
  if (activeCount >= MAX_SESSIONS) {
    return ctx.replyWithHTML(
      `🔴 <b>الخادم ممتلئ!</b>\n\nالجلسات: <b>${activeCount}/${MAX_SESSIONS}</b>\nيرجى المحاولة لاحقاً.`,
      devButtons()
    );
  }

  // إضافة للـ Queue
  processingQueue.set(userId, true);

  const loadingMsg = await ctx.replyWithHTML(
    `⏳ <b>جارٍ إنشاء كود الربط...</b>\n📱 <code>+${text}</code>\n\nيرجى الانتظار...`
  );

  try {
    await startPairingSession(ctx, text, userId, loadingMsg.message_id);
  } catch (err) {
    log.error(`Pairing error for ${text}: ${err.message}`);
    processingQueue.delete(userId);
    try {
      await ctx.telegram.editMessageText(
        ctx.chat.id, loadingMsg.message_id, undefined,
        `❌ <b>خطأ في إنشاء الكود!</b>\n\n<code>${err.message}</code>\n\nحاول مجدداً.`,
        { parse_mode: 'HTML', ...devButtons() }
      );
    } catch {}
  }
});

// ═══════════════════════════════════════════
//    جلسة الربط الرئيسية
// ═══════════════════════════════════════════
async function startPairingSession(ctx, phone, userId, loadingMsgId) {
  const sessionPath = path.join(SESSIONS_DIR, phone);

  if (!fs.existsSync(sessionPath)) {
    fs.mkdirSync(sessionPath, { recursive: true });
  }

  // إغلاق جلسة pending قديمة
  if (pendingSockets.has(userId)) {
    const old = pendingSockets.get(userId);
    clearTimeout(old.timeout);
    try { old.sock.ws.close(); } catch {}
    old.sock.ev.removeAllListeners();
    pendingSockets.delete(userId);
  }

  // جلب أحدث إصدار من Baileys
  const { version }          = await fetchLatestBaileysVersion();
  const { state, saveCreds } = await useMultiFileAuthState(sessionPath);

  const connectionOptions    = buildConnectionOptions(state);
  connectionOptions.version  = version;

  // ✅ الحل: تأكد من وجود global.opts قبل makeWASocket
  if (!global.opts) global.opts = { legacy: false };

  let sock        = makeWASocket(connectionOptions);
  let isConnected = false;
  let codeSent    = false;

  // Timeout 3 دقائق
  const sessionTimeout = setTimeout(async () => {
    if (!isConnected) {
      log.warn(`Timeout for +${phone}`);
      try { sock.ws.close(); } catch {}
      sock.ev.removeAllListeners();
      pendingSockets.delete(userId);
      processingQueue.delete(userId);
      try {
        await ctx.replyWithHTML(
          `⏰ <b>انتهت مهلة الربط (3 دقائق)!</b>\n\nأرسل رقمك مجدداً للحصول على كود جديد.`,
          devButtons()
        );
      } catch {}
    }
  }, 3 * 60 * 1000);

  pendingSockets.set(userId, { sock, timeout: sessionTimeout });

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;

    // ── إرسال Pairing Code عند ظهور QR ──
    if (qr && !codeSent) {
      codeSent = true;
      try {
        // انتظار حتى تصبح WebSocket مفتوحة (readyState = 1 = OPEN)
        await new Promise((resolve) => {
          const check = setInterval(() => {
            if (sock.ws?.readyState === 1) { clearInterval(check); resolve(); }
          }, 300);
          setTimeout(() => { clearInterval(check); resolve(); }, 6000);
        });

        if (typeof sock.requestPairingCode !== 'function') {
          throw new Error('هذا الإصدار من Baileys لا يدعم Pairing Code');
        }

        let code = await sock.requestPairingCode(phone);
        code = code?.match(/.{1,4}/g)?.join('-') || code;

        codeCache.set(`code_${userId}`, code);
        log.success(`Pairing code for +${phone}: ${code}`);

        // حذف رسالة الانتظار
        try { await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsgId); } catch {}

        // إرسال الكود مع زر النسخ
        await ctx.replyWithHTML(
          `╔══════════════════════════════╗\n` +
          `║  🔗 <b>كود ربط</b>        ║\n` +
          `╚══════════════════════════════╝\n\n` +
          `📱 <b>الرقم:</b> <code>+${phone}</code>\n\n` +
          `🔑 <b>كود الربط:</b>\n` +
          `┌──────────────────┐\n` +
          `│  <code>${code}</code>  │\n` +
          `└──────────────────┘\n\n` +
          `📋 <b>خطوات الربط:</b>\n` +
          `➊ افتح <b>واتساب</b> على هاتفك\n` +
          `➋ اضغط ⋮ ← <b>الأجهزة المرتبطة</b>\n` +
          `➌ اضغط <b>ربط جهاز</b> ← <b>ربط برمز</b>\n` +
          `➍ أدخل الكود أعلاه\n\n` +
          `⏰ <b>صلاحية الكود:</b> 3 دقائق فقط\n` +
          `⚠️ <b>واتساب العادي فقط</b> (ليس الأعمال)\n\n` +
          `🤖 ${BOT_NAME}`,
          {
            parse_mode: 'HTML',
            ...Markup.inlineKeyboard([
              [Markup.button.callback(`📋 نسخ: ${code}`, `copy_${userId}`)],
              [
                Markup.button.url('👨‍💻 المطور', `https://t.me/${DEV_TG}`),
                Markup.button.url('📢 القناة', DEV_CHANNEL),
              ],
            ]),
          }
        );
      } catch (err) {
        log.error(`Failed to send pairing code: ${err.message}`);
        processingQueue.delete(userId);
        clearTimeout(sessionTimeout);
        pendingSockets.delete(userId);
        try { await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsgId); } catch {}
        await ctx.replyWithHTML(
          `❌ <b>فشل في إنشاء كود الربط!</b>\n\n<code>${err.message}</code>\n\nتأكد من صحة الرقم وحاول مجدداً.`,
          devButtons()
        );
      }
    }

    // ── الاتصال ناجح ──
    if (connection === 'open') {
      isConnected = true;
      clearTimeout(sessionTimeout);
      pendingSockets.delete(userId);
      processingQueue.delete(userId);

      const userName = sock.authState?.creds?.me?.name || 'مستخدم';
      log.success(`Sub-Bot connected: +${phone} | ${userName}`);

      global.conns.push(sock);
      await joinChannels(sock);

      await ctx.replyWithHTML(
        `╔══════════════════════╗\n` +
        `║  ✅ <b>تم الربط بنجاح!</b>    ║\n` +
        `╚══════════════════════╝\n\n` +
        `👤 <b>الاسم:</b> ${userName}\n` +
        `📱 <b>الرقم:</b> <code>+${phone}</code>\n` +
        `🟢 <b>الحالة:</b> متصل ونشط\n\n` +
        `🎉 البوت الفرعي يعمل الآن!\n\n` +
        `🤖 ${BOT_NAME}`,
        devButtons()
      );

      await setupSubBotHandler(sock, sessionPath, connectionOptions);
    }

    // ── الاتصال مقطوع ──
    if (connection === 'close') {
      const reason = lastDisconnect?.error?.output?.statusCode;
      log.warn(`Connection closed +${phone} | Reason: ${reason}`);

      if (!isConnected) {
        clearTimeout(sessionTimeout);
        pendingSockets.delete(userId);
        processingQueue.delete(userId);
      }

      removeFromConns(sock);

      // 515 = restart required (طبيعي بعد إدخال الكود) → نعيد الاتصال فوراً
      if (reason === 515) {
        log.info(`515 restart signal for +${phone} — reconnecting now...`);
        setTimeout(() => reconnectSubBot(sessionPath, connectionOptions, phone, ctx), 1000);
        return;
      }

      if ([401, 403, 405].includes(reason)) {
        try { fs.rmSync(sessionPath, { recursive: true, force: true }); } catch {}
        if (isConnected) {
          try {
            await ctx.replyWithHTML(
              `🔴 <b>انتهت جلسة البوت الفرعي!</b>\n📱 <code>+${phone}</code>\n\nأرسل رقمك مجدداً لإعادة الربط.`,
              devButtons()
            );
          } catch {}
        }
      } else if (isConnected) {
        log.info(`Auto-reconnecting +${phone}...`);
        setTimeout(() => reconnectSubBot(sessionPath, connectionOptions, phone, ctx), 3000);
      }
    }
  });

  sock.ev.on('creds.update', saveCreds);
}

// ═══════════════════════════════════════════
//    إعداد Handler للبوت الفرعي
// ═══════════════════════════════════════════
async function setupSubBotHandler(sock, sessionPath, connectionOptions) {
  let handler = await import('./handler.js');

  const creloadHandler = async (restatConn) => {
    try {
      const Handler = await import(`./handler.js?update=${Date.now()}`).catch(console.error);
      if (Handler && Object.keys(Handler).length) handler = Handler;
    } catch (e) {
      log.error(`Handler reload: ${e.message}`);
    }

    if (restatConn) {
      try { sock.ws.close(); } catch {}
      sock.ev.removeAllListeners();
      if (!global.opts) global.opts = { legacy: false };
      sock = makeWASocket(connectionOptions);
    }

    if (sock.handler) sock.ev.off('messages.upsert', sock.handler);
    sock.handler = handler.handler.bind(sock);
    sock.ev.on('messages.upsert', sock.handler);
    return true;
  };

  await creloadHandler(false);

  // مراقبة الجلسة
  setInterval(() => {
    if (!sock?.user) {
      removeFromConns(sock);
      sock.ev.removeAllListeners();
    }
  }, 60000);
}

// ═══════════════════════════════════════════
//    إعادة الاتصال التلقائي
// ═══════════════════════════════════════════
async function reconnectSubBot(sessionPath, oldOptions, phone, ctx = null) {
  log.info(`Reconnecting +${phone}...`);
  try {
    const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
    const { version }          = await fetchLatestBaileysVersion();
    const opts = { ...buildConnectionOptions(state), version };

    if (!global.opts) global.opts = { legacy: false };
    const sock = makeWASocket(opts);

    sock.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect } = update;
      if (connection === 'open') {
        const name = sock.authState?.creds?.me?.name || phone;
        log.success(`♻️ Reconnected: +${phone} (${name})`);
        global.conns.push(sock);
        await joinChannels(sock);
        await setupSubBotHandler(sock, sessionPath, opts);
      }
      if (connection === 'close') {
        const reason = lastDisconnect?.error?.output?.statusCode;
        removeFromConns(sock);
        if (reason === 515) {
          log.info(`515 restart for +${phone} — reconnecting...`);
          setTimeout(() => reconnectSubBot(sessionPath, opts, phone, ctx), 1000);
        } else if ([401, 403, 405].includes(reason)) {
          try { fs.rmSync(sessionPath, { recursive: true, force: true }); } catch {}
        } else {
          setTimeout(() => reconnectSubBot(sessionPath, opts, phone, ctx), 5000);
        }
      }
    });

    sock.ev.on('creds.update', saveCreds);
  } catch (err) {
    log.error(`Reconnect failed +${phone}: ${err.message}`);
    setTimeout(() => reconnectSubBot(sessionPath, oldOptions, phone, ctx), 10000);
  }
}

// ═══════════════════════════════════════════
//    إزالة من global.conns
// ═══════════════════════════════════════════
function removeFromConns(sock) {
  const i = global.conns.indexOf(sock);
  if (i >= 0) {
    delete global.conns[i];
    global.conns.splice(i, 1);
  }
}

// ═══════════════════════════════════════════
//    الانضمام للقنوات
// ═══════════════════════════════════════════
async function joinChannels(conn) {
  if (!global.ch) return;
  for (const channelId of Object.values(global.ch)) {
    await conn.newsletterFollow(channelId).catch(() => {});
  }
}

// ═══════════════════════════════════════════
//    تحميل الجلسات المحفوظة عند البدء
// ═══════════════════════════════════════════
async function loadSavedSessions() {
  if (!fs.existsSync(SESSIONS_DIR)) return;

  const sessions = fs.readdirSync(SESSIONS_DIR).filter((d) => {
    try {
      return (
        fs.statSync(path.join(SESSIONS_DIR, d)).isDirectory() &&
        fs.existsSync(path.join(SESSIONS_DIR, d, 'creds.json'))
      );
    } catch { return false; }
  });

  if (!sessions.length) { log.info('No saved sessions found.'); return; }

  log.info(`Found ${sessions.length} saved session(s). Loading...`);

  for (const phone of sessions) {
    try {
      const sessionPath          = path.join(SESSIONS_DIR, phone);
      const { version }          = await fetchLatestBaileysVersion();
      const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
      const opts = { ...buildConnectionOptions(state), version };

      if (!global.opts) global.opts = { legacy: false };
      const sock = makeWASocket(opts);

      sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'open') {
          const name = sock.authState?.creds?.me?.name || phone;
          log.success(`♻️ Auto-loaded: +${phone} (${name})`);
          global.conns.push(sock);
          await joinChannels(sock);
          await setupSubBotHandler(sock, sessionPath, opts);
        }
        if (connection === 'close') {
          const reason = lastDisconnect?.error?.output?.statusCode;
          removeFromConns(sock);
          if (reason === 515) {
            setTimeout(() => reconnectSubBot(sessionPath, opts, phone), 1000);
          } else if ([401, 403, 405].includes(reason)) {
            try { fs.rmSync(sessionPath, { recursive: true, force: true }); } catch {}
          } else {
            setTimeout(() => reconnectSubBot(sessionPath, opts, phone), 5000);
          }
        }
      });

      sock.ev.on('creds.update', saveCreds);

      // تأخير بين الجلسات لتجنب rate limits
      await new Promise((r) => setTimeout(r, 2000));
    } catch (err) {
      log.error(`Failed to load session ${phone}: ${err.message}`);
    }
  }
}

// ═══════════════════════════════════════════
//    Callback زر نسخ الكود
// ═══════════════════════════════════════════
bot.on('callback_query', async (ctx) => {
  const data = ctx.callbackQuery?.data || '';
  if (data.startsWith('copy_')) {
    const uid  = parseInt(data.replace('copy_', ''));
    const code = codeCache.get(`code_${uid}`);
    if (code) {
      await ctx.answerCbQuery(`✅ الكود: ${code}`, { show_alert: true });
    } else {
      await ctx.answerCbQuery('⏰ انتهت صلاحية الكود! أرسل رقمك مجدداً.', { show_alert: true });
    }
  } else {
    await ctx.answerCbQuery();
  }
});

// ═══════════════════════════════════════════
//    أوامر إضافية
// ═══════════════════════════════════════════
bot.command('status', async (ctx) => {
  const active = global.conns.filter(
    (c) => c?.user && c?.ws?.socket?.readyState !== 3
  );

  let msg = `📊 <b>حالة السب-بوتات</b>\n\n`;
  msg    += `🟢 <b>النشطة:</b> ${active.length}/${MAX_SESSIONS}\n`;
  msg    += `🔵 <b>في الانتظار:</b> ${pendingSockets.size}\n\n`;

  if (active.length > 0) {
    msg += `<b>الجلسات النشطة:</b>\n`;
    active.slice(0, 15).forEach((c, i) => {
      const num  = c.user?.jid?.split('@')[0] || '???';
      const name = c.user?.name || 'Unknown';
      msg += `${i + 1}. <code>+${num}</code> — ${name}\n`;
    });
    if (active.length > 15) msg += `... و${active.length - 15} جلسة أخرى`;
  } else {
    msg += `لا توجد جلسات نشطة.`;
  }

  await ctx.replyWithHTML(msg, devButtons());
});

bot.command('help', async (ctx) => {
  await ctx.replyWithHTML(
    `📖 <b>دليل ${BOT_NAME}</b>\n\n` +
    `<b>الأوامر:</b>\n` +
    `• /start — بدء وربط رقم جديد\n` +
    `• /status — حالة الجلسات النشطة\n` +
    `• /help — هذه القائمة\n\n` +
    `<b>طريقة الربط:</b>\n` +
    `① أرسل رقمك بدون +\n` +
    `② انسخ الكود المُرسَل\n` +
    `③ واتساب ← الأجهزة المرتبطة\n` +
    `④ ربط جهاز ← ربط برمز\n` +
    `⑤ أدخل الكود وانتظر التأكيد\n\n` +
    `👨‍💻 <b>المطور:</b> ${DEV_NAME}`,
    devButtons()
  );
});

// ═══════════════════════════════════════════
//    معالجة الأخطاء
// ═══════════════════════════════════════════
bot.catch((err, ctx) => {
  if (typeof log !== 'undefined' && log.error) {
    log.error(`Bot error: ${err.message}`);
  } else {
    console.error(chalk.red(`Bot error: ${err.message}`));
  }
  try {
    ctx.replyWithHTML(`❌ <b>حدث خطأ!</b>\nحاول مجدداً.`, devButtons());
  } catch {}
});

// ═══════════════════════════════════════════
//    تشغيل النظام
// ═══════════════════════════════════════════
(async () => {
  // ضمان وجود global vars
  if (!global.opts)  global.opts  = { legacy: false };
  if (!global.conns) global.conns = [];

  await loadSavedSessions();

  await bot.launch({ dropPendingUpdates: true });

  log.success(`🚀 Telegram Bot launched!`);
  log.success(`Bot: ${BOT_NAME}`);
  log.success(`Dev: @${DEV_TG}`);
  log.success(`Sessions: ${SESSIONS_DIR}`);
})();

process.once('SIGINT',  () => { bot.stop('SIGINT');  });
process.once('SIGTERM', () => { bot.stop('SIGTERM'); });